import { useState, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";

// ─── SUPABASE CONFIG ────────────────────────────────────────────────────────
// Substitua com suas credenciais do Supabase (Settings → API)
const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = process.env.REACT_APP_SUPABASE_ANON_KEY || "";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const ALLOWED_DOMAIN = "@gruponautika.com.br";
const EXERCISE_COUNT = 6;

// ─── CATALOG DATA ───────────────────────────────────────────────────────────
const CATALOG_SECTIONS = {
  "🌊 Aquático e Praia": `4 CatáCCloaagttoáá ll2oo0gg2oo5 22002244

---

PRATIKO 2X2 PRATIKO 3X3 PAGODA 2X2
COLUNA COLUNA COLUNA
040499 D’ÁGUA 040500 D’ÁGUA 040509 D’ÁGUA
1000 MM 1000 MM 1800 MM
Material: Cobertura em poliéster 210D com proteção solar Material: Cobertura em poliéster 210D com proteção solar Material: Cobertura em poliéster Oxford e estrutura em ferro
60 FPS e com revestimento aluminizado na parte interna do 60 FPS e com revestimento aluminizado na parte interna do Medidas: 2 x 2 x 2,5m
tecido. Possui hastes em alumínio + estrutura dobrável em tecido. Possui hastes em alumínio + estrutura dobrável em Teto aluminizado
aço tratado aço tratado Proteção solar 50 FPS
Medidas: 2 x 2 x 2,5m Medidas: 3 x 3 x 2,5 m Peso: 14kg
Peso: 11kg Peso: 11,5kg AZ - 7896558459819
AZ - 7896558459741 AZ - 7898471193214
PAGODA 3X3 PAGODA 2X3 TETO GAZEBO
COLUNA COLUNA
040510 D’ÁGUA 040516 D’ÁGUA PRATIKO
1800 MM 1800 MM
040700
Material: Cobertura em poliéster Oxford e estrutura em ferro Material: Cobertura em poliéster Oxford e estrutura em ferro Material: Poliéster 420D aluminizado
Medidas: 3 x 3 x 2,5m Medidas: 2 x 3 x 2,95m Medidas: 2 x 2m
Peso: 15kg Peso: 14,5kg Proteção solar 60 FPS
Teto aluminizado Teto aluminizado AZ - 7896558462369
Proteção solar 50 FPS Proteção solar 50 FPS Não acompanha a estrutura do gazebo
AZ - 7896558459604 AZ - 7896558464240
TETO GAZEBO TETO GAZEBO
PAGODA 2X2 PAGODA 3X3
040704 040706
Material: Poliéster 420D aluminizado Material: Poliéster 420D aluminizado
Medidas: 2 x 2m Medidas: 3 x 3m
Proteção solar 50 FPS Proteção solar 50 FPS
AZ - 7896558462376 AZ - 7896558462383
PR - 7896558462390
CCaattáállCooaggtáool o22g00o22 244026 5

---

TITAN 6+6 VÊNUS ULTRA
COLUNA COLUNA
041005 D’ÁGUA 3 - 041010 D’ÁGUA
2000 MM 4 - 041012 2500 MM
5 - 041014
6 - 041015
Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno de alta Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno de alta
densidade (antifungo) e costuras seladas seam tape densidade (antifungo), costuras seladas seam tape e varetas em fibra de vidro
Medidas: 4,6 x 3 x 2,15m Medidas: 3P: 2,1 x 1,8 x 1,35m | 4P: 2,1 x 2,1 x 1,4m | 5P: 2,4 x 2,4 x 1,6m |
Peso: 13,8kg 6P: 3 x 3 x 1,8m
MR - 7898471192125 Peso: 3P: 3,2kg | 4P: 3,4kg | 5P: 4,2kg | 6P: 6,4kg
3: LJVD - 7898471193641 | 4: LJVD - 7898471193658
5: LJVD - 7898471193665 | 6: LJVD - 7898471193672
KOALA ZEUS
COLUNA COLUNA
2 - 041016 D’ÁGUA 5 - 041030 D’ÁGUA
600 MM 2500 MM
3 - 041017 6 - 041032
4 - 041018
Material: Sobreteto em poliéster 170T de alta qualidade, varetas em fibra de vidro, Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno de alta
dormitório em poliéster 170T e piso em polietileno 90g/m² densidade, costuras seladas seam tape e varetas em fibra de vidro
Medidas: 2P: 2 x 1,2 x 1m | 3P: 2 x 1,6 x 1,15m | 4P: 2 x 2 x 1,3m Medidas: 5P: 2,1 x 2,1 x 1,45m + Avancê: 2,1 x 1,6m
Peso: 2P: 1,25kg | 3P: 1,55kg | 4P: 1,7kg 6P: 3,05 x 3,05 x 2m + Avancê: 3,05 x 2m
2: UN - 7896558460990 | 3: UN - 7896558461003 | 4: UN - 7896558491291 Peso: 5P: 4kg | 6P: 7,2kg
5: VD - 7898471191531 | 6: VD - 7898471190275
6 CatáCCloaagttoáá ll2oo0gg2oo6 22002244

---

AMAZON REDE DE DESCANSO SMART
AUTO INFLÁVEL
COLUNA
041051 D’ÁGUA COM TELA 042010
2000 MM
041060
Material: Poliéster 190T Material: 210T Nylon com tela mesh no see um Material: Poliéster tafetá 190T com revestimento em PVC +
Medidas: Aberto: 2,60 x 3,00 m Medidas: 2,75 x 1,40 m espuma de alta densidade
Peso: 900g Peso: 690g Medidas: 183 x 60 x 3cm
VD- 7898471192309 VD - 7898471191869 Peso: 1,1kg
PR - 7898471193566
VD - 7898471191586
DOTT DOTT CASAL
042012 042013
Material: Fabricado em TPU revestido de poliamida de alta Material: Nylon 40D com laminação em TPU
tenacidade Medidas: 1,95 x 1,2 x 5,5cm
Medidas: 195 x 58 x 5 cm Peso: 1,2kg
Peso: 420g CZ - 7896558464660
AZ - 7896558453664
ULTRALIGHT SMART ISOLANTE TÉRMICO
042030 042040 042045
Material: Externo: Poliéster 190T W/R W/P | Interior: Material: PVC liso e flocado ultra resistente Material: EVA com revestimento aluminizado
Poliéster 190T | Enchimento: Poliéster 150g/m2 hollow fiber Medidas: 32,5 x 47,5 cm Medidas: Aberto: 180 x 50 x 0,6 cm
Medidas: 200 x 80 x 55 cm Peso: 105g Fechado: 50 x Ø11,5 cm
Peso: 700g MR - 7898471192163 Peso: 170g
Faixa de temperatura: 5°C a 15°C VD - 7896558468033 UN - 7898471190718
PR - 7898471192316
VD - 7898471192323
CCaattáállCooaggtáool o22g00o22 244026 7

---

DIXON BIKE ACTION VISION TENT MEGALITE
043005 044002 044004 044010
Material: Aço inoxidável 420 Material: Corpo em ABS + alumínio e lente Material: ABS e fita em poliéster Material: ABS + policarbonato
Medidas: Lâmina: 34 cm | Espessura: 4 mm em policarbonato Medidas: 75 x 50 x 30mm Medidas: 6cm x Ø12,2 cm
| Cabo: 16 cm Medidas: 3,8 x 3,8 x 5,3 cm Peso: 39g Peso: 59g
Peso: 719g Peso: 213g Potência: 130 lúmens (forte) | 35 lúmens UN - 7898471192552
PR - 7898471192828 Potência: 500 lúmens (fraco)
UN - 7898471200219 UN - 7896558467814
TUBELUX ATTACK
044012 044020
Material: Corpo em ABS Material: Liga de alumínio
Medidas: 9 x 9 x 13,1cm Medidas: 13,2 x Ø 3 cm
Peso: 258g Peso: 130g
Potência: Lanterna frontal: 1000 lúmens | Lanterna superior: 300 lúmens Potência: 140 lúmens
UN - 7896558464592 UN - 7898471191647
PREMIUM ABROLHOS GUARÁ
044022 044042 30 L - 045007
50 L - 045010
Material: Alumínio com tratamento Material: Plástico PVC
anodizado e lente em acrílico côncavo Medidas: 16,2 x Ø 4,18m
Medidas: 10,5cm x Ø 3 cm Peso: 90g
Peso: 125g Potência: 120 lúmens
Potência: 120 lúmens UN - 7898471192521
UN - 7898471191326
MULTI LUX
044044
Material: Corpo em ABS Material: 100% Poliéster Ripstop com conectores em PVC e ABS
Medidas: 19,5 x 10 x 18,5cm Medidas: 30L: 46,5 x 30 x 24cm | 50L: 68 x 36,5 x 29cm
Peso: 570g Peso: 30L: 650g (aprox.) | 50L: 1,2kg (aprox.)
Potência: Lanterna frontal: 1500 lúmens | Lanterna superior: 250 lúmens 30L: PR - 7896558460556 | AZ - 7896558460563
Recarregável 50L: PR - 7896558460570 | AZ - 7896558460587
UN - 7896558468705
8 CatáCCloaagttoáá ll2oo0gg2oo6 22002244

---

AMAZÔNIA 15L KEEP DRY
045012 5 L - 045051
10 L - 045052
20 L - 045054
40 L - 045056
Saco impermeável
Material: Poliéster 210T ultra resistente com vedação em PVC
Medidas e pesos:
5 litros - Medidas: 35 x Ø 18 cm | Peso: 80g
Material: Poliéster 600D e poliéster 210D
10 litros - Medidas: 47 x Ø 21 cm | Peso: 105g
Medidas: 42 x 31 x 12cm
20 litros - Medidas: 66 x Ø 24 cm | Peso: 155g
Peso: 270g
40 litros - Medidas: 72 x Ø 46 cm | Peso: 290g
PR - 7896558464929
5L: AZ - 7896558462635 / LJ - 78984711 92132 | 10L: AZ - 7898471192149 | 20L: AZ -
AZ - 7896558464936
7896558462659 / VD - 7898471192156 / PR - 7898471193542 |
40L: AZ - 7896558462666 / LJ - 7898471193436
SACOLA C/ RODAS MAPA ALUMÍNIO MICROFIBRA
P/ GAZEBO
046005 046007 TRAVEL
PAGODA
046020
045120
Material: Poliéster Material: Polímero ultra resistente Material: Corpo em liga de alumínio Material: Microfibra - 85% Poliéster 15%
Medidas: 22,5cm x 20cm x 1,3m Medidas: 5,5 x 9 cm Medidas: 7,5 x 5,5 x 2,5 cm Poliamida
UN - 7896558464257 Peso: 75g Peso: 113g Medidas: Toalha: 120 x 60 cm
UN - 7898471190022 PR - 7898471190015 Peso: 105g
VD - 7898471193399
CANTIL DE CANECA P/ BASTÃO
PLÁSTICO CANTIL 046040
046030 046035
Material: Plástico PP inodoro Material: Alumínio Material: Duralumínium
Medidas: 15 x 7 x 20 cm Medidas: 13 x 8 x 9 cm Medidas: Ajustável de 65 a 135 cm
Peso: 180g Peso: 99g Peso: 280g
VD - 7898471190138 UN - 7898471192217 Bastão retrátil
PR - 7891000370902
AM - 7896558491239
CCaattáállCooaggtáool o22g00o22 244026 9

---

PARACORD 10M SURVIVAL M
046050 046057
Material: Paracord 550 e Polipropileno + Material: Paracord 550 e Polipropileno +
Poliéster Poliéster
Medidas: 10m | Peso: 77g Medidas: 2,5m | Peso: 77g
VD - 7898471200431 VD - 7898471192255
PR - 7898471200424 PR - 7898471192231
PEDERNEIRA TREKKER POLIC KIT PICNIC
FLINT 046080 046082 046090
046072
Material: Pedra flint + liga de alumínio. Material: Aço inoxidável 420 e cabo em liga Material: Alumínio `,
  "🏕️ Barracas": `BMarórvaeciass
Comparativo Coluna Possui Qtd. Possui Quantidade
costuras Indicação
Barracas d’água seladas? Pessoas avancê? de portas
Gypsy 1000mm Não - Não 1 porta Clima
seco
Challet 3000mm Sim 3/4 e 7/8 Não 1 porta Sol e
pessoas chuva
Flash automática 1500mm Não 2 e 3 Não 1 porta Sol e
pessoas chuvas leves
Canadense 2000mm Sim 3 e 5 Não 1 porta Sol e
pessoas chuvas leves
Windy 2500mm Sim 1 pessoa Sim 1 porta Sol e
chuva
Falcon 1000mm Sim 2, 3 e 4 Sim 1 porta Clima
pessoas seco
Falcon Black Out 2000mm Sim 2 e 3 Sim 1 porta Sol e
pessoas chuvas leves
Onix 2000mm Sim 4 e 6 Sim 1 porta Sol e
pessoas chuvas leves
Cherokee Air 1500mm Sim 4 pessoas Sim 1 porta Sol e
chuva
2/3, 3/4,
Cherokee 2500mm Sim 5/6 e 8/9 Sim 1 porta Sol e
chuva
pessoas
Colorado 2500mm Sim 3/4 e 5/6 Sim 1 porta Sol e
pessoas chuva
Laredo 2500mm Sim 8/9 pessoas Sim 1 porta Sol e
chuva
Amazon 1800mm Sim 3/4 pessoas Sim 2 portas Sol e
chuvas leves
Explorer 2500mm Sim 4/6 pessoas Sim 2 portas Sol e
chuva
Indy 2500mm Sim 5 3 / / 6 4 , e 4 8 / / 5 9 , Sim 2 portas Sol e
chuva
pessoas
2, 3,
Panda 600mm Não 4 e 6 Não 1 porta Clima
seco
pessoas
Fox 1800mm Não 2/ 5 3 / , 6 3 , / 6 4 / , 7 4 e /5, Não 1 porta Clima
seco
7/8 pessoas
Dome 1800mm Não 3, 4, 5 Não 1 porta Sol e
e 6 pessoas chuvas leves
Takoma 2000mm Sim 2 pessoas Sim 1 porta Sol e
chuvas leves
Sol e
Transform 3000mm Não 6 pessoas Não 1 porta chuvas
fortes
Tent Hut 800mm Não 8/9 pessoas Não 1 porta Clima
seco
Hut GT 2500mm Não 8/9 pessoas Sim 1 porta Sol e
chuva
Transform 3000mm Não 5/6 pessoas Não 1 porta Sol e
chuva
1188 CCaattáállooggoo 22002264

---

BMarórvaeciass
Gypsy Challet Inflável
Coluna Coluna
150070 3/4 - 150080
d’água d’água
7/8 - 150082
2000mm 3000mm
Material: Sobreteto em poliéster 190T, tela mosquiteiro em B3 e piso em Material: Poliéster Oxford 300D e piso em polietileno 200g
polietileno 90g Medidas: Aberta: 3,0 x 2,10 x 1,95m | Fechada: 75 x 40 x 34cm
Medidas: 3,0 x 3,0 x 2,0m Peso: 13kg
Peso: 6,5kg Infla totalmente em 1 minuto. Possui janelas com tela mosquiteiro. Bolsos internos
UN - 7896558491321 para pequenos objetos e suporte para lanterna no teto
UN -7896558468200
Canadense
Coluna
3 - 150100 | 5 - 150102
d’água
2000mm
Material: Sobreteto em 100% poliéster 180T, estrutura em tubos de aço,
dormitório 100% poliéster respirável, tela mosquiteiro de poliéster super fino
Medidas: 3P: 2,2 x 2 x 1,5m | 5P: 2,6m x 2,2m x 1,6m
Peso: 3P: 4,9kg | 5,5kg
Dois bolsos internos ajudam na organização de pequenos itens
Estrutura resistente e design clássico
3P: VD - 7896558464622 | BG - 7896558464677
5P: VD - 7896558464639 | BG - 7896558464684
CCaattáállooggoo 22002264 1199

---

BMarórvaeciass
Flash Automática Windy
Coluna Coluna
2 - 150422 150520
d’água d’água
3 - 150430
1500mm 2500mm
Material: Sobreteto em poliéster 190T, quarto em malha B3 + poliéster 190T Material: Sobreteto em 100% poliéster impermeabilizado com poliuretano e
respirável, piso em polietileno 90g e varetas em fibra de vidro retardante de fogo, estrutura com varetas de fibra de vidro, dormitório 100%
Barraca automática: monta em 10 segundos poliéster respirável, tela mosquiteiro de poliéster super fino (NO SEE –UM)
Medidas: 2P: 2,0m x 1,5m x 1,2m | 3P: 2,0 x 2,0 x 1,35m Medidas: 2,5m x 1,5m x 85cm
Peso: 2P: 2,3kg | 3P: 2,6kg Peso: 1,9kg
2P: UN - 7896558491307 UN - 7896558440350
3P: UN - 7896558491314 LJ - 7896558467005
Falcon
Coluna
2 - 150620 | 3 - 150640
d’água
4 - 150660
2000mm
Material: Sobreteto em poliéster laminado com poliuretano, costura selada
termosoldada e proteção UV, interior em poliéster BR respirável, tela mosquiteiro
No-see-um®, piso em polietileno antifungos e estrutura com varetas de fibra de
vidro
Medidas: 2P: 2 x 1,3 x 1m | 3P: 2,05 x 1,6 x 1,1m | 4P: 2,1 x 2,2 x 1,3m
Peso: 2P: 1,8kg | 3P: 2,1kg | 4P: 3,1kg
2P: UN - 7896558411602
3P: UN - 7896558411619
4P: UN - 7896558412012
2200 CCaattáállooggoo 22002264

---

BMarórvaeciass
Falcon Black Out
Coluna
2 - 150621 | 3 - 150641
d’água
2000mm
Material: Sobreteto em poliéster impermeabilizado com poliuretano, costura
selada termosoldada e proteção UV, interior em poliéster respirável, tela
mosquiteiro No-see-um®, piso em polietileno antifungos e estrutura com varetas
de fibra de vidro
Medidas: 2P: 1,00 x 1,30 x 2,00 + 0,30m | 3P: 1,10 x 1,60 x 2,05 + 0,40m
Peso: 2P: 1,9kg | 3P: 2,2kg
2P: UN - 7896558649012
3P: UN - 7896558649029
Onix Cherokee
Coluna Coluna
4 - 150700 | 6 - 150720 2/3 - 151195 | 3/4 - 151200
d’água d’água
5/6 - 151235 | 8/9 - 151245
2000mm 2500mm
Material: Sobreteto em poliéster 190T laminado com poliuretano aluminizado, Material: Sobreteto em 100% Poliéster impermeabilizado com poliuretano, interior
costura selada termo-soldada e proteção UV, inteiror em poliéster 190T respirável, em tela mosquiteiro de poliéster super fino, piso em polietileno antifungos sem
tela mosquiteiro No-see-um®, piso em polietileno antifungos e estrutura em costuras (termosoldado), estrutura com varetas de fibra
varetas de fibra de vidro Medidas: 2/3P: 2,1 x 1,55 x 1,15m | 3/4P: 2,1 x 2,1 x 1,35m | 5/6P: 3 x 3 x 1,75m
Medidas: 4P: 2,1 x 2,2 x 1,3m | 6P: 2,9 x 2,5 x 1,6m 8/9P: 3,6 x 3,05 x 1,85m
Peso: 4P: 3,1kg | 6P: 4,7kg Peso: 2/3P: 2,5kg | 3/4P: 3,5kg | 5/6P: 6,9kg | 8/9P: 8,5kg
4P: UN - 7896558453688 2/3P: UN - 7896558430580
6P: UN - 7896558453671 3/4P: UN - 7896558434304
5/6P: UN - 7896558430597
8/9P: UN - 7896558430603
CCaattáállooggoo 22002264 2211

---

BMarórvaeciass
Laredo
Coluna
8/9 - 151280
d’água
2500mm
Material: Sobreteto em 100% Poliéster impermeabilizado com poliuretano,
interior com tela mosquiteiro de poliéster super fino, piso em polietileno de alta
resistência e antifungos sem costuras (termoselado) e estrutura com varetas de
fibra de vidro
Medidas: 4,6 x 3,1 x 1,9m
Peso: 10,7kg
UN - 7896558431334
Amazon
Coluna
3/4 - 151350
d’água
1800mm
Material: Sobreteto camuflado em poliéster laminado com poliuretano, com
costura selada termosoldada e proteção UV, interior em poliéster respirável e tela
de mosqueteiro No-see-um®, piso em polietileno de alta resistência e antifungos
e estrutura com varetas de fibra de vidro
Medidas: 2,1 x 1,55 x 1,15m
Peso: 3kg
UN - 7896558417321
2222 CCaattáállooggoo 22002264

---

BMarórvaeciass
Explorer Indy
Coluna Coluna
4/6 - 151900 3/4 - 152450 | 4/5 - 152500
d’água d’água
5/6 - 152550 | 8/9 - 152556
2500mm 2500mm
Material: Sobreteto em poliéster laminado com poliuretano parcialmente Material: Sobreteto 100% Poliéster impermeabilizado com poliuretano, interior
aluminizado, costura selada termosoldada e proteção UV, interior com tela em poliéster respirável e tela mosquiteiro No-see-um, piso em polietileno de alta
mosquiteiro de poliéster super fino, piso em polietileno de alta resistência sem resistência antifungos sem costuras (termosselado) e estrutura com varetas de
costuras (termosoldadas), estrutura com varetas de fibra de vidro fibra de vidro
Medidas: 2,1 x 4,7 x 1,95m Medidas: 3/4P: 2,05 x 2,05 x 1,3m | 4/5P: 2,1 x 2,4 x 1,3m | 5/6P: 2,4 x 2,4 x 1,9m |
Peso: 8,6kg 8/9P: 3,6 x 3,05 x 1,85m
UN - 7896558434953 Peso: 3/4P: 4,4kg | 4/5P: 5,6kg | 5/6P: 7,8kg | 8/9P: 13,3kg
3/4P: UN - 7896558414467
4/5P: UN - 7896558412746
5/6P: UN - 7896558419288
8/9P: UN - 7896558457617
Panda
Coluna
2 - 155100 | 3 - 155150
d’água
4 - 155152 | 6 - 155154
600mm
Material: Paredes 100% Poliéster impermeabilizado com poliuretano,
tela mosquiteiro de poliéster No-see-um®, piso em polietileno de alta resistência
e antifungos e estrutura com varetas de fibra de vidro
Medidas: 2P: 2,05 x 1,45 x 1,05m | 3P: 2,5 x 1,6 x 1,15 m | 4P: 2,05 x 2,05 x 1,3m |
6P: 2,9 x 2,3 x 1,3m
Peso: 2P: 1,5kg | 3P: 1,7kg | 4P: 1,8kg | 6P: 2,8kg
2P: UN - 7896558421526
3P: UN - 7896558421359
4P: UN - 7896558430504
6P: UN - 7896558435073
CCaattáállooggoo 22002264 2233

---

BMarórvaeciass
Fox
Coluna
2/3 - 155300 | 3/4 - 155320
d’água
4/5 - 155340 | 5/6 - 155360
1800mm
6/7 - 155370 | 7/8 - 155372
Material: Sobreteto 100% poliéster impermeabilizado com poliuretano, paredes
em poliéster respirável, tela mo`,
  "🎒 Mochilas e Bolsas": `Mochilas
Attack Air X 30L Cargo Air X 40+5L
200130 200145
COSTADO
COSTADO
Material: Poliéster Ripstop 600D, PU e EVA Material: Poliéster Ripstop 600D e PU
Medidas: 51 x 30 x 20cm Medidas: 53 x 30 x 26cm
Peso: 980g Peso: 1kg
Características: exclusivo sistema de ventilação Air X. Costado com ergonomia Características: costado com ergonomia precisa que ajuda a poupar energia ao
precisa que ajuda a poupar energia ao carregar a mochila. Boa ventilação graças carregar a mochila. Exclusivo sistema de ventilação Air X: boa ventilação graças
aos canais entre o costado acolchoado e a malha 3D respirável. Alça com design aos canais entre o costado acolchoado e a malha 3D respirável.
moderno e revestimento em EVA. CZ - 7896558649166
LJ - 7896558649142 VD - 7896558649173
PR - 7896558649159
Cargo Air X 60L
200160
COSTADO
Material: Poliéster Ripstop 600D, PU e EVA
Medidas: 63,5 x 34 x 28cm
Peso: 1,09kg
Características: costado com ergonomia precisa que ajuda a poupar energia ao
carregar a mochila. Boa ventilação graças aos canais entre o costado acolchoado
e a malha 3D respirável.
CZ- 7896558649180
VD- 7896558649197
28

---

Mochilas
Gávea 25l Andes
200205 28L - 200210
40L - 200212
55L - 200214
Material: Tecido em Ripstop e conectores em PVC e Material: Tecido em Ripstop e conectores em PVC e ABS
ABS Medidas: 28L: 18 x 34 x 49cm | 40L: 28 x 37 x 64cm | 55L: 28 x 40 x 73cm
Medidas: 49 x 34 x 16cm Peso: 28L: 530g | 40L: 1,38kg | 55L: 1,43kg
Peso: 530g Características: costado acolchoado para maior conforto, ajuste de barriga, 2 bolsos laterais para garrafas,
Características: costado com sistema Air Flow, compartimento dedicado para notebook e possui saída para sistema de hidratação
ajuste de barriga e altura peitoral, 2 compartimentos Os modelos 40L e 55L acompanham capa de chuva.
espaçosos, possui saída para sistema de hidratação, 28L: VN - 7896558460457 | PR - 7896558460440
compartimento dedicado para notebook, 2 bolsos 40L: VN - 7896558460488 | PR - 7896558460471
laterais para garrafas e saída para fone de ouvido 55L: VN - 7896558460501 | PR - 7896558460495
AZ - 7896558460433 | PR - 7896558460426
LJ - 7896558468132
Tahoe
38L - 200220
60L - 200226
Material: Tecido em Ripstop e conectores em PVC e ABS
Medidas: 38L: 23 x 35 x 62cm | 60L: 32 x 39 x 73cm
Peso: 38L: 1kg | 60L: 1,4kg
Características: costado acolchoado para maior conforto, ajuste de barriga
com bolso e alça, 2 bolsos laterais para garrafas, compartimento dedicado para
notebook, saída para fone de ouvido, 3 compartimentos principais, alça para
prender bastão de caminhada, capuz superior com 2 compartimentos adicionais
e Fitas compactadoras para redução de medidas
O modelo de 60L possui 2 barras estruturais nas costas
38L: AZ - 7896558460525 | PR - 7896558460518
60L: AZ - 7896558460549 | PR - 7896558460532

---

Mochilas
Intruder 45l Intruder 60l Smart
201100 201110 201620
Material: Poliéster Oxford PVC de alta tenacidade Material: Poliéster Oxford PVC de alta tenacidade Material: Poliéster Oxford RU Rip-stop de alta
Medidas: 30 x 60 x 4cm Medidas: 31 x 62 x 8cm tenacidade
Peso: 970g Peso: 1,65kg Medidas: 12 x 33 x 5cm
PR - 7896558427450 PR - 7896558411497 Peso: 450g
PR - 7896558415464
Camp Bag Dollar String
201692 201701 201705
Material: Poliéster Oxford 300D Material: Poliéster 900D Material: Poliéster 190T
Medidas: 40x 32 x 25 cm Medidas: 35 x 13 x 10,5cm Medidas: 34 x 48 cm
VD - 7896558460983 Peso: 120g Peso: 530g
PR - 7896558461065 PRCZ - 7896558462765
PRLJ - 7896558462772
Gym Bag Trail Run
201902 202031
Material: Poliéster 300D Material: Poliéster
Medidas: 43,5 x 26cm Ripstop e 210D
Peso: 400g Medidas: 42 x 29 cm
CZ - 7896558461133 Peso: 260g
PR - 7896558464943
Foxy 3l Foxy
202051 Bag 20l
202052
Material: Poliéster 600D
Material: Poliéster 600D escovado e 210D Medidas: 30,5 x 53 x 11,5 cm
Medidas: 27 x 14,5 x 8cm Peso: 560g
Peso: 130g Características: conta com divisórias internas, compartimento telado com zíper e
Características: alças ajustáveis, dois bolsos externos com zíper e um interno com bolso externo pequeno, alças ajustáveis e fechamento magnético com fivela para
divisória, pode ser usada como necessaire ou shoulder bag maior segurança
AM - 7896558464868 AM - 7896558464882
AZ- 7896558464851 AZ - 7896558464875
30

---

Mochilas
Ioio Pocky Sampa
203040 203042 203046
Material: Poliéster 600D de alta densidade Material: Poliéster 420D Material: Poliéster 290D
Medidas: 36,5 x 21,5 x 15,5 cm Medidas: 43,5 x 25 x 23 cm Medidas: 48 x 34 x 28,5cm
Peso: 180g Peso: 175g Peso: 900g
AZ - 7896558461089 PR - 7896558461126 PR - 7896558461164
CZ - 7896558461102 CZ - 7896558461119
PR - 7896558461072
Evoque 40l Evoque Evoque 2l
203051 Roller 38l 203053
203052
Material: Laminação em PU 600D e poliéster 210D Material: Laminação PU 600D e poliéster 210D Material: Poliéster 600D laminado em PU
Medidas: 53,5 x 33 x 25 cm Medidas: 58,5 x 35,5 x 25 cm Medidas: 25,3 x 12,5 x 5 cm
Peso: 900g Peso: 2,82kg Peso: 170g
Características: possui bolsos organizadores e Características: inclui elástico de compressão e Características: possui dois compartimentos
divisórias teladas, parte interna com divisórias e bolsos telados internos, 2 bolsos externos de fácil principais com divisórias internas para melhor
bandejas removíveis, alças acolchoadas, pode ser acesso, tem puxador ajustável em duas alturas e duas organização, design acolchoado e leve e alça
usada como mala de bordo e em conjunto com a rodinhas para melhor movimentação ajustável com fivela
Evoque Roller PR - 7896558464899 PR - 7896558464912
PR - 7896558464837 VD - 7896558464905

---

Mochilas
Capa P/ Mochila Duffle BK 20l Duffle BKP 25l
M - 205200 206000 206001
G - 205250
Material: Poliéster 190T metalizado e impermeável Material: PVC 500D Tarpaulin Material: PVC 500D Tarpaulin
Peso: 90g Medidas: 30,5 x 12 x 48cm Medidas: 32 x 14 x 63cm
M - 7896558411282 Peso: 700g Peso: 750g
G- 7896558411299 BCPR - 7896558462536 | PR - 7896558462550 LJ - 7896558468835
CZES - 7896558465032 | PRLJ - 7896558468361 CZ - 7896558468828
PRPR - 7896558467166
Daily Duffel c/ visor SOS 2l Duffle 2.0
206004 206005 206050
COM ALÇA
DUPLA
Material: PVC 500D Tarpaulin Material: PVC 250D Tarpaulin Material: PVC 500D Tarpaulin
Medidas: 30 x 75cm Medidas: 34 x 13 x 7cm Medidas: 30 x 75 cm
Peso: 600g Peso: 90g Peso: 600g
PR - 7896558464264 | VD - 7896558464271 LJ - 7896558468859 CZ - 7896558462505
AM - 7896558468392 | LJ - 7896558468408
Duffle 1.0 Duffle Bag 50l Duffle Bag 70l
206055 206060 206070
COM ALÇA
Material: 210T PVC Material: PVC 500D Tarpaulin Material: PVC 500D Tarpaulin
Medidas: 23 x 66cm Medidas: 52 x 32,5 x 32,5 cm Medidas: 64 x 35 x 35 cm
Peso: 300g Peso: 1kg Peso: 1,15kg
LJ - 7896558462529 PR - 7896558462567 | LJ - 7896558462574 PR - 7896558462581
CZ - 7896558462512 AM - 7896558468330 | CZ - 7896558468347 LJ - 7896558462642
Duffle Bag 90l
206090
Material: PVC 500D Tarpaulin
Medidas: 73 x 40 x 40 cm
Peso: 1,5kg
LJ - 7896558468354
32

---

Mochilas
Duffle Bag 120l Saco estanque Saco estanque
206120 Dry 10l Dry 20l
209010 209020
COMPACTADA
(80 LITROS)
EXPANDIDA
(120 LITROS)
Material: PVC 500D Tarpaulin Material: Nylon 70D revestido com PU Material: Nylon 70D revestido com PU
Medidas: 73 x 40 x 40 cm Medidas: 21 x 47 cm Medidas: 23,5 x 66 cm
Peso: 1,5kg Peso: 100g Peso: 200g
LJ - 7896558649265 PR - 7896558467265 PR - 7896558467272
PR - 7896558649272`,
  "😴 Sacos de Dormir e Colchões": `Sacos de dormir
Viper Bugy Freedom
230100 230120 230130
Material: Interno: Algodão (polycotton) | Externo:
Poliéster 190T resinado com poliuretano | Material: Interno: Algodão (polycotton) | Externo: Material: Interno: Algodão (polycotton) | Externo:
Enchimento: Hollow-Fiber 200g/m2 Poliamida | Enchimento: Hollow-Fiber Poliéster 190T resinado com poliuretano |
Medidas: 2,10m x 75cm | Peso: 950g Medidas: 1,8m x 75cm | Peso: 650g Enchimento: Hollow-Fiber 200g/m2
Faixa de temperatura: 5°C a 12°C Faixa de temperatura: 8°C a 15°C Medidas: 2,1m x 75cm | Peso: 1,5kg
AZPR - 7896558423759 | CM - 7896558435943 AZ - 7896558459079 Faixa de temperatura: -1,5°C a -3,5°C
PRLJ - 7896558414474 | PRVD - 7896558423742 PR - 7896558459086 VDCZ - 7896558439132 | AZLJ - 7896558439149
Liberty Mummy Kuple
230150 230300 231010
Material: Interno: Algodão (polycotton) | Externo: Material: Interno: Algodão (polycotton) | Externo:
Poliéster 190T resinado com poliuretano | Poliéster Ripstop 190T resinado com poliuretano |
Enchimento: Hollow-Fiber 250g/m2 Enchimento: Open-Fiber 250g/m2
Medidas: 2,1m x 75cm | Peso: 1,2kg Medidas: 2,3m x 80cm | Peso: 1,5kg
Faixa de temperatura: 4°C a 10°C Faixa de temperatura: -1°C a 8°C
VMPR - 7896558423766 AZCZ - 7896558423797 | PRVD - 7896558431754
Antartik Micron
230500 230600
Material: Interno: Algodão/Polycotton | Externo: Material: Interno: Poliéster 70D | Externo: Poliéster Material: Interno: Algodão/Poliéster Escovado
Poliéster Ripstop 190T resinado com poliuretano | Ripstop 190T resinado com poliuretano | Enchimento: Externo: Poliéster 210T | Enchimento: Hollow-Fiber
Enchimento: Open-Fiber siliconizado 350g/m2 Thermopix® siliconizado 50g/m2 Medidas: 2,1m x 1,5m
Medidas: 2,3m x 80cm | Peso: 1,7kg Medidas: 2,1m x 82cm | Peso: 1,7kg Peso: 4,5kg
Faixa de temperatura: -7°C a 3°C Faixa de temperatura: 5°C a 8°C Faixa de temperatura: -5°C a 5°C
PRAZ - 7896558423810 | PRLJ - 7896558416133 AZPR - 7896558423841 | LJPR - 7896558412821 AZ - 7896558441395
Compactador Eva Aluminizado Mat
p/ saco de 232000 232005
dormir Compak
231090
COMPRIMIDO
Material: Poliéster Oxford 210D Material: E.V.A. laminado com alumínio refletivo Material: E.V.A. (espuma vinílica acetinada)
Medidas: 27 x 46cm Medidas: 1,80m x 50cm x 6mm Medidas: 1,80m x 50cm x 10mm
Peso: 300g Peso: 200g Peso: 300g
PR - 7896558468842 UN - 7896558412500 UN - 7896558464547

---

Colchões
Fit Ecologic casal Star solteiro Star casal
250060 Com inflador 250110 250130
incorporado
Material: PVC Aveludado / PVC Material: PVC 61,4%, Viscose Fibre + PVC 35,9%, Material: PVC 61,4%, Viscose Fibre + PVC 35,9%,
Medidas: 1,87m x 1,32m x 23cm Outros 2,7% Outros 2,7%
Peso: 4kg Medidas: 1,85m x 76cm x 22cm Medidas: 1,91m x 1,37m x 22cm
Peso suportado: 200kg Peso: 1,5kg Peso: 2,9kg
UN - 7896558417079 Peso suportado: 100kg Peso suportado: 200kg
UN - 7896558440015 UN - 7896558440039
Zenite solteiro Zenite casal Com inflador Brunei Auto
incorporado
250500 250550 Bivolt
Com inflador Com inflador
incorporado incorporado
250711
Material: PVC Aveludado / PVC Material: PVC Aveludado / PVC Material: Poliéster e PVC
Medidas: 1,85 m x 76 cm x 28 cm Medidas:1,91m x 1,37m x 28cm Medidas: 202 x 152 x 36cm
Peso: 1,72kg Peso: 3,2kg Peso suportado: 300kg
Peso suportado: 150kg Peso suportado: 300kg Com bomba de ar USB integrada. Infla rápido: entre 5
UN - 7896558450304 UN - 7896558413149 e 6 minutos usando o inflador integrado.
UN - 7896558491475
Mirage solteiro Cozy Doblo
Auto inflável
250810 252019 252022
Auto inflável
Material: PVC Aveludado / PVC Material: Poliéster 190T revestido com PVC Material: Poliéster 75D revestido com PVC
Medidas: 1,87 m x 77 cm x 23 cm Medidas: 1,80m x 53cm x 3cm Medidas: 1,80m x 1,30m x 5cm
Peso: 2,1kg Peso: 510g Peso: 2,8kg
Peso suportado: 100kg UN - 7896558464721 UN - 7896558464707
UN - 7896558411350
Sleep Pack Comfy
252025 252028 Auto inflável
Material: Nylon 40D com laminaçãoem TPU Material: Poliéster 190T revestido com PVC
Medidas: 1,92m x 60cm x 5cm Medidas: 45 x 20 x 10cm
Peso: 650g Peso: 280g
UN - 7896558464714 UN - 7896558464691

---

Colchões
Goya Palmas Kit De Reparo
252210 252220 P/ Colchão
253000
Material: Placa de espuma em poliuretano de alta Material: Placa de espuma em poliuretano de alta Material: PVC
Medidas: 1,90m x 60cm x 2cm densidade D20 UN - 7896558416324
Peso: 525g Medidas:1,90m x 60cm x 2cm
PR - 7896558457464 Peso: 775g
AZ - 7896558457471
38`,
  "🍳 Artefatos a Gás": `Artefatos à gás
Strike Trail Jupiter
280100 280200 280280
Material: Parte inferior e tampa de aço revestido de Material: Aço e polímero Material: Fabricado com aço inoxidável de liga
epóxi com abraçadeiras de aço cromado, registro em Medidas: 12,4 x 20,2cm especial, ultra leve e extra resistente
latão e vidro especial Peso: 460g Medidas: 7 x 10cm
Medidas: 11 x 20cm | Peso: 670g Tipo de cartucho: 190g (não incluso) Peso: 250g
Tipo de cartucho: 190g (não incluso) UN - 7896558416034 Tipo de cartucho: Tekgas (não incluso)
UN - 7896558416027 UN - 7896558426248
Apolo Cairo Magus
280300 280350 280400
Material: Aço galvanizado com pintura epóxi especial
e base revestida com enamel atóxico
Material:Aço inoxidável e aço galvanizado com bico e Material: Aço inoxidável e galvanizado com bico e Medidas: 44 x 31cm | Peso: 4,3kg
válvulas de latão e alumínio válvulas de latão e vidro especial 3 em 1: pode ser usado como grelha, chapa ou fogão
Medidas: 11 x 12cm Medidas: 8 x 13cm tradicional
Peso: 320g Peso: 260g Tipo de cartucho: Campgás (não incluso) ou botijão
Tipo de cartucho: Tekgás / Maxxgás (não incluso) Tipo de cartucho: Tekgás / Maxxgás (não incluso) (GLP) (não incluso)
UN - 7896558417772 UN - 7896558417789 UN - 7896558426132
Aramis Etna
280410 280412
Material: Aço esmaltado com epóxi especial e base Material: Aço inoxidável
revestida com enamel atóxico Medidas: 63 x 27 x 9cm
Medidas: 62,5 x 34,5cm | Peso: 9kg Peso: 3,55kg
Tipo de cartucho: Campgás (não incluso) ou botijão Tipo de cartucho: Campgás (não incluso) ou botijão (GLP) em um queimador (não incluso)
(GLP) (não incluso) PR - 7896558464288
UN - 7896558440428
Frontier Duo Ceramik Cheff
280450 280460 280470
Material: Aço esmaltado com pintura epóxi especial e Material: Aço esmaltado com pintura epóxi especial e
base revestida com enamel atóxico Material: Aço esmaltado com epóxi especial e base base de aço inoxidável atóxico com apoios de panela
Medidas: 35 x 31cm | Peso: 2,1kg revestida com enamel atóxico em alumínio fundido
Tipo de cartucho: Campgás (não incluso) ou botijão Medidas: 35 x 33cm | Peso: 2,2kg Medidas: 30 x 34 x 11cm | Peso: 2,18kg
(GLP) (não incluso) Tipo de cartucho: Campgás (não incluso) ou botijão Tipo de cartucho: Campgás (não incluso) ou botijão
UN - 7896558440374 | BC - 7896558453237 (GLP) (não incluso) (GLP) (não incluso)
PR - 7896558449506 UN - 7896558423582 UN -7896558420086
40

---

Artefatos à gás
Super Chama Super Chama
Lite 280472
280471
Material: Aço inoxidável, alumínio, cobre e outros Material: Aço e cobre
materiais Medidas: 9 x 13,5cm
Medidas: 16,5 x 16,5 x 11cm | Peso: 535g Peso: 620g
3 queimadores 5 queimadores
Tipo de cartucho: Tekgás e Maxxgás Tipo de cartucho: Tekgás e Maxxgás
UN - 7896558465001 UN - 7896558460853
Stain Átomo Átomo Pro
280474 280476 280479
Material: Aço inoxidável Material: Aço inoxidável Material: Aço
Medidas: 33,5 x 27,5 x 8,5cm Medidas: 16 x 16 x 9,5cm Medidas: 14,5 x 14,5 x 12cm
Peso: 1,8kg Peso: 405g Peso: 445g
Tipo de cartucho: Campgás (não incluso) ou botijão Tipo de cartucho: Campgás (não incluso) Tipo de cartucho: Campgás (não incluso)
(GLP) (não incluso) UN - 7896558462604 UN - 7896558465018
UN - 7896558462451
Iron Ikon Mini Ikon
280482 280489 280490
Material: Aço e alumínio Material: Plástico ABS e aço inoxidável Material:Plástico ABS e aço inoxidável
Medidas: Aberto: 31 x 29,3 x 10,8cm Medidas: 25,9cm Medidas: 28 x 4 x 12cm
Fechado: 29,3 x 8,5 x 10,8cm | Peso: 1,4kg Peso: 175g Peso: 215g
Tipo de cartucho: Campgás (não incluso) UN - 7896558462314 UN - 7896558421397
UN - 7896558465025
Gás Torch Drakar
280492 280494
Material: Corpo em polímero e ponteira em aço Material: Plástico ABS e aço inoxidável
Medidas: 14,5 x 9cm Medidas: 19 x 4 x 7cm
Peso: 120g Peso: 130g
PRVM - 7896558459406 UN - 7896558468422

---

Artefatos à gás
Maxtop Maxlong
280495 280496
Material: Aço inoxidável Material: Metal e plástico
Medidas: 17 x 27 x 5cm Medidas: 80 x 8,2cm
Peso: 120g Peso: 415g
UN - 7896558437961 Tipo de cartucho: Campgás (não incluso)
UN - 7896558460860
Mapp Torch Mapp Up 4000 190g caixa c/ 48 pçs.
280498 280499 280500
Material: Aço inoxidável e plástico Material: Aço inoxidável e plástico Conteúdo: Gás tipo Butano
Medidas: 20 x 8cm Medidas: 28 x 9cm Capacidade: 190g
Peso: 208g Peso: 1,9kg UN - 7896558411442
Tipo de cartucho: Mapp (não incluso) Tipo de cartucho: Mapp (não incluso)
UN - 7896558460822 UN - 7896558460815
Campgás caixa Tekgás caixa c/ 6 pçs. Maxxgás caixa c/ 6
c/ 28 pçs. 280600 pçs.
280560 280620
280565
Conteúdo: Gás tipo Nor-Butano / Propano / Iso- Conteúdo: Gás com mistura especial 73% iso-butano, Conteúdo: Gás composto por 75% Iso-Butano e 25%
Butano 23% propano e 4% nor-butano Propano
Capacidade: 227g Capacidade: 230g Capacidade: 450g
280560 - UN - 7896558413286 UN - 7896558413293 UN - 7896558440367
280565 - UN - 7896558464301
Mapp Gás NH Lighter Gás
280662 300ml
12pçs - 280681
6pçs - 280682
600ml
6pçs. - 280683
Conteúdo: Metilacetileno e propadieno, Conteúdo: Gás tipo Propano/Butano
hidrocarbonetos e propano Capacidade: 300ml | 600ml
Capacidade: 453g Filtrado 11 vezes
UN - 7899733820664 300ml - 12pçs. - UN - 7896558460891
300ml - 6pçs. - UN - 7896558467739
600ml - 6pçs. - UN - 7896558467746
42

---

Artefatos à gás
Adaptador p/ Campgás Camisa P/ Lampião
280690 1 amarra - 281000
2 amarras - 281050
Material: Alumínio e plástico Material: Rayon anti-radioativo
Permite utilizar cartuchos campgás em Potência: 100 velas
equipamentos que usam Tekgás 1 AMARRA: UN - 7896558417383
Medidas: 5 x 5,6 cm 2 AMARRAS: UN - 7896558411459
Peso: 33,1 g
UN - 7896558464738
Griller Escudo
282000 M - 282001
G - 282002
Tamanho M
Tamanho G
Material: Alumínio com revestimento anti-aderente Material: Alumínio
Diâmetro: 32 x 32 x 4cm Medidas: M: 75 x 24cm | G: 148x24cm
UN: 7896558419158 Peso: M: 240g | G: 433g
M - PT: 7896558460723
G - UN: 7896558465971`,
  "🪑 Móveis e Cadeiras": `Móveis
Stool Izy Spacio
290100 290108 290150
Material: Poliéster Oxford reforçado e base de aço Material: Plástico Material: Poliéster Oxford 600D e estrutura em aço
esmaltado Medidas: 24,6 x 6,1 - 44,5cm | Peso: 1kg Medidas: 35 x 28 x 41cm
Medidas: 32 x 32 x 40cm | Peso: 1kg Peso suportado: 120kg Peso: 1,4kg
Peso suportado: 80kg UN - 7896558464073 Peso suportado: 120kg
PR - 7896558416591 | AZ - 7896558421847 CZ - 7896558457938
Verão Pocket
290202 290375
Material: Textilene e tubo de alumínio de 22mm Material: Tubos de aço e tecido de poliéster 600D
Medidas: 69 x 60,5 x 24 - 83cm com áreas teladas
Peso: 2,75kg Medidas: 52 x 52 x 61,5cm | Peso: 1,4kg
Peso suportado: 90kg Peso suportado: 90kg
BC - 7896558460716 | AZ - 7896558460709 AZ - 7896558459697
PR - 7896558468019 PR - 7896558491352
Compact Alvorada Boni
290378 290380 290430
Material: Tecido em poliéster 600D e estrutura em Material:Poliéster Oxford reforçado e base de aço Material: Poliéster Oxford com duplo estofado
tubos de aço esmaltado (reforçado) e base em aço esmaltado
Medidas: 65 x 53 x 87cm | Peso: 1,89kg Medidas: 55 x 80 x 77cm | Peso: 2,8kg Medidas: 89 x 52 x 91cm | Peso: 3,5kg
Peso suportado: 90kg Peso suportado: 80kg Peso suportado: 95kg
AZ - 7896558459703 PR - 7896558414634 | VD - 7896558421908 PR - 7896558417369
AZ - 7896558421892 AZ - 7896558421939
Pandera Diretor Astra
290500 291013
Material: Poliéster Oxford reforçado e base em aço Material: Estrutura em aço e tecido em poliéster
esmaltado 600D
Medidas: 84cm x 60cm x 1m | Peso: 4,5kg Medidas: 60 x 57 x 93cm | Peso: 4,3kg
Peso suportado: 95kg Peso suportado: 125kg
CZAZ - 7896558491222 AZ - 7896558491451
PR - 7896558418731

---

Móveis
Andrade
P - 291014
G - 291016
Material: Tubos de aço, tecido em poliéster 600D, polímero e acabamento em madeira
Medidas: P: 44 x 55 x 63cm | G: 53 x 55 x 79cm
Peso: P: 2,3kg | G: 2,9kg
Peso suportado: 95kg
P: PR - 7896558459758 | BG -7896558459642 | PRPR - 7896558464585
G: PR - 7896558459765 | BG -7896558459659 | PRPR - 7896558462796
Gravity Esteira
291020 291023
Material: Tecido em teslin 2x1 e estrutura em aço Material: Poliéster 600x300D com revestimento em
Medidas: 9 x 13,5cm poliuretano e poliéter 210D
Peso: 7kg Medidas: 161 x 53cm
Peso suportado: 120kg Peso: 1,2kg
AZ - 7896558455170 | PR - 7896558468019 AZESC - 7896558462437
Tatu Kayman
Coluna
Solteiro - 291025 d’água 291030
Casal - 291026 3000mm
Material: Estrutura em aço e tecido em poliéster Oxford 210D e proteção UV Material: Poliéster Oxford reforçado bi-color e
Medidas: Solteiro: 2,1m x 80cm x 1,2m | Casal: 2,1m x 1,2 x 1,2m estrutura em aço esmaltado
Peso: Solteiro: 11kg | Casal: 18kg Medidas: 65cm x 1,86m x 25cm
Peso suportado: Solteiro: 120kg | Casal: 250kg Peso: 5,2kg
Solteiro: UN - 7896558440053 Peso suportado: 90kg
Casal: UN - 7896558440886 UN - 7896558430047
46

---

Móveis
Dream Arkadia
291031 291035
Material: Estrutura de aço e tecido de poliéster 600D Material: Tecido de poliéster oxford ripstop reforçado
Medidas: 1,9 x 70 x 35cm e estrutura em aço esmaltado
Peso: 6,3kg Medidas: 64,5cm x 1,89m x 43cm
Peso suportado: 120kg Peso: 7kg
CZ - 7896558463670 Peso suportado: 100kg
UN - 7896558431037
Frade
Material: Tubos e painéis em aço
90cm - 291036 Medidas: 90cm: 90 x 60 x 44cm | 120cm: 120 x 60 x 44cm | G: 5,7kg
Peso: 90cm: 4,3kg | 120cm: 5,7kg | G: 1,1m x 70cm x 70cm
120cm - 291037 90cm: UN - 7896558459666
G - 291038 120cm: UN - 7896558459673
G: PR - 7896558463687 | BG - 7896558463694
Royal Lunch Domo
291050 291079 291080
Material: Estrutura e bancos de alumínio e tampa de Material: Estrutura em alumínio e tampo em MDF Material: Estrutura de alumínio, tampa de MDF
MDF aluminizado Medidas: 60 x 45 x 26-56cm aluminizado e tecido oxford nos bancos
Medidas: 70,5 x 11,5cm Peso: 2kg Medidas: Mesa: 90 x 60 x 70cm | Bancos: 28,5 x 26 x
Peso: 9,7kg Peso suportado: 30kg 39cm | Peso: 5,1kg
Peso suportado: 85kg (cada banco) UN - 7896558460877 Peso suportado: 100kg (cada banco)
UN - 7896558427429 UN - 7896558429829

mc06 mc06
mc07

---

Móveis
Trucker Top
291085 291100
Material: Aço carbono Material: Estrutura de alumínio, tampa de MDF
Medidas: Aberta: 90 x 60 x 42-66cm aluminizado e organizador (prateleira) de poliéster
Fechada: 61 x 47 x 7cm oxford reforçado
Peso: 3kg Medidas: 1,20m x 60cm x 70cm | Peso: 5kg
UN - 7896558467845 Peso suportado: 40kg
UN - 7896558427436
Robust 80 Robust 120 Robust 180
291101 291102 291104
Material: Tampo em polietileno de alta densidade e Material: Polietileno de alta densidade Material: Polietileno de alta densidade
estrutura em aço esmaltado Medidas: 1,20m x 52,5cm x 60cm | Peso: 7,8kg Medidas: 1,80m x 70cm x 74cm | Peso: 12kg
Medidas: 80 x 50 x 50/62/74cm | Peso: 4,1kg Peso suportado: 50kg Peso suportado: 100kg
PR - 7896558462307 PR - 7896558460631 PR - 7896558460648
BC - 7896558460624 UN -7896558459734 UN -7896558459727
Toalha p/ mesa Robust Bistrô Cadeira
Robust 180 291108 Robust
291107 291110
Material: Tecido elástico de poliéster 170GSM Material: Tampo em polietileno de alta densidade e Material: Polipropileno e estrutura em aço
Medidas: 183 x 76 x 76cm estrutura em aço esmaltado Medidas: 45 x 42,5 x 80,5cm | Peso: 3,3kg
Peso: 600g Medidas: 80 x 50 x 1,1m | Peso: 6,9kg BC - 7896558463410
BC - 7896558466084 PR - 7896558464318
PR - 7896558466091
Cadeira Banco
Robust Robust Bench
Rattam 291114
291111
Material: Polipropileno e estrutura em aço Material: Tampo em polietileno e pernas em aço
Medidas: 46 x 53 x 83cm | Peso: 4,2kg esmaltado
MR - 7896558464332 Medidas: 1,83 x 28 x 43cm
Peso: 7,2kg
BC - 7896558464356
PR - 7896558464349
48

---

Móveis
Cucina Serena
291138 291140
Material: Tampo em MDF, pernas em alumínio e Material: Tampo em MDF, pernas em alumínio e
gabinete em poliéster 600D tecido em poliéster Oxford 600D
Medidas: 90cm x 49cm x 1,11m Medidas: 1,46m x 46cm x 80cm
Peso: 9kg Peso: 8,8kg
AZ - 7896558463700 Peso suportado: 30kg
UN - 7896558449735
Lua Mobi
291145 291147
Material: Lona em poliéster Oxford e estrutura em Material: Poliéster 600D e estrutura em aço
aço com pintura epóxi Medidas: 60 x 40 x 39cm
Medidas: 71 x 61 x 51cm Peso: 1,15kg
Peso: 2,4kg Peso suportado: 25kg
Peso suportado: 25kg PR - 7896558464578
PR - 7896558460419
Sink Harpia Suporte p/ rede
291150 293050 293055
Material: Tampo em polímero resistente e pernas em Material: Rede em poliamida 210T, estrutura de fibra Material: Tubos de aço e pés emborrachados
aço esmaltado de vidro e mosquetões em aço cromado Medidas: 1,5 x 1 x 1,15m
Medidas: 1,16m x 60cm x 86cm Medidas: 3m x 1,45m Peso: 2kg
Peso: 12,2kg Peso: 830g Peso suportado: 150kg
Peso suportado: 68kg Peso suportado: 200kg UN - 7896558463434
UN - 7896558443016 VD - 7896558441401`,
  "🧰 Acessórios Camping": `Acessórios
Fole Dupla Ação Blow Recarregável Triplo (110 / 220
300820 300825 USB / 12V)
300851 300853
Material: Plástico ABS Material: Plástico Material: Plástico ABS Material: Plástico ABS e PS
Medidas: 23 x 11,5 x 45,5cm Medidas: 10,8 x 8,8 x 30cm Medidas: 9,5 x 8,2 x 11,05cm Medidas: 12 x 10 x 11cm
Peso: 700g Peso: 266g Peso: 340g Peso: 383g
UN - 7896558412333 Pressão: 0.28 bar (4 PSI) Pressão: 0.58 PSI Pressão: 0.33 PSI
Infla 850ml por ciclo Fluxo de ar: 280L/min. Fluxo de ar: 170L/min.
UN - 7896558462468 UN - 7896558464745 UN - 7896558464752
Inflador 12V Inflador elétrico Camuflado
300855 220V - 300890 301200
Material: Plástico ABS e PS Material: Plástico ABS Material: Alumínio inodoro e capa de
Medidas: 12 x 10 x 11,5cm Medidas: 15 x 13 x 11cm algodão com poliamida
Peso: 283g Peso: 716g Peso: 277g
Pressão: 0.49 PSI Pressão: 0.52 PSI Capacidade: 900ml
Fluxo de ar: 260L/min. 220V: UN - 7896558413859 UN - 7896558418670
UN - 7896558464769
Plástico Flecha Apache Mohave
301220 301230 301235 301240
Material: Plástico PP e capa de algodão Material: Plástico PP inodoro, revestido Material: Cantil em polipropileno Material: Plástico PP inodoro e
com poliamida com folha de aço galvanizado e manta atóxico, capa em algodão com revestimento com poliéster oxford
Peso: 170g isolante de poliéster poliamida Peso: 190g
Capacidade: 900ml Peso: 300g Peso: 320g Capacidade: 750ml
PR - 7896558427351 Capacidade: 1,9l Capacidade: 1 litro UN - 7896558420253
VD - 7896558411084 UN - 7896558417659 VD - 7896558443191
Xepa Ark Onix
301262 301265 301268
Material: Alumínio atóxico e capa de Material: Polietileno e capa térmica de Material: Plástico polipropileno, aço
algodão com poliamida com alça poliéster galvanizado e manta em poliéster
escamoteável Peso: 400g Peso: 370g
Peso: 270g | Capacidade: 900ml Capacidade: 1,8l Capacidade: 1,9 litros
PR - 7896558444693 VD - 7896558462468 PR - 7896558449544
UN - 7896558430801

---

Acessórios
Gallon 10l Flask 500ml
301270 301272
Material: Polietileno colapsável Material: Poliuretano termoplástico
Medidas: 26 x 23 x 23cm (TPU)
Peso: 220g Medidas: 24,5 x 7cm
Capacidade: 10 litros Peso: 28g
UN - 7896558463526 UN - 7896558463533
Hidrabag 2L com Hidrabag 2L com Clorin 1mg King
abertura tampa 301290 301311
301281 301282
Material: ABS, PE, POM, PVC, silicone, Material: ABS, PE, POM, PVC, silicone, Principio ativo: Dicloro-S-Triazinetrione Material: Aço inoxidável
SUS 304 e TPU SUS 304 e TPU de sódio Medidas: 10 x 17,5 cm
Medidas: 33 x 17 cm Medidas: 39 x 18 cm Teor de cloro ativo: 1% Peso: 351g
Peso: 162g Peso: 220g UN- 7897101400104 Capacidade: 710ml
Capacidade: 2 litros Capacidade: 2 litros PR - 7896558457822
UN - 7896558467302 UN - 7896558467302 AZ - 7896558455361
Avalon Siluet
301319 301322
Material: Aço inoxidável 304 Material: Aço inoxidável 304
Medidas: 7,2 x 17,4 cm Medidas: 7,5 x 19,4cm
Peso: 349g | Capacidade: 570 ml Peso: 430g | Capacidade: 850ml
BC - 7896558457594 | CZ - 7896558455361 PR - 7896558455156
PR - 7896558451714 | RS - 7896558457600 TURQ - 7896558453497
VD - 7896558450311
Isomax Rocket
750ml - 301336
1L - 301337
Material: Aço inoxidável e polímero
Medidas: 750ml: 8,4Ø x 24,5cm | 1 litro: 9,2Ø x 27,5cm
Peso: 750ml: 374g | 1 litro: 438g
750ml: AZ - 7896558649593 | PR - 7896558649609
1 litro: AZ - 7896558649579 | PR - 7896558649586
52

---

Acessórios
Isomax Straw 710ml
301341
Material: Aço inox 30, PP e silicone
Medidas: 8,2Ø x 28cm
Peso: 500g
AM - 7896558468668 | BG - 7896558468699 |
AZ - 7896558468682 | VD - 7896558468675
PR - 7896558468651
Tampa Isomax Color
Isomax 550ml - 301351
Straw 750ml - 301354
1 litro - 301353
301345
Material: Aço inox 18/8 e partes em polímero
Material: PP e silicone Medidas: 550ml: 21 x 7cm | 750ml: 24 x 7cm | 1 litro: 25 x 8cm
CZ - 7896558649227 Peso: 550ml: 310g | 750ml: 420g | 1 litro: 525g
550ml: AZAZ - 7896558466039 | VDVD - 7896558466022
750ml: AZAZ - 7896558466053 | VDVD - 7896558466046
1 litro: AZAZ - 7896558466077 | VDVD - 7896558466060
Isomax
550ml - 301356
750ml - 301357
1 litro - 301358
Material: Aço inox 18/8 e partes em polímero
Medidas: 550ml: 21 x 7cm | 750ml: 24 x 7cm | 1 litro: 26 x 7cm
Peso: 550ml: 310g | 750ml: 420g | 1 litro: 480g
550ml: AZ - 7896558460310 | PINK - 7896558460303 | PR - 7896558460297 | VD - 7896558460327 | AZCL - 7896558464431 | RX - 7896558464424
750ml: AZ - 7896558460358 | PINK - 7896558460341 | PR - 7896558460334 | VD - 7896558460365 | AZCL - 7896558464448 | RX - 7896558464455
BC - 7896558465537 | LJ - 7896558465957 | AZMAR - 7896558468873 | AM - 7896558649418 | PRPR - 7896558468866
1 litro: AZ - 7896558460396 | PINK - 7896558460389 | PR - 7896558460372 | VD - 7896558460402 | AZCL - 7896558464479 | RX - 7896558464462
BC - 7896558465544 | LJ - 7896558465964 | AZMAR - 7896558468897 | PRPR - 7896558468880
Tampa Isomax Growler 1,9l Tampa Isomax 2 Isomax 1,5L
301359 301360 301361 301362
Material: Polipropileno Material: Aço inoxidável 304 e 201 Material: Polímero Material: Parte interna em aço
Peso: 74g Medidas: 12,5 x 29,2cm Medidas: 10 x 10 x 5cm inoxidável 304 e parte externa em aço
PR - 7896558463373 Peso: 897g Peso: 78g inoxidável 201
VD - 7896558463342 PR - 7896558468125 Medidas: 32,5 x 12Øcm
PR - 7896558465568 VD - 7896558649692 Peso: 819g
BC - 7896558467012 PR - 7896558468378

---

Acessórios
Isomax Kids 2 Teen Tritan Kids Tour
301371 301375 301380 301700
Material: Aço inoxidável 304 e 201 Material: Aço inoxidável e partes em Material: Plástico polipropileno e partes Material: Plástico ABS
Medidas: 7,3Ø x 19cm polímero emborrachadas PEso: 90g
Peso: 250g Medidas: 7,5 x 18,7cm Medidas: 7 x 20,5cm UN - 7896558411640
AZ - 7896558467210 Peso: 265g Peso: 160g
RS - 7896558467227 RX - 7896558463830 AZ - 7896558463830
VD - 7896558467234
Isobike 600ml Quest Mapa
301400 301720 301750
Material: Corpo em PP e isolamento em EPE Material: Plástico ABS Material: Plástico ABS e base acrílica
Medidas: 7,3Ø x 25,8cm Peso: 90g Peso: 100g
Peso: 110g UN - 7896558413682 UN - 7896558416577
PR - 7896558468040 | BC - 7896558468057 | AZ - 7896558468064
CZ - 7896558468736
Image Ranger Hunter 8x21mm
301760 301765 301780
Material: Plástico ABS e base acrílica Material: Plástico ABS e base metálica Material: Polímero com revestimento
Peso: 120g Peso: 150g PU e lentes de cristal/policarbonato
UN - 7896558416720 UN - 7896558429799 Medidas: 5 x 11 x 8cm
Peso: 180g
UN - 7896558413644
54

---

Acessórios
Bird 10x25mm Águia 7x35mm Tucano 8x40mm
301800 301820 301840
Material: Polímero com revestimento Material: Polímero com revestimento Material: Polímero com revestimento
PU e lentes de cristal/policarbonato PU e lentes de cristal/policarbonato PU e lentes de cristal/policarbonato
Medidas: 6 x 13 x 9cm Medidas: 9 x 22 x 18cm Medidas: 18 x 15,5 x 6cm
Peso: 180g Peso: 750g Peso: 549g
UN - 7896558415556 UN - 7896558416706 UN - 7896558416713
Pelicano Luz Química Camp Kit Bolsas
7x50mm 301950 302150 Impermeáveis
301860 302250
Material: Polímero com revestimento Material: Plástico PP translúcido Material: Aço galvanizado reforçado Material: Plástico PVC soldado
PU e lentes de cristal/policarbonato Medidas: 13cm Medidas: 18 cm / Cordinhas 2,80m eletrônicamente
Medidas: 8 x 20 x 20cm Peso: 100g Peso: 100g Medidas: 12 cm x 17 cm / 17 cm x 25 cm
Peso: 1kg UN - 7896558421441 UN - 7896558417376 / 26 cm x 34 cm
UN - 7896558426293 Peso: 130g
UN - 7896558416317
Saco de Cobertor de Mosquetão - Par
Emergência Emergência 6mm - 302350
302270 302271 8mm - 302400
6mm
8mm
Material: PET (polímero termoplásitco Material: PET (polímero termoplásitco Material: 100% Alumínio anodizado
tipo Tereftalato de Etileno) aluminizado tipo Tereftalato de Etileno) aluminizado Medidas: 6 e 8mm
Medidas: 2,08m x 1,32m Medidas: 2,08m x 1,32m 6mm: UN - 7896558416249
Peso: 45g Peso: 45g 8mm: UN - 7896558416256
UN - 7896558431099 UN - 7896558462673
Magni Serrucho Bastão de Bastão
302480 302490 Caminhada T Grip
302500 302501
Material: Aço com liga especial de Material: Tungstênio Material: Corpo em duralumínio, Material: Corpo em al`,
  "🔦 Iluminação": `Iluminação
EnergyStation 300W EnergyStation 600W
310003 310006
Material: ABS + PC Material: ABS + PC
Medidas: 24,8 x 16,4 x 15cm | Peso: 3,65kg Medidas: 30,1 x 22,7 x 19,3cm | Peso: 7kg
Características: Duas entradas USB-A 12W, duas entradas USB-C 65W, uma Características: Duas entradas USB-A 12W, duas entradas USB-C 100W, duas
entrada para tomada comum (AC) 127V e uma entrada 12V 100W. Possui alça para entradas para tomada comum (AC) 127V e uma entrada 12V 120W. Possui alça para
carregar e display LCD com tempo de uso e recarga. carregar e display LCD com tempo de uso e recarga.
UN - 7908216140134 UN - 7908216140141
Dive Panter Tida Dragster 2.0
Com
sensor de
310151 310345 movimento 310370 310381
Material: Plástico ABS e alumínio Material: Plástico ABS e botões Material: Corpo em ABS Material: Corpo em ABS e interruptor
Medidas: 4,3Ø x 19,5cm emborrachados Medidas: 10 x 10 x 10cm em borracha
Peso: 120g Medidas: 6,6 x 4,6 x 4cm Peso: 50g Medidas: 5,6 x 4 x 4,5cm | Peso: 42g
Potência: 160 lúmens Peso: 89g Potência: 20 lúmens Potência: 180 lúmens
Usa 4 pilhas AA (não inclusas) Potência: 250 lúmens | Recarregável Usa 2 baterias CR2032 de 3v Usa 3 pilhas AAA não inclusas
UN - 7896558468712 UN - 7896558464608 UN - 7896558440848 UN - 7896558460259
Boost Fiji Ciclop Dual
Com
310385 310390 310395 sensor de 310396
movimento
Material: Plástico PP, policarbonato e Material: Corpo em ABS com cinta Material: Corpo em ABS com faixa Material: Corpo em ABS e fita em
botão de acionamento em PVC elástica elástica poliéster
Medidas: 8 x 17 x 12cm | Peso: 70g Medidas: 6 x 3 x 6cm | Peso: 72g Medidas: 30 x 3,2 x 2cm Medidas: 67 x 46 x 38mm | Peso: 80g
Potência: 130 lúmens | Usa 3 pilhas AAA Potência: 90 lúmens Peso: 64g Potência: até 400 lúmens
(não inclusas) Usa 3 pilhas AAA (não inclusas) Potência: 270 lúmens | Recarregável Híbrido: Recarregável ou 3 pilhas AAA
UN - 7896558435967 UN - 7896558440855 UN - 7896558460761 UN - 7896558467791
Ravi Vento Fan
310397 310575 310581
Material: Corpo em ABS com botão em Material: Plástico ABS Material: Plástico PP
borracha Medidas: 11,5 x 11,5 x 20,5 cm Medidas: 19 x 15 x 12cm
Medidas: 6,8 x 3,8 x 5,5cm Peso: 510g | Potência: 400 lúmens Peso: 260g
Peso: 54g Recarregável UN - 7896558460778
Potência: 190 lúmens | Recarregável Função Power Bank
UN - 7896558465773 UN - 7896558449674

---

Iluminação
Comet Radiant Toledo
310651 310652 310654
Material: Corpo em plástico ABS Material: Plástico ABS, policarbonato Material: Plástico ABS
Medidas: 10,8 x 3,7cm e aço Medidas: 6,5 x 6,5 x 11cm | Peso: 120g
Peso: 208g Medidas: 10,5 x 10,5 x 15cm Potência: 150 lúmens
Potência: Inferior: 250 lúmens | Superior: 150 lúmens Peso: 170g Usa 3 pilhas AAA (não inclusas)
Recarregável. Possui fita Led de 10 metros Potência: 250 lúmens | Recarregável UN - 7896558457570
UN - 7896558464615 UN - 7896558460921
Keyled Table Light Trap Light Lanterna
310657 310658 310659 de pescoço
310661
Material: Corpo em alumínio com Material: Corpo em metal de alta Material: Corpo em plástico ABS e Material: Corpo em ABS e braços em
suporte em plástico qualidade com abajur de plástico botões emborrachados borracha
Medidas: 10,5 x 10,5 x 15cm Medidas: 8 x 8 x 34,5cm | Peso: 340g Medidas: 7 x 8,5 x 13,4cm | Peso: 226g Medidas: 20 x 24cm
Peso: 170g Potência: 40 lúmens | Recarregável Potência: 200 lúmens | Recarregável Peso: 143g
Potência: 250 lúmens | Recarregável BC - 7896558461010 Lâmpada mata mosquitos Potência: 80 lúmens | Recarregável
UN - 7896558460785 PR - 7896558461027 UN - 7896558462291 UN - 7896558465049
Tocha 12v Hilux Gama Monster
310800 310802 310804 310821
Material: Corpo em plástico ABS e lente Material: Plástico ABS, policarbonato e Material: Plástico ABS, policarbonato, Material: Plástico ABS
em policarbonato poliamida PA6 PVC e alumínio Medidas: 18 x 10 x 13cm
Medidas: 4 x 24 x 14cm Medidas: 9 x 16 x 18cm Medidas: 9 x 16 x 18cm Peso: 650g
Peso: 680g Peso: 350g Peso: 350g Potência: 1.500 lúmens | Recarregável
Potência: 1.500.000 velas | Usa cabo 12V Potência: 200 lúmens | Recarregável Potência: 1.500 lúmens | Recarregável Função Power Bank
UN - 7896558412777 UN - 7896558460938 UN - 7896558460945 UN - 7896558449650
Jasper Pen Led 16 pçs. Spectra 12 pçs. Canon 12 pçs.
310824 310889 310895 313008
Material: Corpo em plástico e pintura
Material: Corpo em plástico ABS e Material: Corpo em alumínio anodizado Material: Alumínio anodizado
emborrachada
punho non-slip Medidas: 135 x 15cm Peso: 150g
Medidas: 12,3 x 4 x 3cm | Peso: 48g
Medidas: 15 x 16 x 24cm | Peso: 480g Peso: 27g Potência: 100 lúmens
Potência: 100 lúmens
Potência: 350 lúmens | Recarregável ou Potência: 100 lúmens Usa 3 pilhas AAA (não inclusas)
Usa 3 pilhas AAA (não inclusas)
3 pilhas AA (não inclusas) Usa 2 pilhas AAA (não inclusas) UN - 7896558435950
UN - 7896558459468
UN - 7896558442668 UN - 7896558459611
60

---

Iluminação
Hunter Kripton 500 Kripton 1000 Kripton 1500
313040 313049 313052 313054
Material: Corpo em alumínio anodizado Material: Corpo em alumínio anodizado Material: Corpo em alumínio anodizado Material: Alumínio
Medidas: 3,3 x 3,3 x 15,5cm | Peso: 170g Medidas: 12cm | Peso: 85g e botão Medidas: 41 x 155mm
Potência: 350 lúmens Potência: 500 lúmens Medidas: 18 x 4,2cm Peso: 161g
Recarregável Usa 3 pilhas AAA (não inclusas) Peso: 215g Potência: até 1500 lúmens
UN - 7896558468729 UN - 7896558459628 Potência: 1.000 lúmens | Recarregável Recarregável
UN - 7896558459635 UN - 7896558467807
Ranger Fenix Cobb Adaptador 12V
313056 313400 313450 316200
Material: Corpo em ABS Material: ABS e policarbonato Material: Corpo em plástico ABS com Material: Plástico e aço cromado
Medidas: 7,3 x 20,5cm Medidas: 8,3 x 4,4cm cinta elástica Comprimento do cabo: 50cm
Peso: 186g Peso: 80g Peso: 65g Peso: 105g
Potência: LED: 120 lúmens | COB: 160 Potência: LED: 300 lúmens | COB: 200 Potência: 150 lúmens UN - 7896558437344
lúmens | Recarregável lúmens | Recarregável Usa 3 pilhas AAA (não inclusas)
UN - 7896558465056 UN - 7896558456542 UN - 7896558442705`,
  "🗡️ Cutelaria": `Cutelaria
Indian Potro Mini Canivete
320100 320120 320200
Material: Lâmina de aço inox e cabo de Material: Lâmina de aço inox e cabo Material: Lâmina de aço e cabo de
madeira trabalhado madeira trabalhada
Medidas: Fechado 11,4cm / Lâmina 9cm Medidas: Fechado 10cm / Lâmina Medidas: Lâmina 3,8cm / Aberto 8cm
/ Aberto 20,4cm 8,5cm / Aberto 18,5cm Peso: 18g
Peso: 94g Peso: 145g UN - 7896558427962
UN - 7896558415631 UN - 7896558439224
Thunder Stelt Stop Slak
320205 320210 320215 320220
Material: Lâmina de aço inoxidável e Material: Lâmina tipo turca forjada Material: Lâmina de aço inoxidável e Material: Lâmina tipo turca forjada
cabo em alumínio artesanalmente cabo em alumínio artesanalmente e cabo com pintura
Medidas: Cabo: 9,3cm / Lâmina 7cm / Medidas: Cabo 9,3cm / Lâmina 7cm / Medidas: Fechado: 9,3cm / Lâmina 7cm camuflada
Aberto 16,3cm Aberto 16,3cm / Aberto 16,3cm Medidas: Fechado 9,3cm / Lâmina 7cm
Peso: 51g Peso: 74g Peso: 46g / Aberto 16,3cm
UN - 7896558430993 UN - 7896558429898 UN - 7896558430979 Peso: 81g
UN - 7896558429904
Pointer Closer Skaf Box
320260 320320 320330 320450
Material: Lâmina de aço inox e cabo de Material: Lâmina de aço inox e corpo Material: Lâmina de aço com pintura Material: Lâmina de aço inoxidável,
aço inox de alumínio anodizado especial e cabo de alumínio anodizado corpo de alumínio e madeira
Medidas: Fechado 11,4cm / Lâmina Medidas: Fechado 11,5cm / Aberto: texturizado Medidas: Fechado 7,5cm / lâmina 5cm /
8,7cm / Aberto 20,1cm 20cm / Lâmina 8,5cm Medidas: Fechado 11,5cm / Lâmina aberto 12,5cm
Peso: 135g Peso: 129g 8,5cm / Aberto 20cm Peso: 125g
UN - 7896558418823 UN - 7896558430955 Peso: 90g UN - 7896558415655
UN - 7896558422332
Zeus Bulldog Balleno
320550 320930 321041
Material: Lâmina de aço inox e cabo Material: Lâmina de aço inox e cabo Material: Lâmina de aço inoxidável
emborrachado de inox com borracha texturizada forjado a 440ºC e cabo emborrachado
Medidas: Total 9cm antideslizante antideslizante
Peso: 105g Medidas: Fechado 11,5cm Medidas: Total 24cm / Lâmina 12,8cm /
UN - 7896558415693 Peso: 267g Cabo 11,2cm
UN - 7896558417574 Peso: 180g
UN - 7896558431174

---

Cutelaria
Dorff Attack Scorpion
321050 321100 321140
Material: Lâmina de aço inoxidável e Material: Lâmina de aço inox e cabo de Material: Aço forjado a 440º
bainha de poliéster oxford madeira e couro prensado centígrados
Medidas: Total 25,1 cm / Lâmina 14,3 cm Medidas: Total 30,5cm / Lâmina 18cm / Medidas: Lâmina 18,1cm / Total 30,6cm
/ Cabo 10,8cm Cabo 12,5 cm / Cabo 12,5cm
Peso: 206g Peso: 293g Peso: 343g
UN - 7896558431167 UN - 7896558426538 UN - 7896558429935
Platoon EDC Matão Juliet
321161 321163 321260 321401
Material: Lâmina de aço inox e cabo de Material: Lâmina em aço inox 420C e Material: Lâmina de aço carbono e Material: Aço M390
alumínio texturizado e anti-derrapante cabo em polímero PMMA cabo de plástico polipropileno Medidas: Aberto: 18,9cm | Fechado:
Medidas: Total 35,4cm / Lâmina 20,9cm Medidas: Total: 16 x 3,5cm / Lâmina: 7,4 Medidas: Total 57,1 cm / Lâmina 45,4 cm 11,2cm
/ Cabo 14,5cm x 3,5cm / Cabo: 8 x 2,5cm / Cabo 11,7cm Peso: 62g
Peso: 449g Peso: 86g Peso: 387g UN - 7896558462321
UN - 7896558415709 PR - 7896558460792 UN - 7896558420734
Magaiver Dan Pá com Picareta
322015 322020 322100
Material: Aço inoxidável e cabo em Material: Corpo em aço inox e cabo de Material: Corpo de aço revestido com
alumínio borracha texturizado e anti-deslizante pintura antioxidante tipo epóxi
Medidas: 17,3 x 8,8cm Medidas: Total 34cm / Lâmina 7,5cm | Medidas: Fechado 17cm / Aberto 40cm
Peso: 370g Peso: 841g Peso: 612g
UN - 7896558462338 UN - 7896558418915 UN - 7896558413675
Timber Jump
322200 322300
Material: Aço inox com cabo de ABS Material: Aço inoxidável 420ss
Medidas: 14 cm Medidas: Lâmina: 8 cm | Cabo: 10,3 cm |
Peso: 134g Total: 18,3 cm
UN - 7896558413866 Peso: 132g
UN - 7896558442897
64`,
  "🔧 Utilidades": `Utilidades
Camp Lub NTKleaner Smash
24 pçs. 331100 335001
331000
Composição: Polidimetilsiloxano, plastificante, sílica Composição: Tensoativo não iônico, alcalinizante, Material: Aço
e silano coadjuvante, fragrância, corante e veículo Medidas: 32,5 x 12 x 8cm
Peso: 180g Conteúdo: 1 litro Peso: 1kg
UN - 7896558460907 UN - 7899664803927 UN - 7896558462345
Step 1 Step 2
336000 336002
Material: Polipropileno Material: Polipropileno
Medidas: 33 x 28 x 23cm Medidas: 39 x 29 x 22cm
Peso: 700g Peso: 1,6kg
Peso suportado: até 120kg Peso suportado: até 150kg
VD - 7896558462611 PR - 7896558462628
Tool Belt Patrol M Tool Belt Patrol G Tool Bag Patrol G
336100 336102 336106
Material: Poliéster 600D e PVC Material: Poliéster 600D Material: Poliéster 600D e plástico
Medidas: 17 x 28cm Medidas: 25 x 4 x 18,5cm Medidas: 44 x 25 x 28cm
Peso: 90g Peso: 175g Peso: 375g
PRLJ - 7896558464363 PRLJ - 7896558464370 PRLJ - 7896558464387
Caixa Camp Boxx P Caixa Camp Boxx G
337001 337003
Material: Plástico polipropileno e madeira em MDF Material: Plástico polipropileno e madeira em MDF
Medidas: Externa: 43 x 28 x 24,5cm Medidas: Externa: 51 x 34,5 x 29,5cm
Interna: 36 x 24 x 22cm Interna: 43,5 x 30,5 x 27cm
Peso: 1,95kg Peso: 2,8kg
BC - 7896558464400 BC - 7896558464417
66

---

Utilidades
Giro Kit organizador
338001 7 peças
Material: Plástico polipropileno 338010
Medidas: 54 x 34 x 20cm | Peso: 2,8kg
AZESC - 7896558464509
PT - 7896558464516
Material: Fibra de poliéster
Medidas: 40 x 30 x 14cm | 30 x 20 x 11cm |
30 x 27 x 12cm | 26 x 17cm | 35 x 21 x 11cm
Peso: 290g
UN - 7896558466107`,
  "⛺ Gazebos e Tendas": `Gazebos
Camp Fiesta Fantasy
350060 350100 350120
Material: Teto: 100% Polietileno impermeabilizado | Material: Teto 100% em polietileno impermeabilizado Material: Teto 100% em polietileno impermeabilizado
Esturutura: Tubos de aço tratados com pintura epóxi aluminizado e estrutura em tubos de aço esmaltado e estrutura em tubos de aço esmaltado
Medidas: Base: 3 x 3m | Teto: 2,4 x 2,4m | Altura: 2,4m Medidas: 3 x 3 x 2,5m (teto 3m x 3m) Teto aluminizado
Peso: 4,8kg Peso: 6,1kg Medidas: 3 x 3 x 2,5m
BC - 7896558424756 UN - 7896558460013 Peso: 6,1kg
AZ - 7896558491277 UN - 7896558413798
CZ - 7896558491284
Kit de Conexão Paxx 1.8 Paxx 2.0
351050 351818 351820
Material: Plástico polipropileno de alto impacto Material: Cobertura em poliéster 210D e estrutura em Material: Cobertura em poliéster 210D e estrutura em
Contém: 4 sapatas, 4 conectores laterais e 1 conector aço com partes em alumínio aço com partes em alumínio
central Medidas: 1,8 x 1,8 x 2,13m Medidas: 2 x 2 x 2,45m
Peso: 250g Peso: 8,1kg Peso: 8,9kg
UN - 7896558429348 Teto aluminizado Teto aluminizado
Acompanha sacola mochila para transporte PR - 7896558464202
AZ - 78965584644196
Duxx Aluxx
351970 351981
Material: Estrutura em tubo de aço e sobreteto em Material: Colunas em alumínio, treliças em aço e
poliéster 250D cobertura em poliéster oxford
Medidas: Base - 3,0m x 3,0m x 2,5m (teto 2,4m x 2,4m) Medidas: 3 x 3 x 2,5m
Peso: 10,6kg Peso: 10,1kg
Teto aluminizado Teto aluminizado
AZ - 7896558438463 AZ - 7896558463540
VD - 7896558441685 PR - 7896558463557
70

---

Gazebos
Trixx Trixx One Touch Deluxx
352000 352020 352039
Material: Cobertura em poliéster oxford e estrutura Material: Cobertura em poliéster 420D e estrutura em Material: Cobertura em poliéster 420D e estrutura
de treliça em alumínio reforçada com aço aço com colunas e pés em alumínio anodizado cinza em aço
Medidas: Base - 3,0m x 3,0m x 2,5m (teto 3m x 3m) Medidas: 3 x 3 x 2,7m Medidas: 3,85 x 3,85 x 2,8m
Peso: 10,3kg Peso: 12,5kg Peso: 15,5kg
Teto aluminizado Teto aluminizado Teto aluminizado
AZ - 7896558415129 AZ - 7896558464226 MR - 7896558464219
BC - 7896558418960
Magnixx Parede para gazebo Parede Trixx
352040 com janela 352100
352098
Material: Cobertura: 600x300 Poliester Oxford Material: Poliéster 210D Oxford revestido com PA Material: 100% polietileno com fixadores de velcro
250g/m² reforçado com PVC | Estrutura: Aço extra Medidas: 295 x 195cm Medidas: 3,0m x 1,85m
reforçado com revestimento esmaltado Peso: 500g Peso: 800g
Medidas: 3,0m x 3,0m x 2,5m altura lateral, 3,2m altura UN - 7896558468194 AZ - 7896558426453
central | Peso: 20,8kg Não acompanha a estrutura
Teto aluminizado
UN - 7896558427337
Teto Trixx Teto Trixx One Teto Duxx
352105 Touch 352108
352107
Material: Cobertura em poliéster Oxford Material: Cobertura em poliéster Oxford Material: Cobertura em poliéster 250D
Medidas: 3 x 3m Medidas: 3 x 3m Medidas: 3 x 3m
Peso: 1,3kg Aluminizado Aluminizado
Aluminizado AZ - 7896558491246 AZ - 7896558459840
AZ - 7896558447380 Não acompanha a estrutura Não acompanha a estrutura
Não acompanha a estrutura

---

Gazebos
Teto Remixx Remixx Sacola c/ rodas para
352111 353510 Trixx
353520
Material: Cobertura em poliéster Oxford reforçado Material: Cobertura: 600x300 Poliester Oxford Material: Poliéster
com PVC 250g/m² reforçado com PVC | Estrutura: Aço extra Medidas: 22,5cm x 20cm x 1,30m
Medidas: 6 x 3m reforçado com revestimento esmaltado PR - 7896558464233
Aluminizado Medidas: 6,0m x 3,0m x 2,6m (pé direito) x 2,0m
BC - 7896558462413 (lateral) | Peso: 37,9kg
PR - 7896558462420 Aluminizado
Não acompanha a estrutura BC - 7896558429805 | PR - 7896558468316
Sacola para Caribe 180cm Caribe 200cm
Trixx 354100 354200
353521
Material: Poliéster Material: Cobertura de poliéster oxford especial e Material: Cobertura de poliéster oxford especial e
Medidas: 22,5cm x 20cm x 1,30m estrutura de aço esmaltado estrutura de aço esmaltado
PR - 7896558464233 Medidas: 1,8m de diâmetro Medidas: 2m de diâmetro
Peso: 1,2kg | Não acompanha base Peso: 1,4kg | Não acompanha base
AZ - 7896558422042 AZ - 7896558422066
AZCR - 7896558429966
VDAZ - 7896558429973
Solis 1,80m
354202
Material: Estrutura em aço e fibra de vidro e tecido em poliéster com revestimento aluminizado
Medidas: 1,8Ø x 2m
Peso: 1,66kg | Não acompanha base
AZ - 7896558464783 | AZBC - 7896558464776 | COLOR - 7896558464790
72

---

Jet Disk Jet Bob Jet Uno
432000 432100 432120
Material: 100% PVC (interno) e capa em poliamida Material: 100% PVC Material: 100% PVC (interno) e poliamida reforçado
reforçada (externo) Medidas: 2,08m x 1,07m (externo)
Medidas: 1,2m x 35cm Peso: 4,7kg Medidas: 1,14m x 1,20m x 42cm
Peso: 3,1kg Peso suportado: 140kg Peso: 3,3kg
Peso suportado: 160kg (aprox.) UN - 7896558450915 Peso suportado: 160kg
UN - 7896558450908 UN - 7896558415273
Jet Duo Cabo Ski Cabo Jet
432150 432500 432550
Material: 100% PVC (interno) e capa em poliamida Material: 100% polipropileno multi-filamento “anti- Material: Material: 100% polipropileno multifilamento
reforçada (externo) estilingada” “antiestilingada”
Medidas: 1,75m x 1,2m x 46cm Medidas: 7 x 30 x 25cm | Cabo: 22m Medidas: 18m
Peso: 4,35kg Peso: 970g Peso: 550g
Peso suportado: 200kg (aprox.) UN - 7896558417567 UN - 7896558417550
UN - 7896558413873

---

Coletes
Coast Material: Poliamida 70x240 gomado e reforçado
Códigos na tabela abaixo
Código | Capacidade
463000 - 10kg - AZPR - 7896558425234
463050 - 20kg - VMPR - 7896558414665 | AZPR -
7896558425258
463100 - 30kg - VDPR - 7896558414672
VMPR - 7896558425289 | AZPR - 7896558425296
463150 - 40kg - VDPR - 7896558425319
VMPR - 7896558414689 | AZPR - 7896558425333
463200 - 50kg - VMPR - 7896558425340 | AZPR -
7896558414696
463250 - 60kg - VMPR - 7896558414702 | AZPR -
7896558425395
463300 - 70kg - VMPR - 7896558414719 | AZPR -
7896558425418
463350 - 80kg - VDPR - 7896558425449
VMPR - 7896558425432 | AZPR - 7896558414726
463400 - 90kg - VMPR - 7896558425487 | AZPR -
7896558414733
463450 - 100kg - VMPR - 7896558425500 | AZPR -
7896558425524
463500 - 110kg - VDPR - 7896558425531
VMPR - 7896558425548 | AZPR - 7896558425579
463550 - 120kg - VMPR - 7896558414764 | AZPR -
7896558414757
Atlântico Homologado
Códigos na tabela abaixo
Manta flutuante em polipropileno expandido 6mm.
Tecido em poliéster. Fechos em nylon acetal 03
fechos. Cadarço em polipropileno encorpado para
ajuste na cintura e peito. Regulagem anatômica nas
laterais e fita de segurança nas virilhas. Acabamento
em vinil preto para maior conforto e resistência
Código | Capacidade
465012 - 25kg à 35kg - AZ - 7896558452162
465014 - 35kg à 55kg - AZ - 7896558452186
465016 - 55kg à 110kg - VM - 7896558452216
AZ - 7896558452209
465018 - Acima de 110kg - VM - 7896558452230
AZ- 7896558452223

---

Vestuário
Poncho de emergência Poncho Poncho
540050 Compacto Iguazu
540080 540100
Material: Polietileno Composição: PEVA Composição: PVC laminado soldado eletronicamente
Medidas: 14 x 10cm Medidas: 127 x 203cm (sem costuras)
Peso: 50g Peso: 40g Peso: 360g
UN - 7896558426064 AZ - 7896558467876 | PR - 7896558467913 UN - 7896558422424
LJ - 7896558467890 | VD - 7896558467906 VD - 7896558412814
Conjunto Fleece Fleece
Tempest Masculino Feminino
M - 540150 P - 540600 P - 540608
G - 540151 M - 540602 M - 540610
G - 540604 G - 540612
GG - 540152
GG - 540606 GG - 540614
Composição: Poliéster Material: 100% Poliéster Material: 100% Poliéster
Com jaqueta e calça impermeáveis P: UN - 7896558463595 P: UN - 7896558463632
Tamanho M UN - 7896558467883 M: UN - 7896558463601 M: UN - 7896558463649
Tamanho G UN - 7896558468088 G: UN - 7896558463618 G: UN - 7896558463656
Tamanho GG UN - 7896558468095 GG: UN - 7896558463625 GG: UN - 7896558463663
Conjunto
Amandy
M - 540802
Material: Nylon emborrachado
M: UN - 7896558459437
Híbrido 2
Códigos abaixo
Material: solado em borracha, vulcanizado e
costurado | tecido em neoprene
Código | Numeração
547801- 38: PR - 7896558491024
547802 - 39: PR - 7896558491031
547803 - 40: PR - 7896558491048
547804 - 41: PR - 7896558491055
547805 - 4`,
  "🎣 Pesca": `AQUAROD GLADIADOR
CÓDIGOS NA TABELA ABAIXO
GLADIADOR - CAIXA C/
30PÇS.
2000 - 061010
4000 - 061020
Rolamentos: 3
Acompanha linha
Capacidade de linha:
2000 - 0,18mm/230m | 0,20mm/200m | 0,25mm/125m
4000 - 0,30mm/190m | 0,35mm/145m | 0,40mm/110m

---

DURENDAL GII As varas Durendal foram desenvolvidas com a mais moderna tecnologia em fibras de carbono.
Entre suas principais características estão: leveza, agilidade e resistência. Possuem passadores Fuji
UN e Reel Seat sensitive e anatômica. Além disso, possuem EVA de alta densidade.
As varas Durendal Travel (4 partes) podem ser transportadas inclusive como bagagem de mão em
aviões
SAVANNA NOVO
CÓDIGOS NA TABELA ABAIXO
Material: Blank em carbono IM6
82

---

NEPTUNO DURENDAL CARBON
2000 - 084010 DIREITA - 085010
4000 - 084012 ESQUERDA - 085012
6000 - 084014
Material: Corpo em alumínio e carretel em alumínio aliviado
Material: Corpo em carbono
Manivela com anti-reverso infinito
Peso: 144g
Rolamentos: 5+1
Rolamentos: 6+1BB
Drag: 9kg
Drag: 5kg
Relação de recolhimento: 2000 e 4000: 5.2:1 | 6000: 4.9:1
Relação de recolhimento: 7.2:1
Capacidade de linha:
Capacidade de linha: 0,26mm/140m | 0,28mm/120m | 0,30/130m
2000: 0,25mm/115m | 0,30mm/80m
Marinizada
4000: 0,30mm/130m | 0,35mm/100m
085010: UN - 7896558452292
6000: 0,40mm/100m | 0,45mm/90m
085012: UN - 7896558452308
2000: UN - 7896558452292
4000: UN - 7896558452308
6000: UN - 7896558452674
DURENDAL BG DURENDAL BG ULTRA
DIREITA - 085014 DIREITA - 085018
ESQUERDA - 085016 ESQUERDA - 085020
Material: Carbono e partes em polímero Material: Carbono e partes em polímero
Medidas: 15 x 10 x 10cm Material: Carbono e partes em polímero
Peso: 210g Medidas: 15 x 10 x 10cm
Rolamentos: 6+1 Peso: 240g
Drag: 16kg Rolamentos: 6+1
Relação de recolhimento: 7.2:1 Drag: 16kg
Capacidade de linha: 0,30mm/245m | 0,35/215m Relação de recolhimento: 7.2:1
085014: UN - 7896558455095 Capacidade de linha: 0,30mm/245m | 0,35/215m
085016: UN - 7896558455088 Marinizada
085018: UN - 7896558456108
085020: UN - 7896558456115

---

FISHING TRANSPORTER
BAG 089018
089010
Material: 100% Poliéster Material: PVC e nylon
Medidas: 28 x 39 x 18cm Medidas: tamanho retrátil de 1,5m a 2,10m
Peso: 800g Peso: 2,26kg
Capacidade: 30 litros Capacidade: 10 varas de pesca
PRCZ - 7896558455309 UN - 7896558464998
BAG COLLECTION BAG COLLECTION PBC ESTOJO PRAIA
089024 PRO 261109
089026 089040
Material: PVC semi-rígido e partes emborrachadas Material: PVC rígido e partes emborrachadas Material: Polímero de alta resistência
Medidas: 40 x 27x 27cm Medidas: 40 x 27x 27cm Medidas: 25,5 x 11 x 9,5cm
Peso: 750g Peso: 1,2kg Peso: 311g
Capacidade: 25 litros Capacidade: 25 litros PR - 7896558459994
Peso suportado: 6kg Peso suportado: 8kg
LJPR - 7896558459871 AZLJ - 7896558459864 | PRVM - 7896558459857
PBC ORGANIZADOR PBC ORGANIZADOR PBC MALETA 401608
160905 201105 089060
089046 089048
Material: Polímero de alta resistência Material: Polímero de alta resistência inox Material: Polímero de alta resistência
Medidas: 16 x 9 x 5cm Medidas: 20 x 11 x 5cm Medidas: 40 x 16 x 8cm
Peso: 109g Peso: 177g Peso: 287g
LJ - 7896558460020 LJ - 7896558460006 VD - 7896558459918 | LJ - 7896558459901
CZ - 7896558460037 CZ - 7896558460044
PBC MALETA 392708 PBC MALETA 392712 PBC CAIXA 452526
089062 089064 089070
Material: Polímero de alta resistência Material: Polímero de alta resistência Material: Polímero de alta resistência
Medidas: 39 x 27 x 8cm Medidas: 39 x 27 x 12cm Medidas: 45 x 25 x 26cm
Peso: 500g Peso: 750g Peso: 975g
AZ - 7896558459956 | VD - 7896558459949 AZ - 7896558459987 | VD - 7896558459970 CZ - 7896558459895
LJ - 7896558459932 LJ - 7896558459963 VDMU - 7896558459888
AZ - 7896558463564
84

---

PBC ESTOJO BAIT PBC ESTOJO BAIT PBC ESTOJO BAIT
BOX G BOX M BOX P
089075 089076 089077
Material: Polímero de alta resistência Material: Polímero de alta resistência Material: Polímero de alta resistência
Medidas: 34 x 21,5 x 5cm Medidas: 27 x 19 x 5cm Medidas: 20 x 13,5 x 3,5cm
Peso: 605g Peso: 374g Peso: 189g
LJ - 7896558467333 LJ - 7896558467357 LJ - 7896558467371
PBC ESTOJO 352205 PBC ESTOJO 271705 PBC MINI ESTOJO
089078 089079 CONECTOR
089080
Material: Polímero de alta resistência Material: Polímero de alta resistência Material: Polímero de alta resistência
Medidas: 35 x 22 x 5cm Medidas: 27 x 17 x 5cm Medidas: 8 x 12 x 2,5cm
Peso: 565g Peso: 355g Peso: 92g
LJFM - 7896558467395 LJFM - 7896558467418 UN - 7896558467432
LJTRANS - 7896558467401 LJTRANS - 7896558467425
PBC PORTA VARA PBC PORTA COPO PBC PORTA
089081 089082 ACESSÓRIOS
089083
Material: Polímero de alta resistência Material: Polímero de alta resistência Material: Polímero de alta resistência
Medidas: 29 x 4,5cm Medidas: 29 x 4,5cm Medidas: 18 x 15,5 x 5,5cm
Peso: 212g Peso: 103g Peso: 153g
UN - 7896558467449 UN - 7896558467456 UN - 7896558467463
PBC ESTOJO PBC ESTOJO PBC MALETA
MULTIUSO P MULTIUSO M 271726
140803 160903 089090
089085 089086
Material: Polímero de alta resistência Material: Polímero de alta resistência Material: Polímero de alta resistência
Medidas: 13,7 x 8 x 3cm Medidas: 16 x 9 x 3cm Medidas: 27 x 17 x 26cm
Peso: 57g Peso: 84g Peso: 1,3kg
UN - 7896558467685 UN - 7896558467692 UN - 7896558467708

---

AQUALINE
INVISIBLE NG 100M
CÓDIGOS NA TABELA AO LADO
Material: Copolímero
Medida: 100m
Peso: 370g
AQUALINE
INVISIBLE NG 500M
CÓDIGOS NA TABELA AO LADO
Material: Copolímero
Medida: 500m
ECLIPSE PRO NG 150M
CÓDIGOS NA TABELA AO LADO
Material: BRAID (fibras de polietileno)
Medida: 150m
86

---

ECLIPSE PRO NG 500M
CÓDIGOS NA TABELA AO LADO
Material: BRAID (fibras de polietileno)
Medida: 500m
ECLIPSE ULTRA NG
CÓDIGOS NA TABELA AO LADO
Material: BRAID (fibras de polietileno)
Medida: 150m
AQUALEADER
FLUORCOATING NG
CÓDIGOS NA TABELA
AO LADO
Material: BRAID (fibras de polietileno)
Medida: 150m

---

MAXFORCE NG
CÓDIGOS NA TABELA ABAIXO
Material: Fibra de vidro maciça
Vara extremamente resistente e durável
Modelo versátil para pescadores profissionais e
amadores
88

---

MAXFORCE II LISA
CÓDIGOS NA TABELA ABAIXO
Material: Fibra de Vidro Maciça
Extremamente resistente
Indicada para pesca de barranco, como Tilápia e Pacu

---

IMPACTO GII
CÓDIGOS NA TABELA ABAIXO
Material: Carbono tubular IM7
Passadores: Óxido de alumínio
90

---

BRAVUS STT
CÓDIGOS NA TABELA ABAIXO
SELVA NG MAXFORCE GEL
NOVO NOVO
CÓDIGOS NA TABELA ABAIXO CÓDIGOS NA TABELA ABAIXO
UN
Material: Blank em carbono IM6 Material: Fibra de vidro com resina em epóxi
gel transparente

---

DARK LONGO SURF PRO
CÓDIGOS NA TABELA ABAIXO CÓDIGOS NA TABELA ABAIXO
Material: Carbono tubular
Passadores: Sea Guide não corrosivos
Blank: Carbono
Casting de arremesso: 100g - 200g
Ponteira maciça (híbrida)
3 partes
SURF ULTRA SURF ELITE
CÓDIGOS NA TABELA ABAIXO CÓDIGOS NA TABELA ABAIXO
Material: Carbono tubular Material: Fibras de carbono e vidro com cabo
Passadores: Sea Guide não corrosivos em EVA
Blank: Carbono Passadores: Sea Guide não corrosivos
Casting de arremesso: 100g - 200g Blank: Carbono
Ponteira maciça (híbrida) Casting de arremesso: até 250g
3 partes ponteira maciça de óxido de alumínio
(híbrida)
3 partes
92

---

SABRE
CÓDIGOS NA TABELA ABAIXO
Material: Fibra de vidro maciça

---

CARBON GIII
CÓDIGOS NA TABELA ABAIXO
Material: Carbono IM7
Passadores: Oxido de alumínio
94

---

ORBITAL OCELOS
CÓDIGOS NA TABELA ABAIXO CÓDIGOS NA TABELA ABAIXO
Material: carretel em alumínio, Material: carretel em alumínio,
rolamentos em aço, pinhão em rolamentos em aço, pinhão em
latão maciço e engrenagens em latão maciço e engrenagens em
zamac de alto impacto zamac de alto impacto
Modelo ambidestro Modelo ambidestro
Rolamentos: 3BB + 1RB Rolamentos: 7 + 1RB
Drag: 7kg Drag: 9kg
Relação de recolhimento: 5.2:1 Relação de recolhimento: 5.5:1
ORBITAL SURF
CÓDIGOS NA TABELA ABAIXO
Material: carretel em alumínio,
rolamentos em aço, pinhão em
latão maciço e engrenagens em
zamac de alto impacto
Modelo ambidestro
Rolamentos: 5BB + 1RB
Drag: 10kg
Relação de recolhimento: 4.1:1

---

SELVA RUBI GIII
NOVO
CÓDIGOS NA TABELA ABAIXO CÓDIGOS NA TABELA A`,
  "👕 Vestuário e Coletes": `Coletes
Coast Material: Poliamida 70x240 gomado e reforçado
Códigos na tabela abaixo
Código | Capacidade
463000 - 10kg - AZPR - 7896558425234
463050 - 20kg - VMPR - 7896558414665 | AZPR -
7896558425258
463100 - 30kg - VDPR - 7896558414672
VMPR - 7896558425289 | AZPR - 7896558425296
463150 - 40kg - VDPR - 7896558425319
VMPR - 7896558414689 | AZPR - 7896558425333
463200 - 50kg - VMPR - 7896558425340 | AZPR -
7896558414696
463250 - 60kg - VMPR - 7896558414702 | AZPR -
7896558425395
463300 - 70kg - VMPR - 7896558414719 | AZPR -
7896558425418
463350 - 80kg - VDPR - 7896558425449
VMPR - 7896558425432 | AZPR - 7896558414726
463400 - 90kg - VMPR - 7896558425487 | AZPR -
7896558414733
463450 - 100kg - VMPR - 7896558425500 | AZPR -
7896558425524
463500 - 110kg - VDPR - 7896558425531
VMPR - 7896558425548 | AZPR - 7896558425579
463550 - 120kg - VMPR - 7896558414764 | AZPR -
7896558414757
Atlântico Homologado
Códigos na tabela abaixo
Manta flutuante em polipropileno expandido 6mm.
Tecido em poliéster. Fechos em nylon acetal 03
fechos. Cadarço em polipropileno encorpado para
ajuste na cintura e peito. Regulagem anatômica nas
laterais e fita de segurança nas virilhas. Acabamento
em vinil preto para maior conforto e resistência
Código | Capacidade
465012 - 25kg à 35kg - AZ - 7896558452162
465014 - 35kg à 55kg - AZ - 7896558452186
465016 - 55kg à 110kg - VM - 7896558452216
AZ - 7896558452209
465018 - Acima de 110kg - VM - 7896558452230
AZ- 7896558452223

---

Vestuário
Poncho de emergência Poncho Poncho
540050 Compacto Iguazu
540080 540100
Material: Polietileno Composição: PEVA Composição: PVC laminado soldado eletronicamente
Medidas: 14 x 10cm Medidas: 127 x 203cm (sem costuras)
Peso: 50g Peso: 40g Peso: 360g
UN - 7896558426064 AZ - 7896558467876 | PR - 7896558467913 UN - 7896558422424
LJ - 7896558467890 | VD - 7896558467906 VD - 7896558412814
Conjunto Fleece Fleece
Tempest Masculino Feminino
M - 540150 P - 540600 P - 540608
G - 540151 M - 540602 M - 540610
G - 540604 G - 540612
GG - 540152
GG - 540606 GG - 540614
Composição: Poliéster Material: 100% Poliéster Material: 100% Poliéster
Com jaqueta e calça impermeáveis P: UN - 7896558463595 P: UN - 7896558463632
Tamanho M UN - 7896558467883 M: UN - 7896558463601 M: UN - 7896558463649
Tamanho G UN - 7896558468088 G: UN - 7896558463618 G: UN - 7896558463656
Tamanho GG UN - 7896558468095 GG: UN - 7896558463625 GG: UN - 7896558463663
Conjunto
Amandy
M - 540802
Material: Nylon emborrachado
M: UN - 7896558459437
Híbrido 2
Códigos abaixo
Material: solado em borracha, vulcanizado e
costurado | tecido em neoprene
Código | Numeração
547801- 38: PR - 7896558491024
547802 - 39: PR - 7896558491031
547803 - 40: PR - 7896558491048
547804 - 41: PR - 7896558491055
547805 - 42: PR - 7896558491062
547806 - 43: PR - 7896558491079
547807 - 44: PR - 7896558491086

---

Cumbre 3 Minipack 1
740046 COLUNA 740050 COLUNA
D’ÁGUA D’ÁGUA
6000MM 6000MM
Material: Piso em poliéster 150D, dormitório em poliéster, Material: Piso em poliamida oxford 70D/210T, sobreteto em
sobreteto em nylon 20D e varetas em alumínio poliamida ripstop 70D/190T PU e vareta em duralumínio
Medida: 2,15 x 1,8 x 1,1m Medida: 2,55 x 1,4 x 1m
Peso: 2,5kg Peso: 2kg
VD - 7896558455965 UN - 7896558415389
104

---

Nepal 2
740100 COLUNA
D’ÁGUA
6000MM
Material: Piso em poliamida oxford 70D/210T, sobreteto em
poliamida ripstop 70D/190T PU e vareta em duralumínio
Medida: 2,55 x 2,72 x 1,1m
Peso: 2,5kg
UN - 7896558415372
Topo 32 Heat Isomat Reflex
740121 742318 742500
Material: Algodão, poliéster Ripstop
300T e fibras de poliester tipo hollow-
Material: Poliéster Dobby, Ripstop e fiber Material: EVA aluminizado
210D Medidas: 2,30m x 80cm Medidas: 1,8m x 50cm
Medidas: 55 x 30 x 20cm | Peso: 1,16kg Peso: 1,5kg Peso: 180g
Capacidade: 32 litros Faixa de temperatura: 7°C a 18°C UN - 7896558420802
AZ - 7896558464820 PR - 7896558453657
Ruby Ziggy Orok
742570 742575 742585
AUTO INFLÁVEL AUTO INFLÁVEL
Material: Espuma de poliuretano e Material: Espuma de poliuretano e Material: Fabricado em TPU revestido de
Poliéster tafetá 190t poliéster tafetá 190T poliamida de alta tenacidade
Medidas: 1,88m x 55cm x 3cm Medidas: 1,83m x 52cm x 3cm | Peso: 775g Medidas: 1,88m x 58cm x 4,7cm
Peso: 1,2kg UN - 7896558431457 Peso: 450g
UN - 7896558431440 LJ - 7896558447403
105

---

Cosmo Iztac Karibu
742630 742632 742650
Material: Poliéster de alta resistência Material: Liga de alumínio e partes em Material: Assento em poliéster de alta
e estrutura de duralumínio plástico resistência e estrutura em aço
Medidas: 56 x 48 cm Medidas: 70 x 70 x 70cm Medidas: 56 x 60 x 65cm | Peso: 1,6kg
Peso: 775g Peso: 2,4kg Peso suportado: 100kg
UN - 7896558440916 UN - 7896558462840 UN - 7896558440893
Osho Katori Magik
742652 743161 743165
Material: Corpo em ABS com botão Material: Corpo em ABS com cinta
Material: Poliéster com telado e emborrachado e elástico de cabeça elástica de cabeça
estrutura em aço ajustável | Medidas: 25 x 13 x 8cm | Medidas: 13 x 24 x 7cm | Peso: 70g
Medidas: 56 x 60 x 65 cm | Peso: 1,6kg Peso: 50g | Potência: 140 lúmens Potência: 120 lúmens
Peso suportado: 100kg Alimentação: 3 pilhas AAA (não inclusas) Alimentação: Bateria recarregável
LJ - 7896558453565 UN - 7896558438166 UN - 7896558440862
Mistik Kashina
743170 743175
Material: Plástico ABS, cinta elástica Material: Plástico ABS, cinta elástica
de nylon e botão de borracha de nylon e botão de borracha
Medidas: 25 x 13 x 8cm | Peso: 41g Medidas: 12 x 20 x 8cm | Peso: 46g
Potência: 140 lúmens Potência: 140 lúmens
Alimentação: 3 pilhas AAA (não inclusas) Alimentação: 3 pilhas AAA (não inclusas)
UN - 7896558438180 UN - 7896558438180
Jet Cook
743690
Material: Silicone, alumínio e aço
inoxidável
Medidas: Ø12,8 x 17,3cm
Peso: 511g
UN - 7896558438661
106

---

Keep Vernon Naty 1l
743691 744050 744355
Material: Aço inoxidável Material: Polietileno aluminizado Material: Copoliéster “Eastman Tritan”
Medidas: 41,5 x 41,5 x 34cm Medidas: 2,13 x 1,32m (polímero ultra resistente)
Peso: 700g Peso: 60g Medidas: 22 x 9 cm | Peso: 154g
UN - 7896558453589 UN - 7896558415563 Capadicade: 1 litro
UN - 7896558450052
Survivor Lokal
744480 745300
Material: Alumínio Material: Acrílico
Medidas: 7,4 cm Medidas: 14 x 24 x 2cm
Peso: 8g Peso: 57g
UN - 7896558417055 UN - 7896558419189
Oriente Actos Actos Pro Race
745400 745800 Carbon
745802
Material: Acrílico Material: Duralumínio, plástico ABS, Material: Tubo 50% carbono + 3K e cabo
Medidas: 13 x 6cm ponteira em aço endurecido e empunhadura em EVA
Peso: 90g alongada de TPR Medidas: 38cm - 1,35m
UN - 7896558419165 Medidas: 1,05m - 1,35m | Peso: 320g Peso: 230g
UN - 7896558440831 UN - 7896558464127
Actos Super Duble
Light 3K Carbon 35-39 - 747023
40-44 - 747024
745804
Material: Corpo em carbono e alumínio Material: 97% poliamida e 3% elastano
7075, topo em plástico ABS, cabo em EVA, Com camada dupla
ponteira em aço carbono em EVA 747023: UN - 7896558468149
Medidas: 1,20m | Peso: 155g 747024: UN - 7896558468156
UN - 7896558467852
107

---

Jaqueta Impermeável Atzi
COLUNA
Códigos na tabela abaixo
D’ÁGUA
Material: Tecido 100% Poliéster com 5000MM
impermeabilidade de 5.000 mm de coluna
d’água e respirabilidade de 3.000 g/
m²/24h, garantindo proteção contra chuva
e eficiente gerenciamento de umidade.
Corta vento Izel
Códigos na tabela abaixo
Material: Tecido 100% Nylon, 60 g/m², com
revestimento e tratamento DWR (Durable
Water Repellent) para maior resistência à
água
108

---

Jaqueta Trail Tenoch
Códigos na tabela abaixo
Material: Tecido 92% Poliéster e 8%
Elastano, construção ripstop, 140 g/m², com
tratamento DWR (Durable Water Repellent),
oferecendo leve elasticidade, alta
resistência e proteção contra umidade.
Calça Trail Tenoch
Códigos na tabela abaixo
Material: Tecido 92% Poliéster e 8%
Elastano, construção ripstop, 140 g/m², com
tratamento DWR (Durable Water Repellent),
oferecendo leve elasticidade, alta
resistência e proteção contra umidade.
109`,
  "🧊 Coolers": `Coolers
Aqua 8l Ice Box 34l Ice Box 54l
560412 560434 560454
Material: Polipropileno Material: Polipropileno injetado, polietileno e Material: Polipropileno injetado, polietileno e
Medidas: 31 x 20 x 20cm poliestireno expandido poliestireno expandido
Peso: 1,118kg Medidas: 41 x 51 x 31cm Medidas: 43 x 67 x 43cm
Mantém gelado por até 8 horas ou quente por até 4 UN - 7896558463472 CZ - 7896558463489
horas CZLJ - 7896558491260
UN - 7896558467821
Kool Ice Gel Banff
560520 Caixa c/ 20 pçs. 561113
560521
Material: Material de alta qualidade, não tóxico e BPA- Material: Exterior: Plástico | Interior: Gel atóxico Material: Couro sintético com CK e forro em folha de
free (não contém fitolatos) Medidas: 16 x 10cm alumínio
Medidas: 17 x 8,8 x 3,5cm Peso: 200g Medidas: 30 x 16 x 47cm
Peso: 400g UN - 7896558462789 Capacidade: 18 litros
UN - 7896558441517 AZ - 7896558464172
Bora 24l Bag Polar Duffle Mochila Polar Duffle
563025 563105 563107
Composição: PVC/600D + PEVA na parte prateada Material: PVC, Tarpaulin e forro em folha de alumínio Material: PVC, Tarpaulin e forro em folha de alumínio
Medidas: 30 x 25 x 28cm Medidas: 35 x 24 x 35cm Medidas: 32 x 15 x 45cm
Capacidade: 24 litros Capacidade: 26 litros Capacidade: 16 litros
Semi rígida
VM - 7896558435066
Cold Sak Duffle Picnic Park Kit Cesta Picnic
563109 563111 colapsável
c/ mesa
563115
Material: PVC, Tarpaulin e revestimento em PEVA Material: RPET 300D com revestimento em Material: Corpo em silicone e tampa em polietileno
branco poliuretano e forro em PEVA branco Medidas: 47 x 25,8 x 24cm
Medidas: 25,5 x 25,5 x 55,5cm Medidas: 32 x 23 x 43cm VD - 7896558464189
Capacidade: 15 litros AZ - 7896558464165
AZ - 7896558464155`,
  "🎯 TAG / Airgun / Airsoft": `A força que chegou em silêncio e se tornou
impossível de ignorar

---

Sobre a TAG
Quem somos
A TAG nasceu para ir além do óbvio. Somos
a linha tática do Grupo Nautika, a maior
distribuidora multiprodutos de camping e
outdoor do Brasil, com mais de 50 anos levando
qualidade, confiança e aventura para a vida de
milhões de pessoas. Índice
A TAG surgiu de uma necessidade real: oferecer
equipamentos de verdade — robustos,
confiáveis e com excelente custo-benefício.
Cada produto é pensado para quem vive o
esporte intensamente, para quem treina,
compete, supera limites e sente a adrenalina
correr nas veias.
Acreditamos que o esporte deve ser acessível a
todos que têm paixão por ele. Por isso, unimos
Carabinas de entrada 113
inovação, construção de qualidade e preços
justos, tornando possível que cada vez mais Carabinas intermediárias 115
pessoas entrem para esse universo e evoluam
Carabinas Semi-Magnum 117
dentro dele. A TAG acompanha o primeiro
passo de quem está começando e continua ao Carabinas PCP 120
lado de quem busca desempenho e evolução.
Linha PCP AP 124
Nossa proximidade com os usuários é o que nos Linhas pistolas Airgun 129
move. Ouvimos quem está no campo, na trilha e
Linha TAG Optics 134
na linha de tiro. Entendemos necessidades reais
e transformamos essas demandas em soluções Linha Cases 137
concretas, criando produtos que funcionam de
Linha Alvos 140
verdade e acompanham cada desafio.
Acessórios para Airgun 144
Porque, para nós, não se trata apenas de
importar e distribuir equipamentos. Munição TAG 146
Gases TAG 148
NÓS REALIZAMOS SONHOS, DESPERTAMOS
DESEJOS E ENTREGAMOS EXATAMENTE Cutelaria 149
AQUILO QUE O PÚBLICO PROCURA.
Rifles Airsoft 150
TAG é mais do que uma marca. Acessórios Airsoft 151
É atitude, é paixão, é compromisso.
Somos TAG. Vestimos a camisa de quem tem o
espírito tático correndo nas veias.

---

MAMBA MH 5.5MM
900002
TAG MAMBA: leve, robusta e construída para durar. Com bloco
em aço, caixa de gatilho em metal e cano microraiado em aço,
entrega um padrão de qualidade único na sua faixa de preço. A
carabina de entrada mais bem construída do mercado — perfeita
para quem quer começar com confiança.
Calibres: 5.5mm Cano microraiado em aço
Velocidade: 195m/s* Cano de 480 mm
* Pode Variar conforme condicoes de tiro Comprimento total 1085 mm
Material: Bloco em aço e internos em Peso 2.8 kg
metal Municao ideal: 0.70g
Caixa de gatilho: Em metal e ajustável UN -
MAMBA GR 5.5MM
900003
TAG MAMBA a carabina de entrada mais bem construída do
mercado, tambem na versão GR. Mantém toda a qualidade da
versão MH (mola),mas com a evolução do sistema em Gas Ram
de 55 kg, entregando mais consistência, conforto no disparo e
durabilidade para uma experiência única.
Calibres: 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 50kg Cano de 480 mm
Velocidade: 195m/s* Comprimento total 1085 mm
* Pode Variar conforme condicoes de tiro Peso 2.8 kg
Material: Bloco em aço e internos em Municao ideal: 0.70g
metal UN -
Caixa de gatilho: Em metal e ajustável

---

SCORPION
4.5MM - 900004 | 5.5MM - 900005
Leve, prática e extremamente fácil de usar, a TAG Scorpion é
a escolha ideal para quem está dando os primeiros passos no
tiro esportivo. Com basculamento suave e operação simples,
proporciona uma experiência divertida e descomplicada para
treinos, lazer e plinking.
A CARABINA MAIS ACESSÍVEL DO MERCADO, PERFEITA PARA
COMEÇAR COM CONFIANÇA.
Calibres: 4.5mm e 5.5mm
Cano microraiado em aço com
Mola helicoidal
cobertura em polímero
Velocidade: 4.5mm: 160m/s*
Cano de 450 mm
5.5mm: 120m/s*
Comprimento total 1000 mm
* Pode Variar conforme condicoes de tiro
Peso 2.05 kg
Material: Bloco em aço e internos em
Municao ideal: 0.70g
metal
4.5mm: UN -
Caixa de gatilho: Em metal
5.5mm: UN - 7896558455811
114

---

NAJA
4.5MM - 900006 | 5.5MM - 900007
A queridinha do momento e CAMPEÃ DE VENDAS EM 2025, a TAG Naja conquistou
de vez seu espaço entre as carabinas mais populares da categoria GAS RAM
DE 60 KG para quem busca potência real. Após ganhar destaque no mercado,
passou a integrar a lista das mais vendidas do segmento, consolidando-se como
a escolha de quem quer desempenho de verdade.
FORÇA, PRECISÃO E CONSTRUÇÃO EXTREMAMENTE ROBUSTA. Um conjunto
mecânico confiável que garante tiros consistentes e excelente desempenho para
quem quer evoluir no esporte.
TAG NAJA — A CAMPEÃ DE 2025, POTÊNCIA QUE VIROU REFERÊNCIA.
Calibres: 4.5mm e 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 480 mm
Material: Bloco em aço e internos em metal Comprimento total 1150 mm
Caixa de gatilho: Em metal e ajustável Peso: 2,79kg
Velocidade: 4.5mm: 275m/s 4.5mm: UN - 7896558463335
5.5mm: 230m/s 5.5mm: UN - 7896558457860
*Pode Variar conforme condicoes de tiro
NAJA 2.0
4.5MM - 900008| 5.5MM - 900009
A carabina que ELEVA O PADRÃO DA CATEGORIA.
POTÊNCIA IMPRESSIONANTE, PRECISÃO SURPREENDENTE
E CONSTRUÇÃO ROBUSTA EM AÇO se unem em um
equipamento feito para entregar desempenho máximo. Com
CANO FIXO QUE ELIMINA VIBRAÇÕES E MOVIMENTOS NO
BASCULAMENTO, cada disparo é CONSISTENTE, ESTÁVEL E
CONFIÁVEL.
DESEMPENHO EXCEPCIONAL NA FAIXA DE PREÇO MAIS
COMPETITIVA DO MERCADO.
Calibres: 4.5mm e 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 480 mm
Material: Bloco em aço e internos em metal Comprimento total 1170 mm
Caixa de gatilho: Em metal e ajustável Peso: 3,15kg
Velocidade: 4.5mm: 250m/s 4.5mm: UN - 7896558460235
5.5mm: 220m/s 5.5mm: UN - 7896558459130
*Pode Variar conforme condicoes de tiro

---

NAJA WOOD
4.5MM - 900022| 5.5MM - 900023
A mesma qualidade que consagrou a TAG Naja como QUERIDINHA
DO MOMENTO agora chega em VERSÃO MADEIRA, combinando
BELEZA CLÁSSICA, EQUILÍBRIO PERFEITO E ROBUSTEZ
INCOMPARÁVEL. Cada detalhe ELEVA O PADRÃO DE POTÊNCIA,
PRECISÃO E SOFISTICAÇÃO, oferecendo uma experiência ÚNICA
NESTA CATEGORIA.
Calibres: 4.5mm e 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 480 mm
Material: Bloco em aço e internos em metal Comprimento total 1150 mm
Caixa de gatilho: Em metal e ajustável Peso: 2,8kg
Velocidade: 4.5mm: 275m/s 4.5mm: UN - 7896558463885
5.5mm: 230m/s 5.5mm: UN - 7896558463892
*Pode Variar conforme condicoes de tiro
NAJA WOOD 2.0
4.5MM - 900024| 5.5MM - 900025
A mesma potência e precisão que consagraram a TAG
Naja 2.0 agora combinadas com a ELEGÂNCIA CLÁSSICA
DA CORONHA DE MADEIRA. Cada detalhe foi pensado
para oferecer CONFORTO, EQUILÍBRIO PERFEITO E
DURABILIDADE, sem comprometer o desempenho que já é
referência no segmento.
Calibres: 4.5mm e 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 480 mm
Material: Bloco em aço e internos em metal Comprimento total 1170 mm
Caixa de gatilho: Em metal e ajustável Peso: 3,2kg
Velocidade: 4.5mm: 250m/s 4.5mm: UN - 7896558463908
5.5mm: 220m/s 5.5mm: UN - 7896558463915
*Pode Variar conforme condicoes de tiro
116

---

MONTANA
4.5MM - 900016 | 5.5MM - 900017
Quando o assunto é potência, a TAG Montana fala mais alto. Com GÁS RAM DE 60
KG, entrega desempenho capaz de SUPERAR CARABINAS COM 70 KG, provando
que força real vem de um projeto sólido e eficiente.
Sua CONSTRUÇÃO EXTREMAMENTE ROBUSTA transmite confiança em cada
detalhe, enquanto a CORONHA DE MADEIRA adiciona a elegância clássica que
transforma potência bruta em presença imponente.
Calibres: 4.5mm e 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 400 mm
Material: Bloco em aço e internos em metal Comprimento total 1180 mm
Caixa de gatilho: Em metal Peso: 3,7kg
Velocidade: 4.5mm: 320m/s 4.5mm: UN - 7896558460273
5.5mm: 300m/s 5.5mm: UN - 7896558459147
*Pode Variar conforme condicoes de tiro
MONTANA MAG
5.5MM - 900018
A potência da Montana aliada ao MULTISHOT MAGAZINE: disparos consecutivos,
combinando FORÇA EXTREMA, PRECISÃO E VELOCIDADE. Um equipamento feito
para quem quer DESEMPENHO TOTAL EM CADA TIRO.
Calibres: 5.5mm Cano microraiado em aço
Nitro Piston Gas ram 60kg Cano de 480 mm
Material: Bloco em aço e internos em metal Comprimento total 1180 mm
Caixa de gatilho: Em metal Peso: 3,7kg
Velocidade: 5.5mm: 228m/s 5.5`,
  "💣 Munições e Acessórios": `TOMAHAWK TSUNAMI TWISTER
5.5MM - 900132 (125) 4.5MM - 900150 (250) 4.5MM - 900170 (250)
5.5MM - 900155 (125) 5.5MM - 900175 (125)
6.0MM - 900160 (100)
Material: Chumbo
Material: Chumbo Material: Chumbo
Peso: 4.5: 0,65g | 5.5: 1,2g | 6.0: 1,57g (cada
Peso: 4.5: 0,43g | 5.5: 1,12g (cada chumbinho) Peso: 4.5: 0,55g | 5.5: 1,06g (cada chumbinho)
chumbinho)
4.5: UN - 7896558454982 4.5: UN - 7896558435080
4.5: UN - 7896558434106 | 5.5: UN - 7896558432300
5.5: UN - 7896558454999 5.5: UN - 7896558435097
6.0: UN - 7896558438210
DUELO VOLEEX SCORPION 5.5MM
5.5MM - 900185 (125) 5.5MM - 900195 (125) 900197 (75)
Material: Chumbo Material: Chumbo Material: Chumbo
Peso: 4.5: 0,65g | 5.5: 0,98g (cada chumbinho) Peso: 4.5: 0,57g | 5.5: 0,92g (cada chumbinho) Peso: 0,73g(cada chumbinho)
5.5: UN - 7896558438289 5.5: UN - 7896558438265 UN - 7896558457488
VELOZTER
0.12G - 900620
0.20G - 900625
0.25G - 900630
0.28G - 900632
0.30G - 900635
Material: Plástico ABS
Quantidades: 0.12: 2000 un | 0.20g: 5000 un
0.25g: 4000 un | 0.28g: 4000 un | 0.30g: 3500un
0.12g: UN - 7896558435110 | 0.20g: UN - 7896558435035
0.25g: UN - 7896558435042 | 0.28g: UN - 7896558441425
0.30g: UN - 7896558441432
VELOZTER TRACER
0.20G - 900680
0.25G - 900685
Material: Plástico ABS
Quantidade: 2000 unidades
0.20g: VD - 7896558435080
0.25g: VD - 7896558435097

---

BLAST
4.5MM - 900505 (500)
900510 (1000)
6MM - 900525 (500)
Material: Chumbo
Peso: 4.5: 0,02 | 6: 1,12g (cada chumbinho)
4.5: 500pçs. - UN - 7896558454982 | 1000pçs. - UN - 7896558468743
6: UN - 7896558460693
Gás TAG
A mais vendida do Brasil, referência em desempenho e confiabilidade.
A linha conta com opções para cada necessidade, incluindo GREEN GAS, RED GAS E
CO₂, atendendo desde usos recreativos até aplicações que exigem maior potência e
desempenho. Com qualidade comprovada e excelente autonomia.
RED GAS TAIKOON GREEN GAS CÁPSULA CO
2
965000 900710 15 UN. - 900706
25 UN. - 900707
40 UN. - 900708
200 UN. - 900709
Material: CO
²
Peso: 12g (cada cápsula)
Material: Alumínio Material: Alumínio 15un. - UN - 7896558449500
Medidas: 28,5cm x 7,5 (diâmetro) Medidas: 27cm x 6,5 (diâmetro) 25un. - UN - 7896558649517
Peso: 270g Peso: 270g 40un. - UN - 7896558649524
UN - 7896558449803 UN - 7896558438432 200un. - UN - 7896558649531
148

---

ROBOT PATRIOTA RESCUE
901007 901027 901037
Material: Lâmina de aço inoxidável 420SS e cabo de Material: Alumínio e partes em polímero Material: Lâmina de aço inoxidável e cabo de plástico
alumínio Medidas: 21,4cm Medidas: 21cm |Peso: 120g
Medidas: 21,4cm |Peso: 200g Peso: 170g UN - 7896558442842
UN - 7896558449605 UN - 7896558449612
BROOK DOGCUT NAKATA
901038 901056 901077
Material: Aço inoxidável 420 Material: Alumínio e aço inoxidável 420 Material: Aço inoxidável 420 e paracord
Medidas: 20,5cm Medidas: 7,9 x 3cm Medidas: 13 x 23 x 3cm
Peso: 180g Peso: 70g Peso: 180g
UN - 7896558439330 UN - 7896558449636 UN - 7896558440954

---

DE ARMORY BRADOK M904G
936105
Calibre: 6mm Motor: 22000 Hight Torque
Tipo: Rifle Airsoft Elétrico (Airsoft AEG) Gatilho: Flat
Gatilho eletrônico programável com sistema Pre- cocking Munição utilizada: Esferas plásticas Airsoft 6mm (BBs)
Sistema de gatilho: Falcon Electronic Control System Magazine: Mid-Cap
Material: Fibra de Nylon Capacidade do magazine: 120 rounds
Peso: 2.045 kg Não acompanha bateria e carregador
Coronha: Retrátil UN - 7896558451622
Hop up: Ajustável
DE ARMORY ORION
UTR M917G
936107
Calibre: 6mm Motor: 22000 Hight Torque
Tipo: Rifle Airsoft Elétrico (Airsoft AEG) Gatilho: Flat
Gatilho eletrônico programável com sistema Pre- cocking Munição utilizada: Esferas plásticas Airsoft 6mm (BBs)
Sistema de gatilho: Falcon Electronic Control System Magazine: Mid-Cap - UMP
Material: Fibra de Nylon Capacidade do magazine: 120 rounds
Peso: 2380g kg Não acompanha bateria e carregador
Coronha: Rebatível UN - 7896558460594
Hop up: Ajustável
150

---

COMBAT 6MM
937505
Material: Polimero e metal
Funcionamento: semi e full auto
Sistema : Hibrido
Green Gas ou Cápsula CO² de 12 g (magazine
vendido separadamente)
Calibre: 6mm
Munição: BB’s plasticas 6mm
Capacidade: 22 BB’s por magazine
Peso: 700g
Ponteira vermelha metálica
Açao: Blowback
Acompanha 1 Magazine Green Gas.
UN - 7896558454470
LOADER AX LOADER XT ACTION CORD
903002 903005 903031
Material: Polímero resistente Material: Polímero resistente Material: Poliamida e plástico
Medidas: 7 x 21 x 3cm Medidas: 9 x 23 x 3cm Medidas: 12 x 21 x 4cm
Peso: 70g Peso: 440g Peso: 50g
UN - 7896558439460 UN - 7896558439477 UN - 7896558439316
CORD MAG PARACORD GAC SHEMAGH
903033 903036 903044
Material: Poliamida Material: Aço Material: Algodão e poliéster
Medidas: 8 x 18 x 3cm Medidas: 1,7cm x 11,6cm Medidas: 1x1m | Peso: 220g
Peso: 110g Peso: 80g BCPR - 7896558455934 | CQ - 7896558439538
UN - 7896558441159 UN - 7896558442880 PR - 7896558447397| VD - 7896558439521

---

GHOST STORM SHADOW
907027 907028 907029
Material: Policarbonato Material: Policarbonato e TPU Material: Policarbonato
Medidas: 11 x 54 x 4cm Medidas: 5 x 18 x 8cm UN - 7896558649562
Peso: 130g Peso: 249g
UN - 7896558649548 UN - 7896558649555
SLING TRIAD MAGAZINE TG92 KWC 4.5 MAGAZINE M917G
903060 900070 937619
Material: Poliamida Magazine para rifle Orion M917 MAG
Medidas: 11 x 54 x 4cm Material: Metal Série UTR45
Peso: 130g Capacidade de 19 esferas de aço Capacidade 120 rounds
UN - 7896558440695 UN - 7896558460686 UN - 7896558460600
MAGAZINE GREEN GAS HI MAGAZINE HI CAPA MAGAZINE GREEN GAS
CAPA ESTENDIDO GLOCK
936358 936360 936363
Material: Polímero e Metal Material: Polímero e Metal Material: Polímero e Metal
Magazine para pistolas Black Whisper e Evil Magazine para pistolas Black Whisper e Evil Magazine para pistolas Raven e Combat
Peso: 375g Peso: 575g Peso: 308g
UN - 7896558463939 UN - 7896558463946 UN - 7896558463953
152`,
};

const SECTION_KEYS = Object.keys(CATALOG_SECTIONS);

// ─── LEVELS ─────────────────────────────────────────────────────────────────
const LEVELS = [
  { level: 1, name: "Recruta",        badge: "🌱", min: 0    },
  { level: 2, name: "Explorador",     badge: "🧭", min: 150  },
  { level: 3, name: "Aventureiro",    badge: "⛺", min: 400  },
  { level: 4, name: "Especialista",   badge: "🎒", min: 800  },
  { level: 5, name: "Mestre Nautika", badge: "🏆", min: 1400 },
];
const getLevelInfo = (xp) => [...LEVELS].reverse().find(l => xp >= l.min) || LEVELS[0];
const getNextLevel = (xp) => LEVELS.find(l => l.min > xp);

// ─── API: GENERATE EXERCISES ────────────────────────────────────────────────
async function fetchExercises(sectionName, sectionContent) {
  const prompt = `Você é um gerador de exercícios de treinamento de vendas para a Nautika.

CATÁLOGO DA LINHA "${sectionName}":
${sectionContent}

Gere EXATAMENTE ${EXERCISE_COUNT} exercícios variados sobre estes produtos reais.
REGRAS:
- Use APENAS produtos que aparecem no texto acima
- Tipos obrigatórios: multipla_escolha (3x), flashcard (1x), completar_descricao (1x), verdadeiro_falso (1x)
- Foque em: nomes, códigos, materiais, specs técnicas, diferenciais, usos, categorias
- Nunca repita a mesma pergunta
- Para multipla_escolha: 4 opções, correct = índice 0-3
- Para verdadeiro_falso: correct = true ou false

Responda APENAS com JSON válido sem markdown:
{
  "exercises": [
    {"type":"multipla_escolha","question":"...","options":["A","B","C","D"],"correct":0,"explanation":"..."},
    {"type":"flashcard","front":"Nome do produto","back":"Specs, material, peso, diferenciais...","explanation":"..."},
    {"type":"completar_descricao","question":"O ___ pesa ___ e é feito de ___.","display_answer":"resposta completa","hint":"dica","explanation":"..."},
    {"type":"verdadeiro_falso","statement":"A barraca X monta em 30s.","correct":false,"explanation":"..."}
  ]
}`;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await resp.json();
  const text = data.content?.map(i => i.text || "").join("") || "";
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

// ─── HELPERS ────────────────────────────────────────────────────────────────
function ProgressBar({ value, max, color = "#40916c", height = 8 }) {
  return (
    <div style={{ background: "rgba(255,255,255,0.1)", borderRadius: 99, height, overflow: "hidden" }}>
      <div style={{ width: `${Math.min(100,(value/max)*100)}%`, height:"100%", background:`linear-gradient(90deg,${color},${color}bb)`, borderRadius:99, transition:"width .5s ease" }} />
    </div>
  );
}

function XPToast({ value }) {
  return (
    <div style={{
      position:"fixed", top:"16%", left:"50%", transform:"translateX(-50%)",
      background:"linear-gradient(135deg,#1b4332,#40916c)", color:"#d8f3dc",
      padding:"10px 24px", borderRadius:99, fontWeight:800, fontSize:18, zIndex:9999,
      boxShadow:"0 4px 24px rgba(64,145,108,.5)", animation:"floatUp 1.4s ease-out forwards",
      pointerEvents:"none",
    }}>+{value} XP ✨</div>
  );
}

// ─── AUTH SCREEN ─────────────────────────────────────────────────────────────
function AuthScreen({ onAuth }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState("login"); // login | signup | confirm
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  async function handleSubmit() {
    setError(""); setInfo("");
    if (!email.endsWith(ALLOWED_DOMAIN)) {
      setError(`Apenas e-mails ${ALLOWED_DOMAIN} são permitidos.`);
      return;
    }
    if (password.length < 6) { setError("Senha deve ter ao menos 6 caracteres."); return; }
    setLoading(true);
    if (mode === "signup") {
      const { error: e } = await supabase.auth.signUp({ email, password });
      if (e) setError(e.message);
      else { setMode("confirm"); setInfo("Confirme seu e-mail antes de entrar — verifique sua caixa de entrada."); }
    } else {
      const { data, error: e } = await supabase.auth.signInWithPassword({ email, password });
      if (e) setError(e.message);
      else onAuth(data.user);
    }
    setLoading(false);
  }

  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
      <div style={{ width:"100%", maxWidth:380, animation:"slideIn .4s ease" }}>
        <div style={{ textAlign:"center", marginBottom:36 }}>
          <div style={{ fontSize:52, marginBottom:8 }}>⚓</div>
          <h1 style={{ fontSize:24, fontWeight:900, background:"linear-gradient(135deg,#95d5b2,#40916c)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
            Nautika Academy
          </h1>
          <p style={{ color:"#868e96", fontSize:13, marginTop:6 }}>Catálogo 2026 · Jornada de Aprendizado</p>
        </div>

        {mode === "confirm" ? (
          <div style={{ background:"rgba(64,145,108,.15)", border:"1px solid rgba(64,145,108,.4)", borderRadius:16, padding:"24px", textAlign:"center" }}>
            <div style={{ fontSize:36, marginBottom:12 }}>📧</div>
            <p style={{ color:"#95d5b2", fontWeight:600, lineHeight:1.6 }}>{info}</p>
            <button onClick={() => setMode("login")} style={{ marginTop:20, background:"rgba(255,255,255,.08)", border:"1px solid rgba(255,255,255,.15)", borderRadius:10, padding:"10px 20px", color:"#adb5bd", cursor:"pointer" }}>
              Voltar ao login
            </button>
          </div>
        ) : (
          <div style={{ background:"rgba(255,255,255,.04)", border:"1px solid rgba(255,255,255,.08)", borderRadius:20, padding:"28px 24px" }}>
            <h2 style={{ fontSize:17, fontWeight:700, marginBottom:20 }}>
              {mode === "login" ? "Entrar" : "Criar conta"}
            </h2>
            <div style={{ marginBottom:12 }}>
              <label style={{ fontSize:12, color:"#868e96", fontWeight:600, display:"block", marginBottom:6 }}>E-MAIL CORPORATIVO</label>
              <input value={email} onChange={e => setEmail(e.target.value)}
                placeholder={`seu.nome${ALLOWED_DOMAIN}`}
                type="email"
                style={{ width:"100%", background:"rgba(255,255,255,.07)", border:"1px solid rgba(255,255,255,.12)", borderRadius:10, padding:"12px 14px", color:"#fff", fontSize:14, outline:"none" }} />
            </div>
            <div style={{ marginBottom:20 }}>
              <label style={{ fontSize:12, color:"#868e96", fontWeight:600, display:"block", marginBottom:6 }}>SENHA</label>
              <input value={password} onChange={e => setPassword(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSubmit()}
                placeholder="Mínimo 6 caracteres"
                type="password"
                style={{ width:"100%", background:"rgba(255,255,255,.07)", border:"1px solid rgba(255,255,255,.12)", borderRadius:10, padding:"12px 14px", color:"#fff", fontSize:14, outline:"none" }} />
            </div>
            {error && <p style={{ color:"#ff8a80", fontSize:13, marginBottom:14, background:"rgba(192,57,43,.2)", borderRadius:8, padding:"8px 12px" }}>{error}</p>}
            <button onClick={handleSubmit} disabled={loading}
              style={{ width:"100%", background:"linear-gradient(135deg,#1b4332,#40916c)", border:"none", borderRadius:12, padding:"14px", color:"#fff", fontWeight:700, fontSize:15, cursor:loading?"wait":"pointer", opacity:loading?.7:1 }}>
              {loading ? "Aguarde…" : mode === "login" ? "Entrar →" : "Criar conta →"}
            </button>
            <p style={{ textAlign:"center", marginTop:16, fontSize:13, color:"#868e96" }}>
              {mode === "login" ? "Ainda não tem conta? " : "Já tem conta? "}
              <span onClick={() => { setMode(mode==="login"?"signup":"login"); setError(""); }}
                style={{ color:"#74c69d", cursor:"pointer", fontWeight:600 }}>
                {mode === "login" ? "Criar agora" : "Entrar"}
              </span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── HOME SCREEN ─────────────────────────────────────────────────────────────
function HomeScreen({ user, profile, sectionProgress, onSelectSection, onRanking, onLogout }) {
  const xp = profile?.xp || 0;
  const streak = profile?.streak || 0;
  const lvl = getLevelInfo(xp);
  const next = getNextLevel(xp);
  const xpInLevel = xp - lvl.min;
  const xpToNext = next ? next.min - lvl.min : 1;
  const name = user.email.split("@")[0].replace(".", " ").replace(/\b\w/g, c => c.toUpperCase());

  return (
    <div style={{ animation:"slideIn .4s ease" }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"20px 0 16px" }}>
        <div>
          <p style={{ color:"#868e96", fontSize:12, marginBottom:2 }}>Olá,</p>
          <h2 style={{ fontSize:17, fontWeight:800, margin:0 }}>{name} 👋</h2>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onRanking}
            style={{ background:"rgba(255,255,255,.07)", border:"1px solid rgba(255,255,255,.12)", borderRadius:10, padding:"8px 14px", color:"#f1f3f5", fontSize:13, fontWeight:600, cursor:"pointer" }}>
            🏅 Ranking
          </button>
          <button onClick={onLogout}
            style={{ background:"transparent", border:"none", color:"#868e96", fontSize:20, cursor:"pointer" }}>
            ⎋
          </button>
        </div>
      </div>

      {/* Player card */}
      <div style={{ background:"rgba(255,255,255,.05)", borderRadius:20, padding:"18px 20px", marginBottom:20, border:"1px solid rgba(255,255,255,.08)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
          <div style={{ fontSize:38 }}>{lvl.badge}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700, fontSize:15 }}>{lvl.name}</div>
            <div style={{ color:"#74c69d", fontSize:12, fontWeight:600 }}>{xp} XP acumulados</div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:11, color:"#868e96" }}>Sequência</div>
            <div style={{ fontWeight:800, fontSize:20 }}>🔥 {streak}</div>
          </div>
        </div>
        {next && (
          <>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, color:"#868e96", marginBottom:5 }}>
              <span>Nível {lvl.level}</span>
              <span>{next.min - xp} XP para {next.name} {next.badge}</span>
            </div>
            <ProgressBar value={xpInLevel} max={xpToNext} />
          </>
        )}
      </div>

      {/* Section list */}
      <p style={{ fontSize:11, color:"#868e96", fontWeight:700, letterSpacing:1, textTransform:"uppercase", marginBottom:10 }}>
        Linhas de produto
      </p>
      <div style={{ display:"flex", flexDirection:"column", gap:9, marginBottom:28 }}>
        {SECTION_KEYS.map((key) => {
          const prog = sectionProgress[key] || { sessions:0, best_score:0 };
          const [emoji, ...rest] = key.split(" ");
          const sname = rest.join(" ");
          const pct = prog.best_score ? Math.round((prog.best_score / EXERCISE_COUNT) * 100) : 0;
          return (
            <div key={key} onClick={() => onSelectSection(key)}
              style={{ background:"rgba(255,255,255,.04)", border:"1px solid rgba(255,255,255,.07)", borderRadius:16, padding:"13px 16px", cursor:"pointer", display:"flex", alignItems:"center", gap:13, transition:"background .2s" }}
              onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,.09)"}
              onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,.04)"}
            >
              <div style={{ fontSize:26 }}>{emoji}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700, fontSize:13 }}>{sname}</div>
                <div style={{ fontSize:11, color:"#868e96", marginTop:2 }}>
                  {prog.sessions === 0 ? "Não iniciado" : `${prog.sessions} sessão(ões) · melhor: ${pct}%`}
                </div>
                {prog.sessions > 0 && <div style={{ marginTop:5 }}><ProgressBar value={prog.best_score} max={EXERCISE_COUNT} height={4} /></div>}
              </div>
              {prog.sessions > 0 && pct === 100 && <span style={{ fontSize:18 }}>✅</span>}
              <div style={{ color:"#868e96", fontSize:18 }}>›</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── RANKING SCREEN ───────────────────────────────────────────────────────────
function RankingScreen({ currentUserId, onBack }) {
  const [ranking, setRanking] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, email, xp, streak, level_name")
        .order("xp", { ascending: false })
        .limit(20);
      setRanking(data || []);
      setLoading(false);
    })();
  }, []);

  const medals = ["🥇","🥈","🥉"];

  return (
    <div style={{ animation:"slideIn .4s ease" }}>
      <div style={{ display:"flex", alignItems:"center", gap:12, padding:"20px 0 20px" }}>
        <button onClick={onBack} style={{ background:"none", border:"none", color:"#868e96", cursor:"pointer", fontSize:22 }}>←</button>
        <h2 style={{ fontSize:19, fontWeight:900, margin:0 }}>🏅 Ranking do Time</h2>
      </div>
      {loading ? (
        <div style={{ textAlign:"center", padding:60 }}>
          <div style={{ fontSize:36, animation:"spin 1.5s linear infinite" }}>⚓</div>
        </div>
      ) : (
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {ranking.map((p, i) => {
            const name = p.email.split("@")[0].replace(".", " ").replace(/\b\w/g, c => c.toUpperCase());
            const lvl = getLevelInfo(p.xp || 0);
            const isMe = p.id === currentUserId;
            return (
              <div key={p.id} style={{
                background: isMe ? "rgba(64,145,108,.2)" : "rgba(255,255,255,.04)",
                border: `1px solid ${isMe ? "rgba(64,145,108,.5)" : "rgba(255,255,255,.07)"}`,
                borderRadius:14, padding:"13px 16px", display:"flex", alignItems:"center", gap:12,
              }}>
                <div style={{ fontSize:20, width:28, textAlign:"center", fontWeight:800, color:i<3?"#f1f3f5":"#868e96" }}>
                  {i < 3 ? medals[i] : `${i+1}º`}
                </div>
                <div style={{ fontSize:24 }}>{lvl.badge}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:14 }}>{name}{isMe && <span style={{ color:"#74c69d", fontSize:11, marginLeft:6 }}>(você)</span>}</div>
                  <div style={{ fontSize:11, color:"#868e96" }}>{lvl.name} · 🔥 {p.streak || 0}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontWeight:800, fontSize:16, color:"#74c69d" }}>{p.xp || 0}</div>
                  <div style={{ fontSize:10, color:"#868e96" }}>XP</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── EXERCISE SCREEN ──────────────────────────────────────────────────────────
function ExerciseScreen({ section, userId, onFinish, onXP }) {
  const [exercises, setExercises] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [idx, setIdx] = useState(0);
  const [hearts, setHearts] = useState(3);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [isCorrect, setIsCorrect] = useState(null);
  const [fillText, setFillText] = useState("");
  const [cardFlipped, setCardFlipped] = useState(false);
  const [showXP, setShowXP] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchExercises(section, CATALOG_SECTIONS[section]);
        if (!cancelled) { setExercises(data.exercises); setLoading(false); }
      } catch(e) {
        if (!cancelled) { setError("Erro ao gerar exercícios. Tente novamente."); setLoading(false); }
      }
    })();
    return () => { cancelled = true; };
  }, [section]);

  const ex = exercises[idx];
  const total = exercises.length || EXERCISE_COUNT;

  function awardXP(pts) {
    onXP(pts);
    setShowXP(pts);
    setTimeout(() => setShowXP(null), 1400);
  }

  function advance() {
    const newScore = score + (isCorrect ? 1 : 0);
    const nextIdx = idx + 1;
    if (nextIdx >= exercises.length || hearts <= 0) {
      onFinish({ score: newScore, total: exercises.length });
    } else {
      setIdx(nextIdx); setSelected(null); setIsCorrect(null); setFillText(""); setCardFlipped(false);
    }
  }

  function handleMC(i) {
    if (selected !== null) return;
    setSelected(i);
    const ok = i === ex.correct;
    setIsCorrect(ok);
    if (ok) { setScore(s => s+1); awardXP(20); } else setHearts(h => Math.max(0, h-1));
  }
  function handleVF(val) {
    if (selected !== null) return;
    setSelected(val);
    const ok = val === ex.correct;
    setIsCorrect(ok);
    if (ok) { setScore(s => s+1); awardXP(15); } else setHearts(h => Math.max(0, h-1));
  }
  function handleFill() {
    if (isCorrect !== null || !fillText.trim()) return;
    const answer = ex.display_answer?.toLowerCase() || "";
    const user = fillText.trim().toLowerCase();
    const ok = answer.split(/[\s,]+/).filter(w => w.length > 3).some(w => user.includes(w));
    setIsCorrect(ok); setSelected(0);
    if (ok) { setScore(s => s+1); awardXP(25); } else setHearts(h => Math.max(0, h-1));
  }
  function handleFlashcard() {
    awardXP(15); setScore(s => s+1);
    const nextIdx = idx + 1;
    if (nextIdx >= exercises.length || hearts <= 0) onFinish({ score: score+1, total: exercises.length });
    else { setIdx(nextIdx); setSelected(null); setIsCorrect(null); setCardFlipped(false); }
  }

  const [emoji] = section.split(" ");

  return (
    <div style={{ animation:"slideIn .35s ease" }}>
      {showXP && <XPToast value={showXP} />}
      {/* Top bar */}
      <div style={{ display:"flex", alignItems:"center", gap:12, padding:"18px 0 14px" }}>
        <button onClick={() => onFinish({ score, total, aborted:true })}
          style={{ background:"none", border:"none", color:"#868e96", cursor:"pointer", fontSize:22 }}>←</button>
        <div style={{ flex:1 }}><ProgressBar value={idx} max={total} /></div>
        <div style={{ display:"flex", gap:3 }}>
          {[1,2,3].map(h => <span key={h} style={{ fontSize:18, opacity:h<=hearts?1:.2, transition:"opacity .3s" }}>❤️</span>)}
        </div>
      </div>
      {/* Label */}
      <div style={{ display:"inline-flex", alignItems:"center", gap:6, background:"rgba(64,145,108,.15)", border:"1px solid rgba(64,145,108,.3)", borderRadius:99, padding:"4px 12px", marginBottom:18, fontSize:12, fontWeight:600, color:"#74c69d" }}>
        {emoji} {section.slice(section.indexOf(" ")+1)} · {idx+1}/{total}
      </div>

      {loading && (
        <div style={{ textAlign:"center", padding:"70px 0" }}>
          <div style={{ fontSize:44, marginBottom:14, animation:"spin 1.5s linear infinite" }}>⚓</div>
          <p style={{ color:"#74c69d", fontWeight:600 }}>Gerando exercícios com IA…</p>
          <p style={{ color:"#868e96", fontSize:12, marginTop:6 }}>Analisando o catálogo desta linha</p>
        </div>
      )}
      {error && (
        <div style={{ textAlign:"center", padding:40 }}>
          <div style={{ fontSize:40, marginBottom:12 }}>⚠️</div>
          <p style={{ color:"#ff6b6b" }}>{error}</p>
          <button onClick={() => onFinish({ score:0, total:0, aborted:true })} style={{ marginTop:16, background:"rgba(255,255,255,.1)", border:"1px solid rgba(255,255,255,.2)", borderRadius:10, padding:"10px 20px", color:"#fff", cursor:"pointer" }}>Voltar</button>
        </div>
      )}

      {!loading && !error && ex && (
        <div>
          {/* MÚLTIPLA ESCOLHA */}
          {ex.type === "multipla_escolha" && (
            <div>
              <div style={{ fontSize:11, color:"#868e96", fontWeight:700, letterSpacing:1, textTransform:"uppercase", marginBottom:10 }}>✏️ Múltipla escolha</div>
              <h2 style={{ fontSize:17, fontWeight:700, lineHeight:1.55, marginBottom:24, color:"#f1f3f5" }}>{ex.question}</h2>
              <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                {ex.options?.map((opt, i) => {
                  let bg = "rgba(255,255,255,.05)", border = "1px solid rgba(255,255,255,.1)", color = "#dee2e6";
                  if (selected !== null) {
                    if (i === ex.correct) { bg="rgba(27,67,50,.5)"; border="2px solid #40916c"; color="#95d5b2"; }
                    else if (i === selected && !isCorrect) { bg="rgba(192,57,43,.3)"; border="2px solid #e74c3c"; color="#ff8a80"; }
                  }
                  return (
                    <button key={i} onClick={() => handleMC(i)} disabled={selected !== null}
                      style={{ background:bg, border, borderRadius:14, padding:"14px 16px", textAlign:"left", color, fontWeight:600, fontSize:14, cursor:selected!==null?"default":"pointer", transition:"all .15s" }}>
                      <span style={{ opacity:.45, marginRight:10 }}>{["A","B","C","D"][i]}.</span>{opt}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* VERDADEIRO / FALSO */}
          {ex.type === "verdadeiro_falso" && (
            <div>
              <div style={{ fontSize:11, color:"#868e96", fontWeight:700, letterSpacing:1, textTransform:"uppercase", marginBottom:10 }}>🔍 Verdadeiro ou Falso?</div>
              <div style={{ background:"rgba(255,255,255,.05)", border:"1px solid rgba(255,255,255,.1)", borderRadius:16, padding:"22px 18px", marginBottom:24 }}>
                <p style={{ fontSize:16, fontWeight:600, lineHeight:1.6, color:"#f1f3f5", margin:0 }}>{ex.statement}</p>
              </div>
              <div style={{ display:"flex", gap:12 }}>
                {[true, false].map(val => {
                  let bg="rgba(255,255,255,.05)", border="1px solid rgba(255,255,255,.1)", color="#dee2e6";
                  if (selected !== null) {
                    if (val === ex.correct) { bg="rgba(27,67,50,.5)"; border="2px solid #40916c"; color="#95d5b2"; }
                    else if (val === selected && !isCorrect) { bg="rgba(192,57,43,.3)"; border="2px solid #e74c3c"; color="#ff8a80"; }
                  }
                  return (
                    <button key={String(val)} onClick={() => handleVF(val)} disabled={selected !== null}
                      style={{ flex:1, background:bg, border, borderRadius:14, padding:"18px", textAlign:"center", color, fontWeight:700, fontSize:16, cursor:selected!==null?"default":"pointer", transition:"all .15s" }}>
                      {val ? "✅ Verdadeiro" : "❌ Falso"}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* COMPLETE A DESCRIÇÃO */}
          {ex.type === "completar_descricao" && (
            <div>
              <div style={{ fontSize:11, color:"#868e96", fontWeight:700, letterSpacing:1, textTransform:"uppercase", marginBottom:10 }}>📝 Complete a descrição</div>
              <h2 style={{ fontSize:17, fontWeight:700, lineHeight:1.6, marginBottom:8, color:"#f1f3f5" }}>{ex.question}</h2>
              {ex.hint && <p style={{ color:"#868e96", fontSize:12, marginBottom:16 }}>💡 Dica: {ex.hint}</p>}
              {isCorrect === null ? (
                <div style={{ display:"flex", gap:10 }}>
                  <input value={fillText} onChange={e => setFillText(e.target.value)} onKeyDown={e => e.key==="Enter" && handleFill()} placeholder="Digite sua resposta…"
                    style={{ flex:1, background:"rgba(255,255,255,.07)", border:"2px solid rgba(255,255,255,.13)", borderRadius:12, padding:"13px 15px", color:"#fff", fontSize:14, outline:"none" }} />
                  <button onClick={handleFill} style={{ background:"linear-gradient(135deg,#1b4332,#40916c)", border:"none", borderRadius:12, padding:"13px 18px", color:"#fff", fontWeight:700, cursor:"pointer", fontSize:18 }}>✓</button>
                </div>
              ) : (
                <div style={{ background:isCorrect?"rgba(27,67,50,.4)":"rgba(192,57,43,.25)", border:`2px solid ${isCorrect?"#40916c":"#e74c3c"}`, borderRadius:14, padding:"14px 16px", color:isCorrect?"#95d5b2":"#ff8a80" }}>
                  <div style={{ fontWeight:700, marginBottom:4 }}>{isCorrect ? "✓ Correto!" : "✗ Resposta esperada:"}</div>
                  {!isCorrect && <div style={{ fontSize:14 }}>{ex.display_answer}</div>}
                </div>
              )}
            </div>
          )}

          {/* FLASHCARD */}
          {ex.type === "flashcard" && (
            <div>
              <div style={{ fontSize:11, color:"#868e96", fontWeight:700, letterSpacing:1, textTransform:"uppercase", marginBottom:10 }}>🃏 Flashcard</div>
              <div onClick={() => setCardFlipped(f => !f)}
                style={{ background:cardFlipped?"rgba(27,67,50,.35)":"rgba(255,255,255,.05)", border:`2px solid ${cardFlipped?"#40916c":"rgba(255,255,255,.1)"}`, borderRadius:20, padding:"36px 24px", minHeight:190, cursor:"pointer", textAlign:"center", transition:"all .4s ease" }}>
                {!cardFlipped ? (
                  <><div style={{ fontSize:32, marginBottom:10 }}>{emoji}</div>
                  <div style={{ fontSize:22, fontWeight:900 }}>{ex.front}</div>
                  <div style={{ color:"#74c69d", fontSize:12, marginTop:16 }}>Toque para revelar ↕</div></>
                ) : (
                  <><div style={{ fontSize:12, fontWeight:700, color:"#74c69d", marginBottom:12, textTransform:"uppercase", letterSpacing:1 }}>{ex.front}</div>
                  <div style={{ fontSize:14, lineHeight:1.75, color:"#f1f3f5" }}>{ex.back}</div></>
                )}
              </div>
              {cardFlipped && (
                <button onClick={handleFlashcard} style={{ width:"100%", marginTop:14, background:"linear-gradient(135deg,#1b4332,#40916c)", border:"none", borderRadius:14, padding:"15px", color:"#fff", fontWeight:700, fontSize:15, cursor:"pointer" }}>
                  Entendi! Próximo +15 XP →
                </button>
              )}
            </div>
          )}

          {/* EXPLANATION + NEXT */}
          {isCorrect !== null && ex.type !== "flashcard" && (
            <div style={{ marginTop:20 }}>
              <div style={{ background:"rgba(255,255,255,.04)", borderRadius:14, padding:"12px 16px", marginBottom:12, fontSize:13, color:"#adb5bd", lineHeight:1.6 }}>
                <span style={{ color:"#74c69d", fontWeight:700 }}>💡 </span>{ex.explanation}
              </div>
              <button onClick={advance} style={{ width:"100%", background:isCorrect?"linear-gradient(135deg,#1b4332,#40916c)":"linear-gradient(135deg,#1a1a2e,#457b9d)", border:"none", borderRadius:14, padding:"15px", color:"#fff", fontWeight:700, fontSize:15, cursor:"pointer" }}>
                {idx+1 >= exercises.length || hearts <= 0 ? "Ver resultado 🎉" : "Próximo →"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── RESULT SCREEN ────────────────────────────────────────────────────────────
function ResultScreen({ section, result, onRetry, onHome }) {
  const { score, total } = result;
  const pct = total ? Math.round((score/total)*100) : 0;
  const medal = pct >= 80 ? "🏆" : pct >= 55 ? "⭐" : "💪";
  const msg = pct >= 80 ? "Excelente!" : pct >= 55 ? "Bom trabalho!" : "Continue praticando!";
  return (
    <div style={{ animation:"slideIn .4s ease", textAlign:"center", padding:"40px 0" }}>
      <div style={{ fontSize:68, marginBottom:14 }}>{medal}</div>
      <h2 style={{ fontSize:24, fontWeight:900, marginBottom:6 }}>{msg}</h2>
      <p style={{ color:"#868e96", fontSize:14, marginBottom:32 }}>{section}</p>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:32 }}>
        {[
          { label:"Acertos", value:`${score}/${total}`, e:"✅" },
          { label:"Aproveitamento", value:`${pct}%`, e:"📊" },
          { label:"XP ganho", value:`+${score*20}`, e:"⚡" },
          { label:"Avaliação", value:medal, e:"" },
        ].map((s,i) => (
          <div key={i} style={{ background:"rgba(255,255,255,.05)", borderRadius:16, padding:"18px", border:"1px solid rgba(255,255,255,.08)" }}>
            <div style={{ fontSize:22, marginBottom:6 }}>{s.e}</div>
            <div style={{ fontWeight:800, fontSize:20, color:"#74c69d" }}>{s.value}</div>
            <div style={{ color:"#868e96", fontSize:11, marginTop:2 }}>{s.label}</div>
          </div>
        ))}
      </div>
      <button onClick={onRetry} style={{ width:"100%", background:"linear-gradient(135deg,#1b4332,#40916c)", border:"none", borderRadius:14, padding:"15px", color:"#fff", fontWeight:700, fontSize:15, cursor:"pointer", marginBottom:10 }}>
        🔄 Praticar novamente (novas perguntas)
      </button>
      <button onClick={onHome} style={{ width:"100%", background:"rgba(255,255,255,.06)", border:"1px solid rgba(255,255,255,.12)", borderRadius:14, padding:"15px", color:"#adb5bd", fontWeight:700, fontSize:15, cursor:"pointer" }}>
        ← Escolher outra linha
      </button>
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("auth"); // auth | home | exercise | result | ranking
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [sectionProgress, setSectionProgress] = useState({});
  const [selectedSection, setSelectedSection] = useState(null);
  const [lastResult, setLastResult] = useState(null);

  // Check existing session
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) { setUser(session.user); loadProfile(session.user.id); setScreen("home"); }
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session?.user) { setUser(session.user); loadProfile(session.user.id); setScreen("home"); }
      else { setUser(null); setProfile(null); setScreen("auth"); }
    });
    return () => subscription.unsubscribe();
  }, []);

  async function loadProfile(userId) {
    // Load or create profile
    let { data: prof } = await supabase.from("profiles").select("*").eq("id", userId).single();
    if (!prof) {
      const { data: newProf } = await supabase.from("profiles").insert({ id: userId, email: user?.email || "", xp: 0, streak: 0, level_name: "Recruta" }).select().single();
      prof = newProf;
    }
    setProfile(prof);

    // Load section progress
    const { data: progRows } = await supabase.from("section_progress").select("*").eq("user_id", userId);
    const progMap = {};
    (progRows || []).forEach(r => { progMap[r.section_name] = r; });
    setSectionProgress(progMap);
  }

  async function handleXP(pts) {
    if (!user || !profile) return;
    const newXP = (profile.xp || 0) + pts;
    const lvl = getLevelInfo(newXP);
    await supabase.from("profiles").update({ xp: newXP, level_name: lvl.name }).eq("id", user.id);
    setProfile(p => ({ ...p, xp: newXP, level_name: lvl.name }));
  }

  async function handleFinish(result) {
    if (result.aborted) { setScreen("home"); return; }
    setLastResult(result);

    if (user && selectedSection) {
      // Save session to history
      await supabase.from("session_history").insert({
        user_id: user.id, section_name: selectedSection,
        score: result.score, total: result.total,
        completed_at: new Date().toISOString(),
      });

      // Update section progress
      const cur = sectionProgress[selectedSection] || { sessions: 0, best_score: 0 };
      const newBest = Math.max(cur.best_score || 0, result.score);
      const newSessions = (cur.sessions || 0) + 1;
      await supabase.from("section_progress").upsert({
        user_id: user.id, section_name: selectedSection,
        sessions: newSessions, best_score: newBest,
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id,section_name" });

      setSectionProgress(p => ({ ...p, [selectedSection]: { ...cur, sessions: newSessions, best_score: newBest } }));

      // Update streak if perfect
      if (result.score === result.total) {
        const newStreak = (profile?.streak || 0) + 1;
        await supabase.from("profiles").update({ streak: newStreak }).eq("id", user.id);
        setProfile(p => ({ ...p, streak: newStreak }));
      }
    }
    setScreen("result");
  }

  async function handleLogout() {
    await supabase.auth.signOut();
  }

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(160deg,#0a0a0f 0%,#0d1b2a 55%,#0a1628 100%)", fontFamily:"'Segoe UI',system-ui,sans-serif", color:"#fff" }}>
      <style>{`
        @keyframes slideIn { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }
        @keyframes floatUp { 0%{opacity:1;transform:translateX(-50%) translateY(0)} 100%{opacity:0;transform:translateX(-50%) translateY(-55px)} }
        @keyframes spin { to{transform:rotate(360deg)} }
        * { box-sizing:border-box; }
        input::placeholder { color:rgba(255,255,255,.3); }
        button { font-family: inherit; }
      `}</style>
      <div style={{ maxWidth:520, margin:"0 auto", padding:"0 18px 40px" }}>
        {screen === "auth" && <AuthScreen onAuth={u => { setUser(u); loadProfile(u.id); setScreen("home"); }} />}
        {screen === "home" && user && (
          <HomeScreen user={user} profile={profile} sectionProgress={sectionProgress}
            onSelectSection={k => { setSelectedSection(k); setScreen("exercise"); }}
            onRanking={() => setScreen("ranking")}
            onLogout={handleLogout} />
        )}
        {screen === "exercise" && selectedSection && (
          <ExerciseScreen key={selectedSection + Date.now()} section={selectedSection} userId={user?.id}
            onFinish={handleFinish} onXP={handleXP} />
        )}
        {screen === "result" && lastResult && (
          <ResultScreen section={selectedSection} result={lastResult}
            onRetry={() => setScreen("exercise")}
            onHome={() => setScreen("home")} />
        )}
        {screen === "ranking" && (
          <RankingScreen currentUserId={user?.id} onBack={() => setScreen("home")} />
        )}
      </div>
    </div>
  );
}
