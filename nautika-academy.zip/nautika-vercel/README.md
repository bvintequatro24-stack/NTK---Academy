# 🎮 Nautika Academy

Jogo de aprendizado do catálogo Nautika 2026, estilo Duolingo.

## 🚀 Como fazer o deploy no Vercel (passo a passo)

### Opção A — Deploy pelo site (mais fácil, sem instalar nada)

1. **Acesse** [vercel.com](https://vercel.com) e crie uma conta gratuita (pode entrar com Google)

2. **Suba o projeto para o GitHub:**
   - Acesse [github.com](https://github.com) e crie uma conta gratuita
   - Clique em **"New repository"** → dê o nome `nautika-academy` → clique em **"Create repository"**
   - Na página do repositório, clique em **"uploading an existing file"**
   - Arraste todos os arquivos desta pasta (mantenha a estrutura de pastas)
   - Clique em **"Commit changes"**

3. **Conecte ao Vercel:**
   - No Vercel, clique em **"Add New Project"**
   - Clique em **"Import Git Repository"** e selecione o `nautika-academy`
   - Clique em **"Deploy"** — aguarde ~2 minutos

4. **Pronto!** Você receberá um link tipo `nautika-academy.vercel.app` para compartilhar no WhatsApp 🎉

---

### Opção B — Deploy pelo terminal (para quem tem Node.js instalado)

```bash
# Instale o Vercel CLI
npm install -g vercel

# Dentro desta pasta, rode:
vercel

# Siga as instruções, faça login e o link será gerado automaticamente
```

---

## 📁 Estrutura do projeto

```
nautika-vercel/
├── public/
│   └── index.html
├── src/
│   ├── index.js
│   └── App.jsx        ← Jogo completo aqui
├── package.json
├── vercel.json
└── README.md
```

## ⚙️ Rodar localmente (opcional)

```bash
npm install
npm start
```

Abre em http://localhost:3000

---

## ⚠️ Importante: Chave da API Anthropic

O jogo usa a API da Claude para gerar exercícios dinâmicos. Para funcionar em produção:

1. Acesse [console.anthropic.com](https://console.anthropic.com)
2. Crie uma API Key
3. No Vercel, vá em **Settings → Environment Variables**
4. Adicione: `REACT_APP_ANTHROPIC_KEY` = sua chave

Sem a chave, o jogo usa exercícios de fallback que já estão embutidos no código — **ainda funciona**, só não gera perguntas novas via IA.
