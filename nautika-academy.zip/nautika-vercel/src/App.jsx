import { useState, useEffect, useCallback } from "react";

const CATALOG_TEXT = `
GAZEBOS E TENDAS EXTERNAS
PRATIKO 2X2 - Código 040499 - Categoria: Gazebos
Material: Cobertura em poliéster 210D com proteção solar 60 FPS e revestimento aluminizado. Hastes em alumínio + estrutura dobrável em aço tratado. Medidas: 2 x 2 x 2,5m. Peso: 11kg.

PRATIKO 3X3 - Código 040500 - Categoria: Gazebos
Material: Cobertura em poliéster 210D com proteção solar 60 FPS e revestimento aluminizado. Hastes em alumínio + estrutura dobrável em aço tratado. Medidas: 3 x 3 x 2,5m. Peso: 11,5kg.

PAGODA 2X2 - Código 040509 - Categoria: Gazebos
Material: Cobertura em poliéster Oxford e estrutura em ferro. Medidas: 2 x 2 x 2,5m. Teto aluminizado. Proteção solar 50 FPS. Peso: 14kg.

PAGODA 3X3 - Código 040510 - Categoria: Gazebos
Material: Cobertura em poliéster Oxford e estrutura em ferro. Medidas: 3 x 3 x 2,5m. Peso: 15kg. Teto aluminizado. Proteção solar 50 FPS.

PAGODA 2X3 - Código 040516 - Categoria: Gazebos
Material: Cobertura em poliéster Oxford e estrutura em ferro. Medidas: 2 x 3 x 2,95m. Peso: 14,5kg. Teto aluminizado. Proteção solar 50 FPS.

BARRACAS - CATEGORIA: Barracas de Acampamento
TITAN 6+6 - Código 041005 - Categoria: Barracas
Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno de alta densidade (antifungo) e costuras seladas seam tape. Medidas: 4,6 x 3 x 2,15m. Peso: 13,8kg. Capacidade: 6+6 pessoas.

VÊNUS ULTRA - Códigos 041010/041012/041014/041015 - Categoria: Barracas
Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno antifungo, costuras seladas e varetas em fibra de vidro. Disponível em 3P, 4P, 5P e 6P. Peso: 3P: 3,2kg | 4P: 3,4kg | 5P: 4,2kg | 6P: 6,4kg.

KOALA - Códigos 041016/041017/041018 - Categoria: Barracas
Material: Sobreteto em poliéster 170T de alta qualidade, varetas em fibra de vidro, dormitório em poliéster 170T e piso em polietileno 90g/m². Disponível em 2P, 3P, 4P. Peso: 2P: 1,25kg | 3P: 1,55kg | 4P: 1,7kg.

ZEUS - Códigos 041030/041032 - Categoria: Barracas
Material: Poliéster 190T High quality, tela mesh no see um, piso em polietileno de alta densidade, costuras seladas e varetas em fibra de vidro. 5P: 2,1 x 2,1 x 1,45m + Avancê. 6P: 3,05 x 3,05 x 2m + Avancê. Peso: 5P: 4kg | 6P: 7,2kg.

AMAZON - Código 041051 - Categoria: Barracas
Material: Poliéster 190T. Medidas: Aberto: 2,60 x 3,00m. Peso: 900g. Com tela 041060.

GYPSY - Código 150070 - Categoria: Barracas
Coluna d'água 2000mm. Material: Sobreteto em poliéster 190T, tela mosquiteiro em B3 e piso em polietileno 90g. Medidas: 3,0 x 3,0 x 2,0m. Peso: 6,5kg.

CHALLET INFLÁVEL - Códigos 150080/150082 - Categoria: Barracas
Coluna d'água 3000mm. Material: Poliéster Oxford 300D e piso em polietileno 200g. Medidas abertas: 3,0 x 2,10 x 1,95m. Peso: 13kg. Infla em 1 minuto.

CANADENSE - Códigos 150100/150102 - Categoria: Barracas
Coluna d'água 2000mm. Material: Sobreteto 100% poliéster 180T, estrutura em tubos de aço. 3P: 2,2 x 2 x 1,5m. Peso: 3P: 4,9kg | 5P: 5,5kg.

FLASH AUTOMÁTICA - Códigos 150422/150430 - Categoria: Barracas
Coluna d'água 1500mm. Barraca automática, monta em 10 segundos! Material: Poliéster 190T, piso em polietileno 90g, varetas fibra de vidro. 2P: 2,0 x 1,5 x 1,2m. Peso: 2P: 2,3kg | 3P: 2,6kg.

WINDY - Código 150520 - Categoria: Barracas
Coluna d'água 2500mm. Material: Sobreteto 100% poliéster impermeabilizado com poliuretano e retardante de fogo. Medidas: 2,5 x 1,5 x 85cm. Peso: 1,9kg. 1 pessoa com avancê.

FALCON - Códigos 150620/150640/150660 - Categoria: Barracas
Coluna d'água 2000mm. Material: Sobreteto poliéster laminado com poliuretano, costura selada termosoldada, proteção UV, tela No-see-um®, piso antifungos. 2P: 2x1,3x1m, 3P: 2,05x1,6x1,1m, 4P: 2,1x2,2x1,3m.

FALCON BLACK OUT - Códigos 150621/150641 - Categoria: Barracas
Coluna d'água 2000mm. Material: Sobreteto impermeabilizado com poliuretano, costura selada termosoldada, proteção UV, tela No-see-um®. Destaque: bloqueia luz do sol. 2P: 1,9kg | 3P: 2,2kg.

COLCHÕES E CAMPING - CATEGORIA: Colchões e Descanso
SMART AUTO INFLÁVEL - Código 042010 - Categoria: Colchões
Material: Poliéster tafetá 190T com revestimento em PVC + espuma de alta densidade. Medidas: 183 x 60 x 3cm. Peso: 1,1kg.

DOTT - Código 042012 - Categoria: Colchões
Material: TPU revestido de poliamida de alta tenacidade. Medidas: 195 x 58 x 5cm. Peso: 420g.

DOTT CASAL - Código 042013 - Categoria: Colchões
Material: Nylon 40D com laminação em TPU. Medidas: 1,95 x 1,2 x 5,5cm. Peso: 1,2kg.

ULTRALIGHT - Código 042030 - Categoria: Sacos de Dormir
Material: Externo Poliéster 190T W/R W/P | Interior: Poliéster 190T | Enchimento: Poliéster 150g/m2 hollow fiber. Medidas: 200 x 80 x 55cm. Peso: 700g. Temperatura: 5°C a 15°C.

REDE DE DESCANSO - Código 041060 - Categoria: Redes
Material: 210T Nylon com tela mesh no see um. Medidas: 2,75 x 1,40m. Peso: 690g.

LANTERNAS E ILUMINAÇÃO - CATEGORIA: Lanternas
BIKE ACTION - Código 044002 - Categoria: Lanternas
Material: Corpo em ABS + alumínio, lente em policarbonato. Medidas: 3,8 x 3,8 x 5,3cm. Peso: 213g. Potência: 500 lúmens (forte).

VISION TENT - Código 044004 - Categoria: Lanternas
Material: ABS e fita em poliéster. Medidas: 75 x 50 x 30mm. Peso: 39g. Potência: 130 lúmens (forte) | 35 lúmens (fraco).

MEGALITE - Código 044010 - Categoria: Lanternas
Material: ABS + policarbonato. Medidas: 6cm x Ø12,2cm. Peso: 59g.

TUBELUX - Código 044012 - Categoria: Lanternas
Material: Corpo em ABS. Medidas: 9 x 9 x 13,1cm. Peso: 258g. Potência: Lanterna frontal 1000 lúmens | Lanterna superior 300 lúmens.

ATTACK - Código 044020 - Categoria: Lanternas
Material: Liga de alumínio. Medidas: 13,2 x Ø 3cm. Peso: 130g. Potência: 140 lúmens.

PREMIUM - Código 044022 - Categoria: Lanternas
Material: Alumínio com tratamento anodizado, lente em acrílico côncavo. Medidas: 10,5cm x Ø 3cm. Peso: 125g. Potência: 120 lúmens.

MULTI LUX - Código 044044 - Categoria: Lanternas
Material: Corpo em ABS. Medidas: 19,5 x 10 x 18,5cm. Peso: 570g. Potência: Frontal 1500 lúmens | Superior 250 lúmens. Recarregável.

MOCHILAS - CATEGORIA: Mochilas e Bolsas
GUARÁ 30L/50L - Códigos 045007/045010 - Categoria: Mochilas
Material: 100% Poliéster Ripstop com conectores em PVC e ABS. Medidas: 30L: 46,5 x 30 x 24cm | 50L: 68 x 36,5 x 29cm. Peso: 30L: 650g aprox. | 50L: 1,2kg aprox.

AMAZÔNIA 15L - Código 045012 - Categoria: Mochilas
Material: Poliéster 600D e poliéster 210D. Medidas: 42 x 31 x 12cm. Peso: 270g.

KEEP DRY 5L/10L/20L/40L - Códigos 045051/052/054/056 - Categoria: Sacos Impermeáveis
Material: Poliéster 210T ultra resistente com vedação em PVC. Pesos: 5L: 80g | 10L: 105g | 20L: 155g | 40L: 290g.

INTRUDER 45L - Código 201100 - Categoria: Mochilas
Material: Poliéster Oxford PVC de alta tenacidade. Medidas: 30 x 60 x 4cm. Peso: 970g.

INTRUDER 60L - Código 201110 - Categoria: Mochilas
Material: Poliéster Oxford PVC de alta tenacidade. Medidas: 31 x 62 x 8cm. Peso: 1,65kg.

FERRAMENTAS E UTENSÍLIOS - CATEGORIA: Ferramentas
DIXON - Código 043005 - Categoria: Facas e Ferramentas
Material: Aço inoxidável 420. Medidas: Lâmina 34cm | Espessura 4mm | Cabo 16cm. Peso: 719g. Facão.

PEDERNEIRA FLINT - Código 046072 - Categoria: Ferramentas Sobrevivência
Material: Pedra flint + liga de alumínio, corrente em metal, lâmina de aço. Medidas: 7,5 x 2,6 x 1cm. Lâmina de ignição: 7,2 x 1cm. Peso: 60g.

TREKKER - Código 046080 - Categoria: Facas
Material: Aço inoxidável 420 e cabo em liga revestida de alumínio. Medidas: Aberto 16,5cm | Fechado 10cm. Peso: 116g. Canivete.

PARACORD 10M - Código 046050 - Categoria: Acessórios
Material: Paracord 550 e Polipropileno + Poliéster. Medidas: 10m. Peso: 77g.

MAPA ALUMÍNIO - Código 046007 - Categoria: Acessórios Trekking
Material: Polímero ultra resistente. Medidas: 5,5 x 9cm. Peso: 75g.

BASTÃO - Código 046040 - Categoria: Acessórios Trekking
Material: Duraluminium. Medidas: Ajustável 65 a 135cm. Peso: 280g. Bastão retrátil.

KIT PICNIC - Código 046090 - Categoria: Acessórios Camping
Material: 600 x 300D Poliéster, isolamento em alumínio. Medidas: 39 x 30 x 21,5cm. Peso: 1,60kg.

SIBERIAN 25L/34L - Códigos 046092/046093 - Categoria: Coolers
Material: Polipropileno e isolamento térmico em poliestireno expandido. 25L: 39 x 46 x 26cm | 34L: 40 x 46 x 32cm. Mantém temperatura por até 24 horas.

CADEIRAS E MÓVEIS - CATEGORIA: Mobiliário Camping
CADEIRA RELAX LIGHT - Código 046508 - Categoria: Cadeiras
Material: Estrutura em tubos de aço e tecido em poliéster 600D. Medidas: 50 x 50 x 75cm. Peso: 1,45kg.

CADEIRA RELAX - Código 046510 - Categoria: Cadeiras
Material: Estrutura em tubos de aço e tecido em poliéster 600D. Medidas: 50 x 50 x 80cm. Peso: 2kg.

JUNGLE - Código 046512 - Categoria: Cadeiras
Material: 600D Oxford e estrutura em alumínio. Medidas: Aberta 191 x 66 x 42cm | Fechada 97 x 17cm. Peso: 5kg. Cadeira espreguiçadeira.

FOGÕES E COZINHA - CATEGORIA: Cozinha ao Ar Livre
COMPACTO - Código 047004 - Categoria: Fogões
Material: Chapa de aço laminada ao frio, aço inoxidável e liga de alumínio. Medidas: Aberto 14 x 8,6cm | Fechado 6,1 x 8,8cm. Peso: 115g. Fogão portátil.

UNO NOVO - Código 047005 - Categoria: Fogões
Material: Aço esmaltado com queimador em alumínio. Medidas: 34 x 25,5 x 8,5cm. Peso: 1,86kg. Fogão a gás.

DUPPIO - Código 047007 - Categoria: Fogões
Material: Aço esmaltado. Medidas: 34 x 25,5 x 6,5cm. Peso: 1,66kg. 2 bocas.

BURN - Código 047001 - Categoria: Acendedores
Material: Liga de zinco, liga de alumínio, ferro, cobre, aço inoxidável. Medidas: 18 x 4 x 6cm. Peso: 71g. Isqueiro maçarico.

FLAME GUN - Código 047002 - Categoria: Acendedores
Material: Plástico, latão e aço. Medidas: 15 x 6,3 x 4,5cm. Peso: 128g.

TUBE GÁS - Código 047010 - Categoria: Gás Camping
Composição: Iso-butano 20%, Butano 75% e Propano 5%. Peso: 227g cada. Caixa com 28 peças.

AQUÁTICO E PRAIA - CATEGORIA: Produtos Aquáticos
LISA - Código 120010 - Categoria: Boias Infantis
Material: PVC resistente. Indicação: 3 a 6 anos. Medidas: 20 x 20cm.

JUNGLE TREK - Código 120030 - Categoria: Boias Infantis
Material: Vinil super resistente. Medidas: 30 x 15cm. Indicação: 5 a 12 anos.

MINNIE - Código 120035 - Categoria: Boias Infantis
Material: 100% PVC. Medidas: 17 x 13 x 16cm. Peso: 72g. Indicação: 3 a 6 anos.

MINNIE 140L - Código 120038 - Categoria: Piscinas Infláveis
Material: 100% PVC. Medidas: 122 x 122 x 25cm. Peso: 700g. Indicação: a partir de 2 anos.

COLETE SWIM SAFE ABC - Código 120120 - Categoria: Segurança Aquática
Material: PVC resistente. Medida: 51 x 46cm. Indicação: 3 a 6 anos.

FLUTUADOR - Código 120110 - Categoria: Flutuadores
Material: 100% poliéster, enchimento 100% espuma EPE. Indicação: 11 a 18kg. Medida: 45 x 41 x 7,5cm.

PLAY CENTER FUTEBOL - Código 120710 - Categoria: Piscinas Infláveis
Material: Vinil resistente. Indicação: 3 anos ou mais. Medidas: 1,42m x 76cm. Peso: 680g.

FAST SET 1000L - Código 125006 - Categoria: Piscinas
Material: Vinil resistente. Capacidade: 1000 litros. Medidas: 1,68m x 51cm. Indicação: Adultos.

FAST SET 3800L - Código 125020 - Categoria: Piscinas
Material: Vinil resistente. Medidas: 3,05m x 76cm. Peso: 7,5kg. Indicação: Adultos.

ESTRUTURADA CIRCULAR 4678L - Código 126010 - Categoria: Piscinas
Material: PVC. Medidas: 3,05m x 76cm. Peso: 15kg. Indicada para adultos.

ESTRUTURADA CIRCULAR 6473L - Código 126020 - Categoria: Piscinas
Material: PVC. Medidas: 3,66m x 76cm. Peso: 18,5kg. Indicada para adultos.

ÓCULOS E NATAÇÃO - CATEGORIA: Natação e Mergulho
IX-1400 - Código 127725 - Categoria: Óculos de Natação
Material: 45% Policarbonato, 35% TPE e 20% Silicone. Medidas: 16 x 5 x 4cm. Peso: 31g.

PRO LIGHTNING - Código 127741 - Categoria: Óculos de Natação
Material: Policarbonato e Silicone. Indicação: 14 anos ou mais.

DOMINATOR INFANTIL - Código 127853 - Categoria: Óculos de Natação
Material: Policarbonato, polipropileno e PVC. Medidas: 17 x 11 x 8cm. Peso: 218g. Indicação: 7 anos ou mais.

DOMINATOR ADULTO - Código 127854 - Categoria: Óculos de Natação
Material: Policarbonato, polipropileno e PVC. Medidas: 17 x 11 x 7cm. Peso: 261g. Indicação: 14 anos ou mais.

HYDRO FORCE - Código 127840 - Categoria: Snorkels e Mergulho
Material: 15% Policarbonato, 15% Vidro temperado, 20% Plástico ABS e 50% PVC. Peso: 560g. Indicação: Adulto.

AIRSOFT E TIRO - CATEGORIA: Airsoft
DE ARMORY BRADOK M904G - Código 936105 - Categoria: Rifles Airsoft
Calibre: 6mm. Tipo: Rifle Elétrico AEG. Gatilho eletrônico com Pre-cocking. Sistema Falcon Electronic. Material: Fibra de Nylon. Peso: 2.045kg. Coronha: Retrátil. Magazine: Mid-Cap 120 rounds.

DE ARMORY ORION UTR M917G - Código 936107 - Categoria: Rifles Airsoft
Calibre: 6mm. Tipo: Rifle Elétrico AEG. Gatilho eletrônico com Pre-cocking. Sistema Falcon Electronic. Material: Fibra de Nylon. Peso: 2.380g. Coronha: Rebatível. Magazine: Mid-Cap UMP 120 rounds.

COMBAT 6MM - Código 937505 - Categoria: Pistolas Airsoft
Material: Polímero e metal. Semi e full auto. Sistema híbrido, Green Gas ou CO² 12g. Calibre: 6mm. Capacidade: 22 BB's. Peso: 700g. Blowback. Acompanha 1 Magazine Green Gas.

MUNIÇÕES - CATEGORIA: Munições
TOMAHAWK - Códigos 900132/900155 - Categoria: Chumbinhos
Material: Chumbo. Disponível em 4.5mm (0,43g), 5.5mm (1,12g). Formato perfurado.

TSUNAMI - Códigos 900150/900155/900160 - Categoria: Chumbinhos
Material: Chumbo. 4.5mm: 0,65g | 5.5mm: 1,2g | 6.0mm: 1,57g cada chumbinho.

VELOZTER - Códigos 900620 a 900635 - Categoria: BBs Airsoft
Material: Plástico ABS. Disponível em 0.12g (2000un), 0.20g (5000un), 0.25g (4000un), 0.28g (4000un), 0.30g (3500un).

GÁS TAG RED GAS - Código 965000 - Categoria: Gases Airsoft
Material: Alumínio. Medidas: 28,5cm x 7,5cm diâmetro. Peso: 270g.

GÁS TAG GREEN GAS - Código 900710 - Categoria: Gases Airsoft
Material: Alumínio. Medidas: 27cm x 6,5cm diâmetro. Peso: 270g.

CÁPSULA CO2 - Códigos 900706/707/708/709 - Categoria: Gases Airsoft
Material: CO². Peso: 12g cada cápsula. Disponível em pacotes de 15, 25, 40 e 200 unidades.

FACAS E CUTELARIA - CATEGORIA: Cutelaria
ROBOT - Código 901007 - Categoria: Facas Táticas
Material: Lâmina de aço inoxidável 420SS e cabo de alumínio. Medidas: 21,4cm. Peso: 200g.

PATRIOTA - Código 901027 - Categoria: Facas Táticas
Material: Alumínio e partes em polímero. Medidas: 21,4cm. Peso: 170g.

RESCUE - Código 901037 - Categoria: Facas Táticas
Material: Lâmina de aço inoxidável e cabo de plástico. Medidas: 21cm. Peso: 120g.

BROOK - Código 901038 - Categoria: Facas
Material: Aço inoxidável 420. Medidas: 20,5cm. Peso: 180g.

NAKATA - Código 901077 - Categoria: Facas
Material: Aço inoxidável 420 e paracord. Medidas: 13 x 23 x 3cm. Peso: 180g.

ACESSÓRIOS AIRSOFT - CATEGORIA: Acessórios Airsoft
BOONIE - Código 903045 - Categoria: Vestuário Airsoft
Material: Algodão, elastano e poliéster. Medidas: 18 x 35 x 10cm. Peso: 110g. Chapéu tático.

CAMO TAPE - Código 903050 - Categoria: Acessórios Airsoft
Material: Adesivo removível. Sem esticar: 2,10m x 5cm | Esticada: 5,10m x 5cm. Peso: 60g. Fita camuflagem.

SHEMAGH - Código 903044 - Categoria: Vestuário Airsoft
Material: Algodão e poliéster. Medidas: 1 x 1m. Peso: 220g. Lenço tático.

CLEANER - Código 903070 - Categoria: Manutenção Airsoft
Material: Latão, poliéster e algodão. Medidas: 3 x 34 x 8cm. Peso: 170g. Kit limpeza de cano.

GHOST - Código 907027 - Categoria: Proteção Airsoft
Material: Policarbonato. Medidas: 11 x 54 x 4cm. Peso: 130g. Máscara.

STORM - Código 907028 - Categoria: Proteção Airsoft
Material: Policarbonato e TPU. Medidas: 5 x 18 x 8cm. Peso: 249g. Máscara.

SHADOW - Código 907029 - Categoria: Proteção Airsoft
Material: Policarbonato. Máscara tática.

BIPÉ BI-AR - Código 966500 - Categoria: Suportes Airsoft
Material: Alumínio com partes metálicas e pés emborrachados. Medidas: 15 x 23cm. Peso: 230g. Bipé articulado.

BIPÉ BI-STRAIGHT - Código 966505 - Categoria: Suportes Airsoft
Material: Alumínio com partes metálicas e pés emborrachados. Medidas: 15,3 x 17,8cm. Peso: 340g. Bipé reto.
`;

const CATEGORIES = [
  { id: "gazebos", name: "Gazebos", emoji: "⛺", color: "#2d6a4f" },
  { id: "barracas", name: "Barracas", emoji: "🏕️", color: "#1d3557" },
  { id: "colchoes", name: "Colchões e Descanso", emoji: "😴", color: "#6d4c41" },
  { id: "lanternas", name: "Lanternas", emoji: "🔦", color: "#f4a261" },
  { id: "mochilas", name: "Mochilas", emoji: "🎒", color: "#457b9d" },
  { id: "ferramentas", name: "Ferramentas", emoji: "🔧", color: "#5c4033" },
  { id: "cadeiras", name: "Cadeiras e Móveis", emoji: "🪑", color: "#7b6e8d" },
  { id: "fogoes", name: "Fogões e Cozinha", emoji: "🍳", color: "#e63946" },
  { id: "aquatico", name: "Aquático e Praia", emoji: "🏊", color: "#0077b6" },
  { id: "airsoft", name: "Airsoft", emoji: "🎯", color: "#3d405b" },
  { id: "municoes", name: "Munições", emoji: "🔫", color: "#495057" },
  { id: "cutelaria", name: "Cutelaria", emoji: "🗡️", color: "#c0392b" },
];

const EXERCISE_TYPES = ["multipla_escolha", "associar_categoria", "completar_descricao", "flashcard"];

// XP thresholds for levels
const LEVELS = [
  { level: 1, name: "Iniciante", minXP: 0, maxXP: 100, badge: "🌱" },
  { level: 2, name: "Explorador", minXP: 100, maxXP: 250, badge: "🧭" },
  { level: 3, name: "Aventureiro", minXP: 250, maxXP: 500, badge: "⛺" },
  { level: 4, name: "Especialista", minXP: 500, maxXP: 900, badge: "🎒" },
  { level: 5, name: "Mestre Nautika", minXP: 900, maxXP: 9999, badge: "🏆" },
];

const getLevelInfo = (xp) => LEVELS.find((l) => xp >= l.minXP && xp < l.maxXP) || LEVELS[LEVELS.length - 1];

export default function NautikaGame() {
  const [screen, setScreen] = useState("home"); // home | category | exercise | result | flashcard
  const [xp, setXp] = useState(0);
  const [streak, setStreak] = useState(0);
  const [completedCategories, setCompletedCategories] = useState({});
  const [currentCategory, setCurrentCategory] = useState(null);
  const [currentExercise, setCurrentExercise] = useState(null);
  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [exercises, setExercises] = useState([]);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [isCorrect, setIsCorrect] = useState(null);
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState(0);
  const [flashcardFlipped, setFlashcardFlipped] = useState(false);
  const [hearts, setHearts] = useState(3);
  const [showXPGain, setShowXPGain] = useState(null);
  const [fillAnswer, setFillAnswer] = useState("");

  const levelInfo = getLevelInfo(xp);
  const nextLevel = LEVELS.find((l) => l.level === levelInfo.level + 1);
  const xpProgress = nextLevel
    ? ((xp - levelInfo.minXP) / (nextLevel.minXP - levelInfo.minXP)) * 100
    : 100;

  const generateExercises = useCallback(async (category) => {
    setLoading(true);
    const prompt = `Você é um gerador de exercícios de treinamento de vendas para a Nautika.
    
Baseado neste catálogo de produtos da Nautika:
${CATALOG_TEXT}

Gere 5 exercícios de aprendizado focados na categoria: "${category.name}"

Regras:
- Misture os tipos: múltipla escolha, associar produto à categoria, completar descrição, e flashcards
- Use produtos REAIS do catálogo
- As perguntas devem ensinar: nomes, descrições, especificações técnicas, materiais, pesos, medidas
- Respostas devem ser em português brasileiro
- Para múltipla escolha, sempre forneça 4 opções onde apenas 1 é correta

Responda APENAS com um JSON válido (sem markdown, sem explicações), neste formato exato:
{
  "exercises": [
    {
      "type": "multipla_escolha",
      "question": "Qual é o material da cobertura do gazebo PRATIKO 2X2?",
      "options": ["Poliéster 210D", "Nylon 300T", "PVC reforçado", "Algodão impermeável"],
      "correct": 0,
      "explanation": "O PRATIKO 2X2 usa cobertura em poliéster 210D com proteção solar 60 FPS e revestimento aluminizado."
    },
    {
      "type": "flashcard",
      "front": "FLASH AUTOMÁTICA",
      "back": "Barraca que monta em apenas 10 segundos! Coluna d'água 1500mm, material em poliéster 190T, disponível em 2P (2,3kg) e 3P (2,6kg).",
      "question": "O que é a barraca Flash Automática?",
      "explanation": "A Flash Automática é famosa por montar automaticamente em 10 segundos."
    },
    {
      "type": "completar_descricao",
      "question": "O BASTÃO de trekking (cód. 046040) é feito de _______ e é ajustável de ___ a ___ cm.",
      "blanks": ["Duraluminium", "65", "135"],
      "display_answer": "Duraluminium, 65 a 135 cm",
      "explanation": "O Bastão de trekking é feito de Duraluminium e pode ser ajustado de 65 a 135 cm."
    },
    {
      "type": "associar_categoria",
      "question": "Arraste os produtos para suas categorias corretas:",
      "items": ["SIBERIAN 25L", "BURN", "DOMINATOR ADULTO", "FALCON"],
      "correct_categories": ["Coolers", "Acendedores", "Óculos de Natação", "Barracas"],
      "explanation": "SIBERIAN é cooler, BURN é isqueiro maçarico, DOMINATOR é óculos de natação e FALCON é barraca."
    },
    {
      "type": "multipla_escolha",
      "question": "Qual é o peso do colchão DOTT?",
      "options": ["420g", "700g", "1,1kg", "270g"],
      "correct": 0,
      "explanation": "O DOTT é um colchão ultra leve feito de TPU com apenas 420g."
    }
  ]
}`;

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await response.json();
      const text = data.content.map((i) => i.text || "").join("");
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setExercises(parsed.exercises);
      setCurrentExercise(parsed.exercises[0]);
      setExerciseIndex(0);
    } catch (e) {
      console.error(e);
      // Fallback exercises
      setExercises(getFallbackExercises(category));
      setCurrentExercise(getFallbackExercises(category)[0]);
      setExerciseIndex(0);
    }
    setLoading(false);
  }, []);

  const getFallbackExercises = (cat) => [
    {
      type: "multipla_escolha",
      question: `Qual categoria pertence o produto PRATIKO 2X2?`,
      options: ["Gazebos", "Barracas", "Mochilas", "Lanternas"],
      correct: 0,
      explanation: "O PRATIKO 2X2 é um gazebo com cobertura em poliéster 210D e proteção solar 60 FPS.",
    },
    {
      type: "flashcard",
      front: "SIBERIAN",
      back: "Cooler em polipropileno com isolamento térmico em poliestireno expandido. Mantém temperatura por até 24 horas! Disponível em 25L e 34L.",
      question: "O que é o SIBERIAN da Nautika?",
      explanation: "O SIBERIAN é um cooler térmico que mantém temperatura por até 24 horas.",
    },
    {
      type: "multipla_escolha",
      question: "Quantos lúmens tem a lanterna TUBELUX na posição frontal?",
      options: ["500 lúmens", "1000 lúmens", "300 lúmens", "140 lúmens"],
      correct: 1,
      explanation: "A TUBELUX possui lanterna frontal de 1000 lúmens e lanterna superior de 300 lúmens.",
    },
    {
      type: "completar_descricao",
      question: "A barraca FLASH AUTOMÁTICA monta em apenas ___ segundos.",
      blanks: ["10"],
      display_answer: "10 segundos",
      explanation: "A Flash Automática é famosa por montar automaticamente em apenas 10 segundos.",
    },
    {
      type: "multipla_escolha",
      question: "Qual é o material do bastão de trekking (cód. 046040)?",
      options: ["Aço inoxidável", "Duraluminium", "Fibra de carbono", "Alumínio comum"],
      correct: 1,
      explanation: "O Bastão de trekking é feito de Duraluminium e é ajustável de 65 a 135 cm.",
    },
  ];

  const startCategory = (category) => {
    setCurrentCategory(category);
    setHearts(3);
    setScore(0);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setFillAnswer("");
    setFlashcardFlipped(false);
    setExercises([]);
    setScreen("exercise");
    generateExercises(category);
  };

  const handleAnswer = (answerIndex) => {
    if (selectedAnswer !== null || isCorrect !== null) return;
    setSelectedAnswer(answerIndex);
    const correct = answerIndex === currentExercise.correct;
    setIsCorrect(correct);
    if (correct) {
      const gained = 20;
      setXp((prev) => prev + gained);
      setScore((prev) => prev + 1);
      setStreak((prev) => prev + 1);
      setShowXPGain(gained);
      setTimeout(() => setShowXPGain(null), 1500);
    } else {
      setHearts((prev) => Math.max(0, prev - 1));
      setStreak(0);
    }
  };

  const handleFillSubmit = () => {
    if (!fillAnswer.trim()) return;
    const correctAns = Array.isArray(currentExercise.blanks)
      ? currentExercise.display_answer
      : currentExercise.display_answer;
    const userAns = fillAnswer.trim().toLowerCase();
    const correct = currentExercise.blanks?.some((b) =>
      userAns.includes(b.toString().toLowerCase())
    ) || userAns.includes(correctAns?.toLowerCase());
    setIsCorrect(correct);
    setSelectedAnswer(0);
    if (correct) {
      const gained = 25;
      setXp((prev) => prev + gained);
      setScore((prev) => prev + 1);
      setStreak((prev) => prev + 1);
      setShowXPGain(gained);
      setTimeout(() => setShowXPGain(null), 1500);
    } else {
      setHearts((prev) => Math.max(0, prev - 1));
      setStreak(0);
    }
  };

  const nextExercise = () => {
    const nextIdx = exerciseIndex + 1;
    if (nextIdx >= exercises.length || hearts === 0) {
      setScreen("result");
      const catId = currentCategory.id;
      setCompletedCategories((prev) => ({
        ...prev,
        [catId]: Math.max(prev[catId] || 0, score + (isCorrect ? 1 : 0)),
      }));
    } else {
      setExerciseIndex(nextIdx);
      setCurrentExercise(exercises[nextIdx]);
      setSelectedAnswer(null);
      setIsCorrect(null);
      setFillAnswer("");
      setFlashcardFlipped(false);
    }
  };

  const handleFlashcardNext = () => {
    const gained = 15;
    setXp((prev) => prev + gained);
    setScore((prev) => prev + 1);
    setShowXPGain(gained);
    setTimeout(() => setShowXPGain(null), 1500);
    nextExercise();
  };

  const handleAssociarAnswer = (answerIndex) => {
    handleAnswer(answerIndex);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #0d1b2a 100%)",
      fontFamily: "'Segoe UI', system-ui, sans-serif",
      color: "#fff",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Animated background dots */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: "radial-gradient(circle at 20% 50%, rgba(45,106,79,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(29,53,87,0.2) 0%, transparent 50%)",
      }} />

      {/* XP Gain popup */}
      {showXPGain && (
        <div style={{
          position: "fixed", top: "20%", left: "50%", transform: "translateX(-50%)",
          background: "linear-gradient(135deg, #2d6a4f, #40916c)",
          color: "#fff", padding: "12px 24px", borderRadius: "50px",
          fontWeight: "800", fontSize: "20px", zIndex: 999,
          animation: "floatUp 1.5s ease-out forwards",
          boxShadow: "0 4px 20px rgba(45,106,79,0.6)",
        }}>
          +{showXPGain} XP ✨
        </div>
      )}

      <style>{`
        @keyframes floatUp { 0% { opacity:1; transform:translateX(-50%) translateY(0); } 100% { opacity:0; transform:translateX(-50%) translateY(-60px); } }
        @keyframes pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.05); } }
        @keyframes slideIn { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
        @keyframes flipCard { 0% { transform:rotateY(0deg); } 100% { transform:rotateY(180deg); } }
        .card-flip { transition: transform 0.6s; transform-style: preserve-3d; }
        .card-flip.flipped { transform: rotateY(180deg); }
        .card-face { backface-visibility: hidden; }
        .card-back { transform: rotateY(180deg); }
        .option-btn:hover { transform: translateY(-2px) !important; filter: brightness(1.1); }
        .option-btn { transition: all 0.2s ease !important; }
        .category-card:hover { transform: translateY(-4px) scale(1.02) !important; }
        .category-card { transition: all 0.25s ease !important; }
      `}</style>

      <div style={{ position: "relative", zIndex: 1, maxWidth: 520, margin: "0 auto", padding: "0 16px" }}>
        {/* HOME SCREEN */}
        {screen === "home" && (
          <div style={{ animation: "slideIn 0.5s ease" }}>
            {/* Header */}
            <div style={{ textAlign: "center", padding: "32px 0 24px" }}>
              <div style={{ fontSize: 48, marginBottom: 8 }}>⚓</div>
              <h1 style={{ fontSize: 28, fontWeight: 900, margin: 0, letterSpacing: "-0.5px",
                background: "linear-gradient(135deg, #74c69d, #40916c)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Nautika Academy
              </h1>
              <p style={{ color: "#adb5bd", margin: "8px 0 0", fontSize: 14 }}>
                Aprenda o catálogo 2026 jogando
              </p>
            </div>

            {/* Player card */}
            <div style={{
              background: "rgba(255,255,255,0.05)", backdropFilter: "blur(10px)",
              borderRadius: 20, padding: "20px", marginBottom: 24,
              border: "1px solid rgba(255,255,255,0.1)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16 }}>
                <div style={{ fontSize: 40 }}>{levelInfo.badge}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 16 }}>{levelInfo.name}</div>
                  <div style={{ color: "#74c69d", fontSize: 13, fontWeight: 600 }}>{xp} XP total</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 13, color: "#adb5bd" }}>Sequência</div>
                  <div style={{ fontWeight: 800, fontSize: 20 }}>🔥 {streak}</div>
                </div>
              </div>
              {nextLevel && (
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#adb5bd", marginBottom: 6 }}>
                    <span>Nível {levelInfo.level}</span>
                    <span>{nextLevel.minXP - xp} XP para {nextLevel.name}</span>
                  </div>
                  <div style={{ background: "rgba(255,255,255,0.1)", borderRadius: 8, height: 8, overflow: "hidden" }}>
                    <div style={{
                      width: `${xpProgress}%`, height: "100%",
                      background: "linear-gradient(90deg, #2d6a4f, #74c69d)",
                      borderRadius: 8, transition: "width 0.5s ease",
                    }} />
                  </div>
                </div>
              )}
            </div>

            {/* Categories grid */}
            <h2 style={{ fontSize: 16, fontWeight: 700, color: "#adb5bd", marginBottom: 12, letterSpacing: 1, textTransform: "uppercase", fontSize: 11 }}>
              Escolha uma categoria para estudar
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
              {CATEGORIES.map((cat) => {
                const done = completedCategories[cat.id];
                return (
                  <div
                    key={cat.id}
                    className="category-card"
                    onClick={() => startCategory(cat)}
                    style={{
                      background: `linear-gradient(135deg, ${cat.color}22, ${cat.color}44)`,
                      border: `1px solid ${cat.color}55`,
                      borderRadius: 16, padding: "16px 14px",
                      cursor: "pointer", position: "relative",
                    }}
                  >
                    {done > 0 && (
                      <div style={{
                        position: "absolute", top: 8, right: 8,
                        background: "#2d6a4f", borderRadius: 20,
                        fontSize: 10, fontWeight: 700, padding: "2px 7px", color: "#74c69d",
                      }}>✓</div>
                    )}
                    <div style={{ fontSize: 28, marginBottom: 6 }}>{cat.emoji}</div>
                    <div style={{ fontWeight: 700, fontSize: 13, lineHeight: 1.3 }}>{cat.name}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* EXERCISE SCREEN */}
        {screen === "exercise" && (
          <div style={{ animation: "slideIn 0.4s ease" }}>
            {/* Top bar */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "20px 0 16px" }}>
              <button onClick={() => setScreen("home")} style={{
                background: "transparent", border: "none", color: "#adb5bd",
                cursor: "pointer", fontSize: 20, padding: 4,
              }}>←</button>
              <div style={{ flex: 1, background: "rgba(255,255,255,0.1)", borderRadius: 8, height: 8, overflow: "hidden" }}>
                <div style={{
                  width: exercises.length ? `${((exerciseIndex) / exercises.length) * 100}%` : "0%",
                  height: "100%", background: `linear-gradient(90deg, ${currentCategory?.color || "#2d6a4f"}, #74c69d)`,
                  transition: "width 0.3s ease",
                }} />
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                {[1, 2, 3].map((h) => (
                  <span key={h} style={{ fontSize: 18, opacity: h <= hearts ? 1 : 0.2 }}>❤️</span>
                ))}
              </div>
            </div>

            {loading ? (
              <div style={{ textAlign: "center", padding: "80px 20px" }}>
                <div style={{ fontSize: 48, animation: "pulse 1s infinite" }}>⚓</div>
                <p style={{ color: "#74c69d", marginTop: 16, fontWeight: 600 }}>Gerando exercícios com IA...</p>
              </div>
            ) : currentExercise ? (
              <div>
                {/* Exercise type badge */}
                <div style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  background: `${currentCategory?.color || "#2d6a4f"}33`,
                  border: `1px solid ${currentCategory?.color || "#2d6a4f"}55`,
                  borderRadius: 20, padding: "4px 12px", marginBottom: 20,
                  fontSize: 12, fontWeight: 600, color: "#adb5bd",
                }}>
                  {currentExercise.type === "multipla_escolha" && "✏️ Múltipla escolha"}
                  {currentExercise.type === "flashcard" && "🃏 Flashcard"}
                  {currentExercise.type === "completar_descricao" && "📝 Complete a descrição"}
                  {currentExercise.type === "associar_categoria" && "🔗 Associação"}
                  <span style={{ color: "#74c69d" }}>{exerciseIndex + 1}/{exercises.length}</span>
                </div>

                {/* MULTIPLA ESCOLHA */}
                {currentExercise.type === "multipla_escolha" && (
                  <div>
                    <h2 style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.5, marginBottom: 28, color: "#f8f9fa" }}>
                      {currentExercise.question}
                    </h2>
                    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                      {currentExercise.options?.map((opt, i) => {
                        let bg = "rgba(255,255,255,0.06)";
                        let border = "1px solid rgba(255,255,255,0.12)";
                        let color = "#f8f9fa";
                        if (selectedAnswer !== null) {
                          if (i === currentExercise.correct) { bg = "rgba(45,106,79,0.4)"; border = "2px solid #2d6a4f"; color = "#74c69d"; }
                          else if (i === selectedAnswer && !isCorrect) { bg = "rgba(198,40,40,0.3)"; border = "2px solid #c62828"; color = "#ef9a9a"; }
                        }
                        return (
                          <button
                            key={i}
                            className="option-btn"
                            onClick={() => handleAnswer(i)}
                            disabled={selectedAnswer !== null}
                            style={{
                              background: bg, border, borderRadius: 14,
                              padding: "16px 18px", textAlign: "left",
                              color, fontWeight: 600, fontSize: 15,
                              cursor: selectedAnswer !== null ? "default" : "pointer",
                            }}
                          >
                            <span style={{ opacity: 0.5, marginRight: 10 }}>{String.fromCharCode(65 + i)}.</span>
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* FLASHCARD */}
                {currentExercise.type === "flashcard" && (
                  <div>
                    <p style={{ color: "#adb5bd", marginBottom: 20 }}>{currentExercise.question || "O que você sabe sobre este produto?"}</p>
                    <div
                      onClick={() => setFlashcardFlipped(!flashcardFlipped)}
                      style={{
                        background: flashcardFlipped
                          ? `linear-gradient(135deg, ${currentCategory?.color || "#2d6a4f"}44, ${currentCategory?.color || "#2d6a4f"}22)`
                          : "rgba(255,255,255,0.06)",
                        border: `2px solid ${flashcardFlipped ? currentCategory?.color || "#2d6a4f" : "rgba(255,255,255,0.12)"}`,
                        borderRadius: 20, padding: "40px 28px",
                        minHeight: 180, cursor: "pointer",
                        textAlign: "center", transition: "all 0.4s ease",
                      }}
                    >
                      {!flashcardFlipped ? (
                        <div>
                          <div style={{ fontSize: 36, marginBottom: 12 }}>{currentCategory?.emoji}</div>
                          <div style={{ fontSize: 24, fontWeight: 900, letterSpacing: 1 }}>{currentExercise.front}</div>
                          <div style={{ color: "#74c69d", fontSize: 12, marginTop: 16 }}>Toque para revelar ↕</div>
                        </div>
                      ) : (
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: "#74c69d", marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>
                            {currentExercise.front}
                          </div>
                          <div style={{ fontSize: 15, lineHeight: 1.7, color: "#f8f9fa" }}>{currentExercise.back}</div>
                        </div>
                      )}
                    </div>
                    {flashcardFlipped && (
                      <button
                        onClick={handleFlashcardNext}
                        style={{
                          width: "100%", marginTop: 16,
                          background: "linear-gradient(135deg, #2d6a4f, #40916c)",
                          border: "none", borderRadius: 14, padding: "16px",
                          color: "#fff", fontWeight: 700, fontSize: 16, cursor: "pointer",
                        }}
                      >
                        Entendi! Próximo +15 XP →
                      </button>
                    )}
                  </div>
                )}

                {/* COMPLETAR DESCRIÇÃO */}
                {currentExercise.type === "completar_descricao" && (
                  <div>
                    <h2 style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.6, marginBottom: 24, color: "#f8f9fa" }}>
                      {currentExercise.question}
                    </h2>
                    {isCorrect === null && (
                      <div style={{ display: "flex", gap: 10 }}>
                        <input
                          value={fillAnswer}
                          onChange={(e) => setFillAnswer(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleFillSubmit()}
                          placeholder="Digite sua resposta..."
                          style={{
                            flex: 1, background: "rgba(255,255,255,0.08)", border: "2px solid rgba(255,255,255,0.15)",
                            borderRadius: 12, padding: "14px 16px", color: "#fff", fontSize: 15,
                            outline: "none",
                          }}
                        />
                        <button onClick={handleFillSubmit} style={{
                          background: "linear-gradient(135deg, #2d6a4f, #40916c)",
                          border: "none", borderRadius: 12, padding: "14px 20px",
                          color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 16,
                        }}>✓</button>
                      </div>
                    )}
                    {isCorrect !== null && (
                      <div style={{
                        background: isCorrect ? "rgba(45,106,79,0.3)" : "rgba(198,40,40,0.25)",
                        border: `2px solid ${isCorrect ? "#2d6a4f" : "#c62828"}`,
                        borderRadius: 14, padding: "16px 18px",
                        color: isCorrect ? "#74c69d" : "#ef9a9a",
                      }}>
                        <div style={{ fontWeight: 700, marginBottom: 4 }}>
                          {isCorrect ? "✓ Correto!" : "✗ Resposta correta:"}
                        </div>
                        <div style={{ fontSize: 14 }}>
                          {!isCorrect && <strong>{currentExercise.display_answer}</strong>}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* ASSOCIAR CATEGORIA - simplified as multiple choice */}
                {currentExercise.type === "associar_categoria" && (
                  <div>
                    <h2 style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.5, marginBottom: 8 }}>
                      {currentExercise.question || "Qual categoria pertence ao produto?"}
                    </h2>
                    {currentExercise.items && (
                      <div style={{ marginBottom: 20 }}>
                        <p style={{ color: "#adb5bd", fontSize: 13, marginBottom: 12 }}>Produtos desta rodada:</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                          {currentExercise.items.map((item, i) => (
                            <span key={i} style={{
                              background: `${currentCategory?.color || "#2d6a4f"}33`,
                              border: `1px solid ${currentCategory?.color || "#2d6a4f"}55`,
                              borderRadius: 8, padding: "6px 12px", fontSize: 13, fontWeight: 600,
                            }}>{item}</span>
                          ))}
                        </div>
                      </div>
                    )}
                    <p style={{ color: "#adb5bd", fontSize: 14, marginBottom: 16 }}>
                      Qual desses produtos pertence à categoria <strong style={{ color: "#74c69d" }}>"{currentExercise.correct_categories?.[0]}"</strong>?
                    </p>
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      {currentExercise.items?.map((item, i) => {
                        const isRealCorrect = i === 0;
                        let bg = "rgba(255,255,255,0.06)";
                        let border = "1px solid rgba(255,255,255,0.12)";
                        if (selectedAnswer !== null) {
                          if (isRealCorrect) { bg = "rgba(45,106,79,0.4)"; border = "2px solid #2d6a4f"; }
                          else if (i === selectedAnswer) { bg = "rgba(198,40,40,0.3)"; border = "2px solid #c62828"; }
                        }
                        return (
                          <button key={i} className="option-btn" onClick={() => handleAssociarAnswer(isRealCorrect ? 0 : i + 10)}
                            disabled={selectedAnswer !== null}
                            style={{
                              background: bg, border, borderRadius: 14, padding: "14px 18px",
                              textAlign: "left", color: "#f8f9fa", fontWeight: 600, fontSize: 14,
                              cursor: selectedAnswer !== null ? "default" : "pointer",
                            }}>
                            {item}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Explanation + Next button */}
                {isCorrect !== null && currentExercise.type !== "flashcard" && (
                  <div style={{ marginTop: 20 }}>
                    <div style={{
                      background: "rgba(255,255,255,0.05)", borderRadius: 14, padding: "14px 16px",
                      fontSize: 13, color: "#adb5bd", lineHeight: 1.6, marginBottom: 14,
                    }}>
                      <span style={{ color: "#74c69d", fontWeight: 700 }}>💡 </span>
                      {currentExercise.explanation}
                    </div>
                    <button onClick={nextExercise} style={{
                      width: "100%",
                      background: isCorrect ? "linear-gradient(135deg, #2d6a4f, #40916c)" : "linear-gradient(135deg, #1d3557, #457b9d)",
                      border: "none", borderRadius: 14, padding: "16px",
                      color: "#fff", fontWeight: 700, fontSize: 16, cursor: "pointer",
                    }}>
                      {exerciseIndex + 1 >= exercises.length ? "Ver resultado 🎉" : "Próximo →"}
                    </button>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        )}

        {/* RESULT SCREEN */}
        {screen === "result" && (
          <div style={{ animation: "slideIn 0.5s ease", textAlign: "center", padding: "40px 0" }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>
              {score >= exercises.length * 0.8 ? "🏆" : score >= exercises.length * 0.5 ? "⭐" : "💪"}
            </div>
            <h2 style={{ fontSize: 26, fontWeight: 900, marginBottom: 8 }}>
              {score >= exercises.length * 0.8 ? "Incrível!" : score >= exercises.length * 0.5 ? "Bom trabalho!" : "Continue praticando!"}
            </h2>
            <p style={{ color: "#adb5bd", fontSize: 15, marginBottom: 32 }}>
              {currentCategory?.name}
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 32 }}>
              {[
                { label: "Acertos", value: `${score}/${exercises.length}`, emoji: "✅" },
                { label: "XP ganho", value: `+${score * 20}`, emoji: "⚡" },
                { label: "Corações", value: `${hearts}/3`, emoji: "❤️" },
                { label: "Sequência", value: `🔥 ${streak}`, emoji: "" },
              ].map((stat, i) => (
                <div key={i} style={{
                  background: "rgba(255,255,255,0.06)", borderRadius: 16,
                  padding: "20px", border: "1px solid rgba(255,255,255,0.1)",
                }}>
                  <div style={{ fontSize: 24, marginBottom: 6 }}>{stat.emoji}</div>
                  <div style={{ fontWeight: 800, fontSize: 22, color: "#74c69d" }}>{stat.value}</div>
                  <div style={{ color: "#adb5bd", fontSize: 12 }}>{stat.label}</div>
                </div>
              ))}
            </div>

            <button onClick={() => startCategory(currentCategory)} style={{
              width: "100%", background: "linear-gradient(135deg, #2d6a4f, #40916c)",
              border: "none", borderRadius: 14, padding: "16px",
              color: "#fff", fontWeight: 700, fontSize: 16, cursor: "pointer", marginBottom: 12,
            }}>
              🔄 Praticar novamente
            </button>
            <button onClick={() => setScreen("home")} style={{
              width: "100%", background: "rgba(255,255,255,0.07)",
              border: "1px solid rgba(255,255,255,0.15)", borderRadius: 14, padding: "16px",
              color: "#adb5bd", fontWeight: 700, fontSize: 16, cursor: "pointer",
            }}>
              ← Escolher outra categoria
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
